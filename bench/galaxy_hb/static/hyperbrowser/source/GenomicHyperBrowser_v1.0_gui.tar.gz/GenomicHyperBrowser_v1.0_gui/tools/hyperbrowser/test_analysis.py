# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#from dbgp.client import brkOnExcept
#brkOnExcept(host='localhost', port=9000, idekey='galaxy')

import sys, os, getopt, types
from urllib import quote, unquote

import galaxy.eggs
from galaxy.util import restore_text

from gold.application.GalaxyInterface import *
from quick.application.LocalOSConfig import *
import hyperbrowser.hyper_gui as hg


def getDataFilePath(root, id):
    hashDir = '/%03d/' % (int(id) / 1000)
    return root + hashDir + 'dataset_' + str(id) + '.dat'

def main():
    filename = sys.argv[1]
    tool = None
    if len(sys.argv) > 2:
        tool = sys.argv[2]
        
    params = hg.fileToParams(filename)
    
    #import_link = 'http://insilico.titan.uio.no:8097/tool_runner?tool_id=file_import&dbkey=hg18&runtool_btn=yes&input='

    file_path = None
    
    trackName1 = ""
    trackName2 = ""
    intensityTrackName = None
    subName1 = ""
    subName2 = ""
    track1File = None
    track1FileType = None
    track1FileDescr = None
    track2File = None
    track2FileType = None
    track2FileDescr = None
    intensityTrackFile = None
    intensityTrackFileType = None
    statClassName = ""
    binSize = "*"
    region = "*"
    userBins = None
    output = filename
    extractFile = None
    customFile = None
    statsFile = None
    method = None
    segLength = 0
    overlaps = None
    genome = 'NCBI36'
    genomes = {'hg18': 'NCBI36','hg17': 'NCBI35','hg16': 'NCBI34','hg15': 'NCBI33'}
    username = None
    
    for o, a in params.items():
        if a == "":
            continue
        elif o == "dbkey":
            if genomes.has_key(a):
                genome = genomes[a]
            else:
                genome = a
        elif o == "tool":
            tool = a
        elif o == "track1":
            trackName1 = a
        elif o == "track2":
            trackName2 = a
        elif o == "trackIntensity":
            intensityTrackName = a
        elif o == "grptrack1":
            grpName1 = a
        elif o == "grptrack2":
            grpName2 = a
        elif o == "subtrack1":
            subName1 = a
        elif o == "subtrack2":
            subName2 = a
        elif o == "stats":
            statClassName = a
        elif o == "binsize":
            binSize = a
        elif o == "seglength":
            segLength = int(a)
        elif o == "region":
            region = a
        elif o == "method":
            method = a
        elif o == "output":
            output = a
#            sys.stdout = open(a, "w", 0)
        elif o == "extract":
            extractFile = a
        elif o == "custom":
            sys.stdout = open(a, "w", 0)
            customFile = a
        elif o == "binfile":
            region = "bed"
            userBins = a
        elif o == "track1file":
            dummy, track1File, track1FileType, track1FileDescr = a.split(',')
        elif o == "track2file":
            dummy, track2File, track2FileType, track2FileDescr = a.split(',')
        elif o == "trackIntensityfile":
            dummy, intensityTrackFile, intensityTrackFileType, intensityTrackFileDescr = a.split(',')
        elif o == 'track1type':
            track1FileType = a
        elif o == 'track2type':
            track2FileType = a
        elif o == "statsfile":
            statsFile = a
        elif o == "file_path":
            file_path = a
        elif o == "overlaps":
            overlaps = unquote(a)
        elif o == "userEmail":
            username = a

#
#    binFiles = {'chrom': '/data1/rrresearch/standardizedTracks/NCBI36/Mapping and Sequencing Tracks/_Chromosomes/chromosomes.bed',
#       'arms': '/data1/rrresearch/standardizedTracks/NCBI36/Mapping and Sequencing Tracks/Chromosome arms/ucscChrArms.bed',
#        'bands': '/data1/rrresearch/standardizedTracks/NCBI36/Mapping and Sequencing Tracks/Chromosome bands/ucscChrBands.bed'
#       }
#
#    if method in binFiles.keys():
#        region = 'file'
#        binSize = binFiles[method]

    if method in ['__chrs__', '__chrBands__', '__chrArms__', '__genes__']:
        region = method
        binSize = params[method]

    if userBins and userBins.startswith('galaxy'):
        binSize = getDataFilePath(file_path, userBins.split(',')[1])
        region = userBins.split(',')[2]
    
    if track1File != None:
        tracks1 = ['galaxy', track1FileType, getDataFilePath(file_path, track1File), unquote(track1FileDescr)]
    else:
        tracks1 = trackName1.split(':')

    if track2File != None:
        tracks2 = ['galaxy', track2FileType, getDataFilePath(file_path, track2File), unquote(track2FileDescr)]
    else:
        tracks2 = trackName2.split(':')

    if intensityTrackFile != None:
        intensityTracks = ['galaxy', intensityTrackFileType, getDataFilePath(file_path, intensityTrackFile), unquote(intensityTrackFileDescr)]
    elif intensityTrackName != None:
        intensityTracks = intensityTrackName.split(':')
    else:
        intensityTracks = []
        
    if statClassName.startswith('galaxy'):
        statsFileId = statClassName.split(',')[1]
        statsFile = getDataFilePath(file_path, statsFileId)
        #hashDir = '/%03d/' % (int(statsFileId) / 1000)
        #statsFile = file_path + hashDir + 'dataset_' + statsFileId + '.dat'
        statClassName = '[scriptFn:=' + statsFile.encode('hex_codec') + ':] -> CustomRStat'

    #print tracks1, tracks2, statClassName, statsFile

    if tool == 'extract':
        print 'GalaxyInterface.extractTrackManyBins*', (genome, tracks1, region, binSize, True, overlaps, output)
        if output != None:
            sys.stdout = open(output, "w", 0)
        if params.has_key('sepFilePrRegion'):
            GalaxyInterface.extractTrackManyBinsToRegionDirsInZipFile(genome, tracks1, region, binSize, True, overlaps, output)
        else:
            GalaxyInterface.extractTrackManyBins(genome, tracks1, region, binSize, True, overlaps, output)

    elif tool == 'preprocess':
        print 'GalaxyInterface.startPreProcessing', (genome, tracks1)
        if output != None:
            sys.stdout = open(output, "w", 0)
        GalaxyInterface.startPreProcessing(genome)

    elif tool == 'intensity':
        intensityname = params.get('intensityname')
        if intensityname != None:
            intensityname = intensityname.split(':')
        else:
            intensityname = 'galaxy:hbfunction:'+output+':Create intensity track'
            
        numctrltracks = int(params.get('numctrltracks'))
        ctrltracks = []
        for num in range(numctrltracks):
            trackName = params.get('track' + str(num+2))
            track = trackName.split(':')
            ctrltracks.append(track)
        if output != None:
            sys.stdout = open(output, "w", 0)
#        print 'GalaxyInterface.createIntensityTrack', (tracks1, ctrltracks, intensityname, region, binSize, genome)
        print '''
            <html>
                <head>
                    <script type="text/javascript" src="%(prefix)s/static/scripts/jquery.js"></script>
                    <link href="%(prefix)s/static/style/base.css" rel="stylesheet" type="text/css" />
                </head>
                <body>
                    <p style="text-align:right"><a href="#debug" onclick="$('.debug').toggle()">Toggle debug</a></p>
            ''' % {'prefix': URL_PREFIX}
        GalaxyInterface.createIntensityTrack(tracks1, ctrltracks, intensityname, region, binSize, genome)
        print '''
                </body>
                <script type="text/javascript">
                    $('.debug').hide()
                </script>
            </html>
            '''
    elif tool == "segmentation":
        method = restore_text(method)
        methodLines = method.split('XX')
        if output != None:
            sys.stdout = open(output, "w", 0)
        GalaxyInterface.createSegmentation(genome, trackName1.split(':'), trackName2.split(':'), methodLines, segLength)

    else: #run analysis
# already validated        
#        validation = GalaxyInterface.runValid(tracks1, tracks2, statClassName, region, binSize)
        validation = True
        if validation == True:
            if output != None:
                sys.stdout = open(output, "w", 0)
            #print params
            try:
                print '''<html><head>
                    <script type="text/javascript" src="%(prefix)s/static/scripts/jquery.js"></script>
                    <script type="text/javascript">
                        var done = false;
                        var job = { filename: "%(file)s", pid: %(pid)d };

                        var dead = document.cookie.indexOf("dead=" + job.pid) >= 0 ? true : false;
                                                
                        function check_job() {
                            if (!done) {
                                if (!dead) {
                                    $.getJSON("%(prefix)s/hyper/check_job", job, function (status) {
                                            if (!status.running)
                                                document.cookie = "dead=" + job.pid;
                                            location.reload(true);
                                        }
                                    );
                                } else {
                                    alert("This job did not finish successfully: " + job.filename);
                                }
                            }
                        }
                        
                        function toggle(id) {
                            $("#" + id).toggle();
                            return false;
                        }

                        function toggleDebug() {
                            $(".debug").toggle();
                            return false;
                        }

                        function toggleInfo() {
                            $(".infomessagesmall").toggle();
                            return false;
                        }

                        setTimeout("if (!done) check_job();", 3000);
                    </script>
                    <link href="%(prefix)s/static/style/base.css" rel="stylesheet" type="text/css" />
                    </head>
                    <body>
                    <style type="text/css">
                        div.explanation {
                            padding: 5px;
                            margin: 10px;
                            background-image: none;
                        }
                        div.answerbox {
                            padding: 5px;
                            margin-bottom: 10px;
                            background-image: none;
                        }
                        div.question {
                            background-color: #FFFC8C;
                        }
                        div.simplisticanswer {
                            background-color: #C5FF8C;
                        }
                        div.preciseanswer {
                            background-color: #D8FFB3;
                        }
                        div.resultsbox {
                            background-color: #FFFFFF;
                        }
                        td {
                        white-space: normal;
                        }
                    </style>
                ''' % {'file': output, 'pid': os.getpid(), 'prefix': URL_PREFIX }

                if params.has_key('demoID'):
                    print GalaxyInterface.getDemoResultsIntro(params['demoID'])

                print '''<p style="text-align:right">
                    <a href="#debug" onclick="return toggle('run_description')">Toggle run description</a> | 
                    <a href="#debug" onclick="return toggleDebug()">Toggle debug</a>
                    </p>'''
                #print '<div class="debug">run ',(tracks1, tracks2, statClassName, region, binSize, genome, output, intensityTracks, username), '</div>'
                GalaxyInterface.run(tracks1, tracks2, statClassName, region, binSize, genome, output, intensityTracks, username)
            finally:
                print '''<script type="text/javascript">
                    done = true;
                    $(".debug").hide();
                    $(".explanation").hide();
                    $(".rundescription").hide();
                    </script>
                    </body></html>
                    '''
        else:
            print validation


if __name__ == "__main__":
    os.nice(10)
    os.environ['DISPLAY'] = ':9.0'
    main()
