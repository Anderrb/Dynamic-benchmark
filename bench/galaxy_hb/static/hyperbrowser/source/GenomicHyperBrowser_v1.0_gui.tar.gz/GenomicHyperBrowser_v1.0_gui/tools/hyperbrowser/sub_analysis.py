# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#from dbgp.client import brkOnExcept
#brkOnExcept(host='localhost', port=9000, idekey='galaxy')

import sys, os, getopt,types

import galaxy.eggs
from galaxy.util import restore_text

from gold.application.GalaxyInterface import *


def getMainTrackNames(nr):
    tracks = None
    if nr == 2:
        tracks = GalaxyInterface.getMainTrackNames([('', '', False)], [('-- From history (bed-file) --', 'bed', False), ('-- From history (wig-file) --', 'wig', False)])
    elif nr == 1:
        tracks = GalaxyInterface.getMainTrackNames([], [('-- From history (bed-file) --', 'bed', False), ('-- From history (wig-file) --', 'wig', False)])
    else:
        tracks = GalaxyInterface.getMainTrackNames([], [])
    return tracks
    #opts = []
    #for track in tracks:
    #    opts.append((track, track, False))
    #return opts


def getSubTrackNames(trackNr, baseAnno, loc):
    #print "XXX" + trackNr
    #print loc
    #if loc.has_key('type1'):
    #    baseAnno = loc['type1']
    #else:
    #    baseAnno = None
    #    print loc['type1']
    #print "sub: ",main,baseAnno
    if type(baseAnno) is types.StringType:
        globals()[trackNr + '_type'] = baseAnno
        tracks = GalaxyInterface.getSubTrackNames(baseAnno)
        #tracks = []
    else:
        tracks = []
    #opts = []
    #for track in tracks:
    #    opts.append((track, track, False))
    return tracks

def getStatOptions(loc):
#    print loc
    #print loc['track1']['x']['sub']
    sub1 = None
    if loc['track1'].has_key('x'):
        sub1 = loc['track1']['x']['sub']
        
    sub2 = None
    if loc['track2'].has_key('x'):
        sub2 = loc['track2']['x']['sub']
    
    track1 = loc['track1']['type']
    track2 = loc['track2']['type']
#    if loc['track1'].has_key('file'):
#        track1File = loc['track1']['file']
#        print vars(track1File)
#    track2File = loc['track2']['file']

#    if track1 in ['wig', 'bed']:
#        return []
#    if track2 in ['wig', 'bed']:
#        return []

    tracks1 = [track1]
    if track1 not in ['wig', 'bed']:
        subs1 = GalaxyInterface.getSubTrackNames(track1)
        if sub1 == None or sub1 not in subs1:
            sub1 = subs1[0]
        tracks1.extend(sub1[1].split(':'))

    tracks2 = [track2]
    if track2 not in ['wig', 'bed']:
        subs2 = GalaxyInterface.getSubTrackNames(track2)
        if sub2 == None or sub2 not in subs2:
           sub2 = subs2[0]
        tracks2.extend(sub2[1].split(':'))

    #print sub1, sub2


    stats = GalaxyInterface.getStatOptions(tracks1, tracks2)
    return stats
    #stats = [sub1 + " + " + sub2]
    #opts = []
    #for stat in stats:
    #    opts.append((stat, stat, False))
    #return opts


def main():
    trackName1 = ""
    trackName2 = ""
    subName1 = ""
    subName2 = ""
    track1File = None
    track1FileType = None
    track2File = None
    track2FileType = None
    statClassName = ""
    binSize = "*"
    region = "*"
    outputFile = ""
    extractFile = None
    customFile = None
    tool = None
    method = None
    segLength = 0
    genome = 'NCBI36'
    genomes = {'hg18': 'NCBI36','hg17': 'NCBI35','hg16': 'NCBI34','hg15': 'NCBI33'}
    
    longOpts = ['output=', 'genome=', 'track1=', 'track2=', 'stats=', 'sub1=', 'sub2=', \
        'track1-file=', 'track2-file=', 'track1-type=', 'track2-type=', 'format1=', 'format2=', \
        'binsize=', 'genome=', 'region=', 'bedfile=', 'method=', 'extract=', 'tool=', 'seglength=']
    opts, args = getopt.getopt(sys.argv[1:], '', longOpts)

    print opts

    for o, a in opts:
        if a == "":
            continue
        elif o == "--genome":
            if genomes.has_key(a):
                genome = genomes[a]
            else:
                genome = a
        elif o == "--tool":
            tool = a
        elif o == "--track1":
            trackName1 = a
        elif o == "--track2":
            trackName2 = a
        elif o == "--sub1":
            subName1 = a
        elif o == "--sub2":
            subName2 = a
        elif o == "--stats":
            statClassName = a
        elif o == "--binsize":
            binSize = a
        elif o == "--seglength":
            segLength = int(a)
        elif o == "--region":
            region = a
        elif o == "--method":
            method = a
        elif o == "--output":
            output = a
#            sys.stdout = open(a, "w", 0)
        elif o == "--extract":
            extractFile = a
        elif o == "--custom":
            sys.stdout = open(a, "w", 0)
            customFile = a
        elif o == "--bedfile":
            region = "file"
            binSize = a
        elif o == "--track1-file":
            track1File = a
        elif o == "--track2-file":
            track2File = a
        elif o == '--track1-type':
            track1FileType = a
        elif o == '--track2-type':
            track2FileType = a
            
    if track1File != None:
        tracks1 = ['galaxy', track1FileType, track1File, 'default']
    else:
        tracks1 = [trackName1]
        tracks1.extend(subName1.split(':'))

    if track2File != None:
        tracks2 = ['galaxy', track2FileType, track2File, 'default']
    else:
        tracks2 = [trackName2]
        tracks2.extend(subName2.split(':'))

    #print tracks1, tracks2

    if extractFile != None:
        #print 'GalaxyInterface.extractTrack', (genome, tracks1, region, extractFile)
        GalaxyInterface.extractTrack(genome, tracks1, region, extractFile)
    elif tool == 'customtrack':
        method = restore_text(method).replace('XX', '\n')
        print 'GalaxyInterface.createCustomTrack', (genome, tracks1, binSize, method)
        if output != None:
            sys.stdout = open(output, "w", 0)
        GalaxyInterface.createCustomTrack(genome, tracks1, binSize, method)
    elif tool == "segmentation":
        method = restore_text(method)
        methodLines = method.split('XX').replace('XX', '\n')
        if output != None:
            sys.stdout = open(output, "w", 0)
        GalaxyInterface.createSegmentation(genome, trackName1.split(':'), trackName2.split(':'), methodLines, segLength)
    else:
        validation = GalaxyInterface.runValid(tracks1, tracks2, statClassName, region, binSize)
#        validation = True
        if validation == True:
            if output != None:
                sys.stdout = open(output, "w", 0)
            GalaxyInterface.run(tracks1, tracks2, statClassName, region, binSize, genome, output)
        else:
            print validation


if __name__ == "__main__":
    main()
