#!/bin/sh

. $GALAXY_ENVIRONMENT_SCRIPT

cd `dirname $0`

python ./scripts/check_python.py
[ $? -ne 0 ] && exit 1

SAMPLES="
    external_service_types_conf.xml.sample
    datatypes_conf.xml.sample
    reports_wsgi.ini.sample
    tool_conf.xml.sample
    tool_data_table_conf.xml.sample
    universe_wsgi.ini.sample
    tool-data/shared/ucsc/builds.txt.sample
    tool-data/*.sample
    static/welcome.html.sample
"

# Create any missing config/location files
for sample in $SAMPLES; do
    file=`echo $sample | sed -e 's/\.sample$//'`
    if [ ! -f "$file" -a -f "$sample" ]; then
        echo "Initializing $file from `basename $sample`"
        cp $sample $file
    fi
done

# Temporary: since builds.txt is now removed from source control, create it
# from the sample if necessary
if [ ! -f "tool-data/shared/ucsc/builds.txt" ]; then
    cp tool-data/shared/ucsc/builds.txt.sample tool-data/shared/ucsc/builds.txt
fi

for i in {0..$GALAXY_ADDITIONAL_WEB_SERVER_COUNT}; do
  python ./scripts/paster.py serve universe_wsgi.webapp.ini --server-name=web$i --pid-file=paster$i.pid --log-file=paster$i.log $@
done
python ./scripts/paster.py serve universe_wsgi.runner.ini --server-name=runner --pid-file=runner.pid --log-file=runner.log $@
