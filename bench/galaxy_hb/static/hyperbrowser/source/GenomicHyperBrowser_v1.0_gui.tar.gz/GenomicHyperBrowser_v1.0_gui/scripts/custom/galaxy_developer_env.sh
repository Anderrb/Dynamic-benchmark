echo "Setting runtime enviroment for developer"

export PYTHONPATH=/usit/invitro/data/hyperbrowser/hb_core_developer/trunk

#export PYTHONPATH="$PYTHONPATH:/web/lookalike/Komodo-PythonRemoteDebugging-4.3.2-17463-linux-x86"

. /usit/invitro/data/galaxy/scripts/galaxy_modules_env.sh
