from subprocess import Popen
import os
import urllib
import gold.application.Config as Config

class ModFiles(object):
    BASIS_SUFFIX = '.basis'
    OLD_SUFFIX = '.old'
    ORIG_SUFFIX = '.orig'
    UNLOCALIZED_SUFFIX = '.unlocalized'
    
    def __init__(self, modListFn, numCols=2):
        self._modList = []
        for line in open(modListFn):
            if line.startswith('#') or line.strip() == '':
                continue
            
            cols = line.strip().split()
            assert len(cols) == numCols, "Line does not have correct number of columns (%d): %s" % (numCols, line.strip())
            self._modList.append([cols[i] for i in range(numCols)])

    def _createConfigDict(self):
        cfgList =  [x for x in dir(Config) if type(Config.__dict__[x]) == str and x[0] != '_']
        self._cfgDict =  dict((x, Config.__dict__[x]) for x in cfgList)

    def _applyLocalization(self, contents):
        for cfg in self._cfgDict:
            contents = contents.replace('$' + cfg, self._cfgDict[cfg])
            contents = contents.replace('$%' + cfg, urllib.quote(self._cfgDict[cfg]))
        return contents

    def _fixIfDir(self, fn):
        if os.path.isdir(fn) and fn[-1] != os.sep:
            fn += os.sep
        return fn

    def _copyFile(self, fromFn, toFn):
        process = Popen(['cp %s %s' % (fromFn, toFn)], shell=True)
        return process.wait() == 0

    def _isLocalizedFn(self, fn):
        return fn.endswith(self.UNLOCALIZED_SUFFIX)

    def _localizedFn(self, fn):    
        if self._isLocalizedFn(fn):
            return fn[:-len(self.UNLOCALIZED_SUFFIX)]
        return fn

    def _oldFn(self, fn):
        return fn + self.OLD_SUFFIX

    def _basisFn(self, fn):
        return fn + self.BASIS_SUFFIX

    def _origFn(self, fn):
        return self._localizedFn(fn) + self.ORIG_SUFFIX

    def _origOrOldFn(self, fn):
        if self._isLocalizedFn(fn):
            return fn + self.OLD_SUFFIX
        return fn + self.ORIG_SUFFIX

    def _getUnlocalizedFnIfExists(self, fn):
        if os.path.exists(self._unlocalizedFn(fn)):
            return self._unlocalizedFn(fn)
        return fn

    def _unlocalizedFn(self, fn):
        return fn + self.UNLOCALIZED_SUFFIX

    def _cleanUpFile(self, fn):
        if os.path.isdir(fn):
            for subFn in os.listdir(fn):
                self._cleanUpFile(os.sep.join([fn, subFn]))
        
        if not self._filesExist([self._oldFn(fn)]):
            return False
        
        os.remove(self._oldFn(fn))
        print 'REMOVED: %s' % self._oldFn(fn)
        return True
        
    def _filesExist(self, fnList, printError=False):
        for fn in fnList:
            if not os.path.exists(fn):
                if printError:
                    print 'FAILED: %s (File does not exist)' % fn
                return False
        return True
        
