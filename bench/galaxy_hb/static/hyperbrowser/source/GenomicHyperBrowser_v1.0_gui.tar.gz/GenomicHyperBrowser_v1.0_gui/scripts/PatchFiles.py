from ModFiles import ModFiles
from quick.application.LocalOSConfig import GALAXY_SOURCE_CODE_BASE_DIR, GALAXY_BASE_DIR
from subprocess import PIPE, Popen
import sys
import os

class PatchFiles(ModFiles):
    def _getFns(self, hbFn, galaxyFn):
        patchFn = self._fixIfDir(os.sep.join([GALAXY_SOURCE_CODE_BASE_DIR, hbFn]))
        targetFn = self._fixIfDir(os.sep.join([GALAXY_BASE_DIR, galaxyFn]))
        patchBasisFn = self._fixIfDir(os.sep.join([GALAXY_SOURCE_CODE_BASE_DIR, os.path.dirname(hbFn), os.path.basename(galaxyFn)]))
        patchedFn = self._fixIfDir(os.sep.join([GALAXY_BASE_DIR, os.path.dirname(galaxyFn), os.path.basename(hbFn)]))
        
        if os.path.basename(hbFn) == os.path.basename(galaxyFn):
            patchBasisFn += '.basis'
            
        patchedFn = self._getUnlocalizedFnIfExists(patchedFn)

        return patchFn, patchBasisFn, targetFn, patchedFn

    def _isDifferent(self, fn1, fn2):
        if not self._filesExist([fn1, fn2]):
            return True

        process = Popen(['diff %s %s | wc -l' % (fn1, fn2)], shell=True, stdout=PIPE)
        return int(process.stdout.readline().strip()) != 0
        
    def _updateFile(self, newFn, origFn):
        if not self._filesExist([newFn], printError=True):
            return False
        
        if not self._isDifferent(newFn, origFn):
            print 'FAILED: %s (Nothing to update)' % origFn
            return True

        if self._filesExist([origFn]):
            self._copyFile(origFn, self._oldFn(origFn))
        self._copyFile(newFn, origFn)
        print 'UPDATED: %s' % origFn
        return True
        
    def _updateFiles(self, patchFn, patchBasisFn, targetFn, patchedFn):
        targetExists = self._updateFile(newFn=targetFn, origFn=patchBasisFn)
        if targetExists:
            self._updateFile(newFn=patchedFn, origFn=patchFn)
        return targetExists

    def update(self):
        for hbFn, galaxyFn in self._modList:
            patchFn, patchBasisFn, targetFn, patchedFn = self._getFns(hbFn, galaxyFn)
            
            if os.path.basename(hbFn) == os.path.basename(galaxyFn):
                origTargetExists = self._updateFiles(patchFn, patchBasisFn, self._origFn(targetFn), patchedFn)
                if not origTargetExists:
                    #The target file and the patch file have the same name, but there is no target.orig file,
                    # i.e. no patches have been applied.
                    self._updateFile(newFn=targetFn, origFn=patchBasisFn)
            else:
                self._updateFiles(patchFn, patchBasisFn, targetFn, patchedFn)

    def _getCorrectTargetFn(self, hbFn, galaxyFn, targetFn):
        if os.path.basename(hbFn) == os.path.basename(galaxyFn) and os.path.exists(self._origFn(targetFn)):
            return self._origFn(targetFn)
        return targetFn
    
    def apply(self):
        for hbFn, galaxyFn in self._modList:
            patchFn, patchBasisFn, targetFn, patchedFn = self._getFns(hbFn, galaxyFn)
            if not self._filesExist([patchFn, patchBasisFn, targetFn], printError=True):
                continue

            if self._filesExist([patchedFn]):
                process = Popen(['diff3 -m -E %s %s %s | diff - %s | wc -l' % \
                                 (patchFn, patchBasisFn, self._getCorrectTargetFn(hbFn, galaxyFn, targetFn), patchedFn)], \
                                shell=True, stdout=PIPE)
                if int(process.stdout.readline().strip()) == 0:
                    print 'FAILED: %s (Patch has allready been applied)' % hbFn
                    continue

            if os.path.basename(hbFn) == os.path.basename(galaxyFn) and not self._filesExist([self._origFn(targetFn)]):
                self._copyFile(targetFn, self._origFn(targetFn))
            elif self._filesExist([patchedFn]):
                self._copyFile(patchedFn, self._oldFn(patchedFn))

            process = Popen(['diff3 -x %s %s %s | wc -l' % \
                             (patchFn, patchBasisFn, self._getCorrectTargetFn(hbFn, galaxyFn, targetFn))], \
                             shell=True, stdout=PIPE)
            if int(process.stdout.readline().strip()) != 0:
                print 'CONFLICT: %s' % patchedFn

            process = Popen(['diff3 -m -E %s %s %s > %s' % \
                             (patchFn, patchBasisFn, self._getCorrectTargetFn(hbFn, galaxyFn, targetFn), patchedFn)], \
                            shell=True)
            print 'PATCHED: -> %s' % (patchedFn)

    def cleanup(self):
        for hbFn, galaxyFn in self._modList:
            patchFn, patchBasisFn, targetFn, patchedFn = self._getFns(hbFn, galaxyFn)

            self._cleanUpFile(patchFn)
            self._cleanUpFile(patchBasisFn)

if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] not in ['update', 'apply', 'cleanup']:
        print '''
Usage: python PatchFiles.py update|apply|cleanup patchListFn
        
update:  Copies original and patched Galaxy files to the HyperBrowser file tree.
         This is done to create the patch files or update them with the latest
         Galaxy changes.
         N.B.: Make sure that there is no unresolved conflicts in the patched files.
        
apply:   Applies the HyperBrowser patches to the Galaxy files. Also includes any 
         additional changes made after the patch was last updated.
         If an unlocalized version of the Galaxy file is present,
         this is the file that is patched.

         N.B.: Conflicts may occur. In that case, manually edit the patched files.
         Also, if the HyperBrowser file and the Galaxy file have the same name,
         the original Galaxy file is renamed <filename>.orig before patching.

cleanup: Removes old files from the HyperBrowser file tree. This is typically
         called prior to svn commit.
'''
        sys.exit(0)

    command = sys.argv[1]
    patchFiles = PatchFiles(sys.argv[2])

    if command == 'update':
        patchFiles.update()
    elif command == 'apply':
        patchFiles.apply()
    elif command == 'cleanup':
        patchFiles.cleanup()
    else:
        print 'Nothing done. Should not be possible'

