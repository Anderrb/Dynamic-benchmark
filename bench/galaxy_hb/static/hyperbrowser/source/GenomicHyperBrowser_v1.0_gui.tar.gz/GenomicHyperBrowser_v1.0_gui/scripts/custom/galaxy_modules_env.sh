. /etc/profile.d/modules.sh

module purge
module load gcc/4.5.1
module load R/2.10.1
export RHOME="/xanadu/site/common/VERSIONS/R-2.10.1/lib64/R"
export R_LIBS="/projects/rrresearch/common_software/lib/R-2.10.1/library"
#export R_LIBS_USER=$R_LIBS
module load python/2.7.gcc45

export PYTHONPATH="$PYTHONPATH:/projects/rrresearch/common_software/lib/python2.7/site-packages"
#export PYTHONPATH="$PYTHONPATH:/web/lookalike/Komodo-PythonRemoteDebugging-4.3.2-17463-linux-x86"

# Xvfb
export DISPLAY=":9.0"

export TMPDIR="/usit/invitro/work/tmp"
export TMP=$TMPDIR
export TEMP=$TMPDIR
export PYTHON_EGG_CACHE="$TMP/.python-eggs"

umask 0002
ulimit -c 50000
ulimit -s unlimited
#ulimit -a

#ulimit -m 8000000
ulimit -v 20000000

