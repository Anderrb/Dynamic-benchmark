#!/bin/sh

if [ $# -ne 1 ]
then
    if [ ! -L `pwd -P`"/hb_core" ]
    then
	echo "Usage: $0 [HB_source_path]"
	echo "  HB_source_path must be specified if a symbolic link named hb_core is not "
	echo "  present in the current directory."
	exit
    else
	SOURCE_PATH=`pwd -P`"/hb_core"
    fi
else
    SOURCE_PATH="$1"
fi

if [ ! -d "$SOURCE_PATH" ]; then
  echo "Error: Directory $SOURCE_PATH does not exist"
  exit
fi

OLD_PYTHONPATH=$PYTHONPATH
export PYTHONPATH=$SOURCE_PATH:$PYTHONPATH
