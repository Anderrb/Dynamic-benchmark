#!/bin/sh

. common_begin.sh

python CopyFiles.py cleanup copy_list.txt
python PatchFiles.py cleanup patch_list.txt

. common_end.sh
