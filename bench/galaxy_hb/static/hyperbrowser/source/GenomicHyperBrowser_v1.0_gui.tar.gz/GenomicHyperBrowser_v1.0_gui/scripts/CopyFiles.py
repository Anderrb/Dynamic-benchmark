from ModFiles import ModFiles
from quick.application.LocalOSConfig import GALAXY_SOURCE_CODE_BASE_DIR, GALAXY_BASE_DIR
from subprocess import PIPE, Popen
import sys
import os

class CopyFiles(ModFiles):
    RSYNC_CMD = "rsync -rpEic --exclude='.*' --exclude='*~' --exclude='#*' --exclude='*.orig' --exclude='*.old'"

    def _getFns(self, hbFn, galaxyFn):
        newFn = self._fixIfDir(os.sep.join([GALAXY_SOURCE_CODE_BASE_DIR, hbFn]))
        origFn = self._fixIfDir(os.sep.join([GALAXY_BASE_DIR, galaxyFn]))
        origFn = self._getUnlocalizedFnIfExists(origFn)
        return newFn, origFn

    def _getFnFromRsyncOut(self, text):
        return [' '.join(x.strip().split()[1:]) for x in text]

    def _copy(self, newFn, origFn, rsyncCmd, renameFunc):
        if not self._filesExist([newFn], printError=True):
            return False

        process = Popen([rsyncCmd + ' --dry-run %s %s' % (newFn, origFn)], shell=True, stdout=PIPE)
#        print os.linesep.join([x for x in process.stdout])
        filesToCopy = self._getFnFromRsyncOut(process.stdout)
        if len(filesToCopy) == 0:
            print 'FAILED: %s (File/directory has allready been copied)' % origFn
            return False

        for fn in filesToCopy:
            if fn == 'non-regular':
                print 'FAILED: %s (File is symlink)' % origFn
                return False
            galaxyFn = os.sep.join([os.path.dirname(origFn), fn])
            if not os.path.isdir(galaxyFn):
                galaxyFn = self._getUnlocalizedFnIfExists(galaxyFn)
                if self._filesExist([galaxyFn]):
                    self._copyFile(galaxyFn, renameFunc(galaxyFn))
                
        process = Popen([rsyncCmd + ' %s %s' % (newFn, origFn)], shell=True, stdout=PIPE)
        filesCopied = self._getFnFromRsyncOut(process.stdout)
        for fn in filesCopied:
            galaxyFn = os.sep.join([os.path.dirname(origFn), fn])
            if not os.path.isdir(newFn):
                galaxyFn = self._getUnlocalizedFnIfExists(galaxyFn)
            print 'COPIED: -> %s' % galaxyFn

        return True

    def update(self):
        for hbFn, galaxyFn in self._modList:
            newFn, origFn = self._getFns(hbFn, galaxyFn)
            self._copy(origFn, newFn, self.RSYNC_CMD + ' --existing', self._oldFn)

    def apply(self):
        for hbFn, galaxyFn in self._modList:
            newFn, origFn = self._getFns(hbFn, galaxyFn)
            self._copy(newFn, origFn, self.RSYNC_CMD, self._origOrOldFn)

    def cleanup(self):
        for hbFn, galaxyFn in self._modList:
            newFn, origFn = self._getFns(hbFn, galaxyFn)

            self._cleanUpFile(newFn)

if __name__ == "__main__":
    if len(sys.argv) != 3 or sys.argv[1] not in ['update', 'apply', 'cleanup']:
        print '''
Usage: python CopyFiles.py update|apply|cleanup patchListFn
        
update:  Copies original Galaxy files to the HyperBrowser file tree. Only
         copies files that exist in the HyperBrowser tree and are different.
         N.B. This overwrites the HyperBrowser files (but a copy is stored
         as <filename>.old).

apply:   Copies HyperBrowser files to the Galaxy file tree. Only copies files
         that are different. Works recursively for directories.
         N.B. This overwrites the Galaxy files (but a copy is stored as
         <filename>.orig).

         If an unlocalized version of the Galaxy file is present,
         this is the file that is overwritten (and a copy is stored as <filename>.old).
         N.B. This does not work recursively for directories.
         
cleanup: Removes old files from the HyperBrowser file tree. This is typically
         called prior to svn commit.
'''
        sys.exit(0)

    command = sys.argv[1]
    copyFiles = CopyFiles(sys.argv[2])

    if command == 'update':
        copyFiles.update()
    elif command == 'apply':
        copyFiles.apply()
    elif command == 'cleanup':
        copyFiles.cleanup()
    else:
        print 'Nothing done. Should not be possible'

