#!/bin/sh

. common_begin.sh

python LocalizeFiles.py apply localize_list.txt

. common_end.sh