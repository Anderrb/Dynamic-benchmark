echo "Setting runtime enviroment for stable"

export PYTHONPATH=/usit/invitro/data/hyperbrowser/hb_core_stable/trunk

. /usit/invitro/data/galaxy/scripts/galaxy_modules_env.sh
