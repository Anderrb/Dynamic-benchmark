#!/bin/sh

. common_begin.sh

python CopyFiles.py apply copy_list.txt

. common_end.sh