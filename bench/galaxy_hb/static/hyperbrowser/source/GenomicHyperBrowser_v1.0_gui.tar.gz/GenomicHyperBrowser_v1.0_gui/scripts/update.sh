#!/bin/sh

. common_begin.sh

python CopyFiles.py update copy_list.txt
python PatchFiles.py update patch_list.txt

. common_end.sh
