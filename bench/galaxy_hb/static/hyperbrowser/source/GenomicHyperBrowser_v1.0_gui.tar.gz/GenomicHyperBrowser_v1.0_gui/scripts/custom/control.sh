#!/bin/sh

GALAXY_NAME=`basename $0`
GALAXY_DIR="/usit/invitro/data/galaxy/$GALAXY_NAME"

if [ ! -d "$GALAXY_DIR" ]; then
    echo "$GALAXY_DIR does not exist"
    exit 2
fi

start() {
    sudo -u ghbrowse $GALAXY_DIR/run.sh --daemon
}

stop() {
    sudo -u ghbrowse $GALAXY_DIR/run.sh --stop-daemon
}

restart() {
    stop
    sleep 5
    start
}

case "$1" in
  start)
        start
        ;;
  stop)
        stop
        ;;
  restart)
        restart
        ;;
  status)
	status
        RETVAL=$?
        ;;
  *)
        echo $"Usage: $0 {start|stop|status|restart}"
        RETVAL=1
esac

exit $RETVAL
