#!/bin/sh

. common_begin.sh

python ShellCommands.py apply setupdirs_list.txt
python CopyFiles.py apply copy_list.txt
python PatchFiles.py apply patch_list.txt
python LocalizeFiles.py apply localize_list.txt

python ShellCommands.py apply make_style.txt
python CopyFiles.py apply copy_list.txt

python ShellCommands.py apply permissions_list.txt

. common_end.sh
