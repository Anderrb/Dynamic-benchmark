#!/bin/sh

. common_begin.sh

python PatchFiles.py apply patch_list.txt

. common_end.sh