# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.
#
# instance is dynamically imported into namespace of <modulename>.mako template (see web/controllers/hyper.py)

import sys, os
from gold.application.GalaxyInterface import GalaxyInterface
from quick.webtools.GeneralGuiToolsFactory import GeneralGuiToolsFactory
from quick.application.LocalOSConfig import *
from quick.util.StaticFile import *
from BaseToolController import *
 
class GenericToolController(BaseToolController):
    def __init__(self, trans, job):
        BaseToolController.__init__(self, trans, job)
        self.errorMessage = None
        self.toolId = self.params.get('tool_id', 'arrgh')
        self.prototype = GeneralGuiToolsFactory.getWebTool(self.toolId)
        self.inputNames = self.prototype.getInputBoxNames()
        self.inputTypes = []
        self.inputValues = []
        self.inputIds = [name.replace(' ', '_') for name in self.inputNames]
        self.trackElements = {}
        if trans:
            self.action()

    def _getOptionsBox(self, i):
        if i > 0:
            opts = getattr(self.prototype, 'getOptionsBox' + str(1 + i))(self.inputValues)
        else:
            opts = getattr(self.prototype, 'getOptionsBox' + str(1 + i))()
        return opts

    def action(self):
        self.options = []
        for i in range(len(self.inputNames)):
            name = self.inputNames[i]
            id = self.inputIds[i]
            opts = self._getOptionsBox(i)
            val = self.params.get(id)
            if opts == None:
                self.inputTypes += ['hidden']
            elif isinstance(opts, str):
                if opts == '__genome__':
                    self.inputTypes += ['__genome__']
                    val = self.getGenome()
                elif opts == '__track__':
                    self.inputTypes += ['__track__']
                    track = self.trackElements[id] = self.getTrackElement(id, name)
                    val = track.asString()
                else:
                    self.inputTypes += ['text']
                    if val == None:
                        val = opts
                    opts = 1
            elif isinstance(opts, tuple):
                if opts[0] == '__history__':
                    self.inputTypes += opts[:1]
                    opts = self.galaxy.optionsFromHistoryFn(opts[1:] if len(opts)>1 else None, val)
                    if val == None and opts and len(opts[1]) > 0:
                        val = opts[1][0]
                    #opts = self.galaxy.getHistory(GalaxyInterface.getSupportedGalaxyFileFormats())
                elif len(opts)==2 and isinstance(opts[0], str) and isinstance(opts[1], int):
                    self.inputTypes += ['text']
                    if val == None:
                        val = opts[0]
                    opts = opts[1]
                    
            elif isinstance(opts, dict):
                self.inputTypes += ['multi']
                values = type(opts)()
                for k,v in opts.items():
                    values[k] = self.params.get(id + '|' + k, False if val else v)
                val = values
                        
            elif isinstance(opts, list) and len(opts) == 0:
                self.inputTypes += ['text']
                if val == None:
                    val = ''
            else:
                self.inputTypes += ['select']
                if val == None or val not in opts:
                    val = opts[0]
            self.inputValues.append(val)
            self.options.append(opts)
        self.validate()

    def _action(self):
        pass

    def execute(self):
        if self.prototype.getOutputFormat() == 'html':
            self.stdoutToHistory()
        #print self.params
        
        for i in range(len(self.inputIds)):
            opts = self._getOptionsBox(i)
            if opts == '__genome__':
                id = 'dbkey'
            else:
                id = self.inputIds[i]
            choice = self.params[id] if self.params.has_key(id) else ''

            if isinstance(opts, dict):
                values = type(opts)()
                for k,v in opts.items():
                    if self.params.has_key(id + '|' + k):
                        values[k] = self.params[id + '|' + k]
                    else:
                        values[k] = False
                choice = values

            self.inputValues.append(choice)

        #print choices
        if self.prototype.getOutputFormat() == 'html':
            print '''
            <html>
                <head>
                    <script type="text/javascript" src="%(prefix)s/static/scripts/jquery.js"></script>
                    <link href="%(prefix)s/static/style/base.css" rel="stylesheet" type="text/css" />
                </head>
                <body>
                    <p style="text-align:right"><a href="#debug" onclick="$('.debug').toggle()">Toggle debug</a></p>
            ''' % {'prefix': URL_PREFIX}

        self.prototype.execute(self.inputValues, self.jobFile)

        if self.prototype.getOutputFormat() == 'html':
            print '''
                </body>
                <script type="text/javascript">
                    $('.debug').hide()
                </script>
            </html>
            '''

    def isPublic(self):
        try:
            return self.prototype.isPublic()
        except:
            return False
        
    def isDebugging(self):
        try:
            return self.prototype.isDebugMode()
        except:
            return False
        
    def getIllustrationImage(self):
        image = None
        id = self.prototype.getToolIllustration()
        if id:
            image = StaticImage(id)
        return image

    def getDemoURL(self):
        try:
            demo = self.prototype.getDemoSelections()
            url = '?mako=generictool&tool_id=' + self.toolId
            for i in range(len(self.inputIds)):
                if self.inputTypes[i] == '__genome__':
                    id = 'dbkey'
                else:
                    id = self.inputIds[i]
                val = demo[i]
                url += '&' + id + '=' + val
        except:
            url = None
        return url
        
    def hasDemoURL(self):
        try:
            demo = self.prototype.getDemoSelections()
            if len(demo) > 0:
                return True
        except:
            pass
        return False

    def doRedirect(self):
        return self.prototype.isRedirectTool() and self.params.has_key('start')
        #return True

    def getRedirectURL(self):
        return self.prototype.getRedirectURL(self.inputValues)
        #return 'http://www.vg.no'
     
    def validate(self):
        self.errorMessage = self.prototype.validateAndReturnErrors(self.inputValues)
    
    def isValid(self):
        return True if self.errorMessage is None else False
    
    def hasErrorMessage(self):
        return False if self.errorMessage in [None, ''] else True
        
def getController(transaction = None, job = None):
    return GenericToolController(transaction, job)

