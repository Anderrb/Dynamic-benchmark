
import sys
from numpy import *
from rpy import r
from gold.application.GalaxyInterface import GalaxyInterface
from hyper_gui import *
from BaseToolController import *
from gold.application.StatRunner import AnalysisDefJob
from quick.webtools.GeneralGuiTool import GeneralGuiTool
from Pycluster import *
from test.sandbox.master.draw_dendrogram import draw_dendrogram
from quick.util.StaticFile import StaticFile, GalaxyRunSpecificFile
from gold.description.TrackInfo import TrackInfo
from quick.aux.clustering.FeatureCatalog import FeatureCatalog, DirectDistanceCatalog, LocalResultsAsFeaturesCatalog 
from quick.util.CommonFunctions import extractIdFromGalaxyFn

class ClusteringToolController(BaseToolController):
    def __init__(self, trans, job):
        BaseToolController.__init__(self, trans, job)
        
    def execute(self):
        self.stdoutToHistory()
        clusterTracks = []
        refTracks = []
        options = [] #for the case using refTracks, options contains feature for every refTrack, chosen by user.
        genome = self.params.get('dbkey')

        for i in range(int(self.params['numclustertracks'])) :
            tempKey = 'track' + str(i+1)
            clusterTracks.append(self.params[tempKey])

        #print 'hello'
        #for track in clusterTracks :
        #   print track

        tracks = self.trackPrepare(clusterTracks)
        track_names = [track[-1] for track in tracks] #just take the last part in each track_path, used as name of the track
        
        if self.params.get('clusterCase') == 'use pair distance':
            if self.params.has_key("pair_feature") : # must use "" here because the '' does not work
                feature = self.params.get('pair_feature')
                extra_feature = self.params.get('pair_feature+') #must be different from the text --select--
                clusterMethod = self.params.get("clusterMethod") # from clusterMethod select tag
                extra_option = self.params.get("clusterMethod+") # option associated in the clusteMethod choose.    
                d_matrix = self.constructDistMatrix(genome, tracks, feature, extra_feature)
                figure = GalaxyRunSpecificFile(['cluster_trakcs_result_figure.png'], self.jobFile) #this figure is runspecific and is put in the directory
                #/usit/invitro/data/galaxy/galaxy_developer/static/hyperbrowser/run_specific/
                figurepath = figure.getDiskPath(True)
                r.png(figurepath)
                r.assign('track_names',track_names)
                r.assign('d_matrix', d_matrix)
                r('row.names(d_matrix) <- track_names')
                #r.assign('clusterMethod',clusterMethod)
                #r.assign('extra_option',extra_option)
                r('d <- as.dist(d_matrix)')
                if clusterMethod == 'Hierarchical clustering' and extra_option != "--select--" :
                   r.assign('extra_option',extra_option) 
                   r('hr <- hclust(d, method=extra_option, members=NULL)')
                   r('plot(hr, hang=0.1)')
                   #r('rect.hclust(hr, k=3, border="red")')
                r('dev.off()')
                print figure.getLink('clustering results figure<br>')
                
            else :
                print 'A feature must be selected in order to compute the distance between tracks.'
                
                
        elif self.params.get('clusterCase') == 'use refTracks':
            if self.params.has_key('numreferencetracks') :
                galaxyFn = self.jobFile #run-specific file 
                for i in range(int(self.params['numreferencetracks'])):
                    ref_i = self.params['reftrack' + str(i+1)].split(":") #name of refTrack is being used to construct the name of expanded refTrack
                    refTracks.append(ref_i) #put the refTrack into refTracks list
                    temp_opt1 = 'ref'+str(i)+'feature'
                    if self.params.has_key(temp_opt1):
                        options.append(self.params.get(temp_opt1))
                    if self.params.get('yes_no'+str(i)) == "Yes" and self.params.get('how_many'+str(i)) != "--select--":
                        for expan in range(int(self.params.get('how_many'+str(i)))) :
                            upFlank = int(self.params.get(str(i)+str(expan)+'up'))
                            downFlank = int(self.params.get(str(i)+str(expan)+'down'))
                            withinRunId = str(i+1)+' expansion '+str(expan + 1)
                            outTrackName = GalaxyInterface.expandBedSegmentsFromTrackNameUsingGalaxyFn(ref_i, genome, upFlank, downFlank, galaxyFn, withinRunId) #outTrackName is unique for run
                            refTracks.append(outTrackName) #put the expanded track into refTracks list
                            options.append(options[-1]) # use chosen feature for refTack as valid feature for the expanded
            
                for track in refTracks :
                    print track
                    print '<br>' 
                    
            if len(refTracks) > 0 :
                
               ''' 
               reftracks = self.trackPrepare(refTracks)
               f_matrix = self.construct_feature_matrix_using_reftracks(genome,tracks,reftracks,options)
               tree = treecluster(f_matrix, method="s")
               print tree
               trackNames = [track[-1] for track in tracks]
               figure = StaticFile(['hiepln','dendro.jpg'])
               #figure = StaticFile(['hiepln','dendro'],'jpg')
               filepath = figure.getDiskPath()           
               draw_dendrogram(tree,trackNames,filepath)
               print figure.getLink('clustring result')
               '''
               distanceType = self.params.get("distanceType") #from distanceType select tag 
               clusterMethod = self.params.get("clusterMethod") # from clusterMethod select tag
               extra_option = self.params.get("clusterMethod+") # option associated in the clusteMethod choose.               
               reftracks = self.trackPrepare(refTracks)
               #reftracks = refTracks #just for temporary use 
               f_matrix = self.construct_feature_matrix_using_reftracks(genome,tracks,reftracks,options)
               figure = GalaxyRunSpecificFile(['cluster_tracks_result_figure.png'], self.jobFile) #runspecific file to save the result figure
               figurepath = figure.getDiskPath(True)
               r.png(figurepath)
               r.assign('track_names',track_names) #use as track names, will be shown in clustering figure
               r.assign('f_matrix',f_matrix)
               r.assign('distanceType',distanceType)
               r('row.names(f_matrix) <- track_names')
               #r.assign('clusterMethod',clusterMethod)
               #r.assign('extra_option',extra_option)
               #r('d <- dist(f_matrix, method=distanceType)')
               if clusterMethod == 'Hierarchical clustering' and extra_option != "--select--":
                   r('d <- dist(f_matrix, method=distanceType)')
                   r.assign('extra_option',extra_option)
                   r('hr <- hclust(d, method=extra_option, members=NULL)')
                   r('plot(hr, hang=0.1)')
                   #r('rect.hclust(hr, k=3, border="red")') #graph cut
               elif clusterMethod == 'K-means clustering' and extra_option != "# clusters" :
                   extra_option = int(extra_option)
                   r.assign('extra_option',extra_option)
                   r('hr <- kmeans(f_matrix,extra_option)') #the number of cluster is gotten from clusterMethod+ tag, instead of 3 used here
                   r('plot(f_matrix, col=hr$cluster)') 
               r('dev.off()')
               
               heatmap = GalaxyRunSpecificFile(['heatmap_figure.png'], self.jobFile)
               heatmap_path = heatmap.getDiskPath(True)
               r.png(heatmap_path)
               r('heatmap(f_matrix, Colv=NA, scale="column", xlab="Features", ylab="cluster tracks")')
               r('dev.off()')
               print figure.getLink('clustering results figure<br>')
               print heatmap.getLink('heatmap figure <br>')
               
            else :
               print 'Have to specify a set of refTracks'
        else: #self feature case.
            if self.params.has_key("self_feature") :
                feature = self.params.get("self_feature")
                distanceType = self.params.get("distanceType") #from distanceType select tag 
                clusterMethod = self.params.get("clusterMethod") # from clusterMethod select tag
                extra_option = self.params.get("clusterMethod+") # option associated in the clusteMethod choose.
                f_matrix = self.construct_feature_matrix(genome, tracks, feature)
                print f_matrix
                figure = GalaxyRunSpecificFile(['cluster_tracks_result_figure.png'], self.jobFile)
                figurepath = figure.getDiskPath(True)
                r.png(figurepath)
                r.assign('track_names',track_names) #use as track names, will be shown in clustering figure
                r.assign('f_matrix',f_matrix)
                r.assign('distanceType',distanceType)
                r('row.names(f_matrix) <- track_names')
                #r.assign('clusterMethod',clusterMethod)
                #r.assign('extra_option',extra_option)
                #r('d <- dist(f_matrix, method=distanceType)')
                if clusterMethod == 'Hierarchical clustering' and extra_option != "--select--":
                    r('d <- dist(f_matrix, method=distanceType)')
                    r.assign('extra_option',extra_option)
                    r('hr <- hclust(d, method=extra_option, members=NULL)')
                    r('plot(hr, hang=0.1)')
                    #r('rect.hclust(hr, k=3, border="red")')
                elif clusterMethod == 'K-means clustering' and extra_option != "# clusters" :
                    extra_option = int(extra_option)
                    r.assign('extra_option',extra_option)
                    r('hr <- kmeans(f_matrix,extra_option)') #the number of cluster is gotten from clusterMethod+ tag, instead of 3 used here
                    r('plot(f_matrix, col=hr$cluster)') 
                r('dev.off()')
                heatmap = GalaxyRunSpecificFile(['heatmap_figure.png'], self.jobFile)
                heatmap_path = heatmap.getDiskPath(True)
                r.png(heatmap_path)
                r('heatmap(f_matrix, Colv=NA)')
                r('dev.off()')
                print figure.getLink('clustering results figure<br>')
                print heatmap.getLink('heatmap figure <br>')
                '''
                feature = self.params.get("self_feature")
                results = self.build_feature_vector(genome, tracks[0], feature)
                vektor = [results[localKey]['Result'] for localKey in sorted(results.keys())]
                print vektor   
                '''                                                          
            else :
                print 'A feature must be selected in order to build the feature vecotr for tracks.'
        
        parameters = GalaxyRunSpecificFile(['run_parameters.html'],self.jobFile) #just collect the parametes used into a file
        p_path = parameters.getDiskPath(True)
        p_output = open(p_path,'w')
        p_output.write('<html><body>')
        #p_output.write('parameters of this run are :\n')
        p_output.write('<ol>')
        for key in self.params.keys() :
            p_output.write('<li>%s:%s </li>'%(key,self.params[key]))
        p_output.write('</body></html>')
        p_output.close()
        print parameters.getLink('Parameters of this run')
        
    def trackPrepare(self, inputTracks) : #just filter out the -- All subtypes -- tag if it exists
        output = []
        for track in inputTracks :
            if type(track) == str :
                track = track.split(":")
            if track[-1] == "-- All subtypes --" :
                output.append(track[:-1])
            else :
                output.append(track)
        return output

    def computeDistance(self, genome, track1, track2, feature): #direct distance between track1, track2
        '''
        track1 and track2 are two lists like : ['Sequence','Repeating elements','LINE']
        feature specifies how the distance between track1 and track2 is defined 
        '''
        validFeature = DirectDistanceCatalog.getValidAnalyses(genome, track1, track2)[feature]
        analysisDef = validFeature[0] #'bla bla -> PropFreqOfTr1VsTr2Stat' #or any other statistic from the HB collection
        regSpec = self.params.get("region")
        binSpec = self.params.get("binsize")
        #regSpec = 'chr1' #could also be e.g. 'chr1' for the whole chromosome or '*' for the whole genome
        #binSpec = '10m' #could also be e.g.'100', '1k' or '*' for whole regions/chromosomes as bins 
        #genome = 'NCBI36' # path /../../..../genome
        #allRepeats = GalaxyInterface.getSubTrackNames(genome,['Sequence','Repeating elements'],False)
        #GalaxyInterface.run(trackName1, trackName2, question, regSpec, binSpec, genome='NCBI36')
        userBinSource = GalaxyInterface._getUserBinSource(regSpec,binSpec,genome)
        
        result = AnalysisDefJob(analysisDef, track1, track2, userBinSource).run()
        #result er av klassen Results..
        #from gold.result.Results import Results

        mainResultDict = result.getGlobalResult()
        #from PropFreqOfTr1VsTr2Stat:...
        #self._result = {'Track1Prop':ratio,'CountTrack1':c1, 'CountTrack2':c2,'Variance':variance}

        #mainValueOfInterest = mainResultDict['Variance']
        return mainResultDict[validFeature[1]]

    def constructDistMatrix(self, genome, tracks, feature, extra_feature="default"): #construct the distance matrix used in pair_distance case
        '''
        Need the use of extra_feature because the intersect/union ratio cannot be used as the distance between tracks.
        But the (cov. por. intersection) over (cov. por1 * cov. por2) ratio can be directly used as the distance
        '''
        l = len(tracks)
        matrix = zeros((l,l))
        for i in range(l) :
            for j in range(l):
                if i < j :
                    if extra_feature == "1 minus the ratio" :
                        matrix[i,j] = 1 - self.computeDistance(genome, tracks[i], tracks[j], feature)
                        matrix[j,i] = matrix[i,j]
                    elif extra_feature == "1 over the ratio" :
                        matrix[i,j] = 1/self.computeDistance(genome, tracks[i], tracks[j], feature)
                        matrix[j,i] = matrix[i,j]
                    else :
                        matrix[i,j] = self.computeDistance(genome, tracks[i], tracks[j], feature)
                        matrix[j,i] = matrix[i,j] 
        return matrix

    def extract_feature(self, genome, track, ref, option) : 
        '''
        this function return the relation of clusterTrack to referenceTrack
        option is the statistical function used, should be named feature
        track, ref is clusterTrack and referenceTrack
        '''
        validFeature = FeatureCatalog.getFeaturesFromTracks(genome,track,ref)[option] #validFeature contains analysisDef and the key to get the needed number from the global result
        analysisDef = validFeature[0] #or any other statistic from the HB collection
        regSpec = self.params.get("region")
        binSpec = self.params.get("binsize")
        #regSpec = 'chr1' #could also be e.g. 'chr1' for the whole chromosome or '*' for the whole genome
        #binSpec = '10m' #could also be e.g.'100', '1k' or '*' for whole regions/chromosomes as bins 
        #genome = 'NCBI36'
        userBinSource = GalaxyInterface._getUserBinSource(regSpec,binSpec,genome)
        result = AnalysisDefJob(analysisDef, track, ref, userBinSource).run()
        mainResultDict = result.getGlobalResult()
        return mainResultDict[validFeature[1]]
        #return mainResultDict['1inside2']

    def construct_feature_matrix_using_reftracks(self, genome, cTracks, rTracks, options) : #rTracks and options has the same length 
        c = len(cTracks)
        r = len(rTracks)
        output = zeros((c, r))
        for i in range(c) :
            for j in range(r) :
                output[i,j] = self.extract_feature(genome,cTracks[i],rTracks[j],options[j])
        return output
    
    def build_feature_vector(self, genome, ctrack, feature):
        '''
        this function create a feature vector for ctrack
        feature specifies how the vector is constructed
        '''
        validFeature = LocalResultsAsFeaturesCatalog.getValidAnalyses(genome, ctrack, [])[feature]
        analysisDef = validFeature[0]
        regSpec = self.params.get("region")
        binSpec = self.params.get("binsize")
        userBinSource = GalaxyInterface._getUserBinSource(regSpec,binSpec,genome)
        result = AnalysisDefJob(analysisDef, ctrack, [], userBinSource).run()
        return [result[localKey][validFeature[1]] for localKey in sorted(result.keys())]
    
    def construct_feature_matrix(self, genome, cTracks, option):
        '''
        option mean how the feature vector is created for every track in cTracks
        this matrix is for the self feature case
        '''
        f_matrix = self.build_feature_vector(genome, cTracks[0], option)
        for i in range(1,len(cTracks)) :
            f_matrix = vstack((f_matrix,self.build_feature_vector(genome, cTracks[i], option)))
        return f_matrix
    
    def getTrackFormat(self,genome,trackName) : #trackName here is a list of directories which is path of track
        temp = trackName.split(":")
        if temp[-1] == "-- All subtypes --" :
            trackName = temp[:-1]
        else :
            trackName = temp
        #trackName = self.trackPrepare(trackName)
        return TrackInfo(genome,trackName).trackFormatName
    
    def getValidFeatures(self,genome,ctrack,rtrack): #valid feature for every pair ctrack, rtrack
        return FeatureCatalog.getFeaturesFromTracks(genome,ctrack,rtrack)
        
    def getDirectDistanceFeatures(self, genome, ctrack1, ctrack2) : #used in direct distance case
        return DirectDistanceCatalog.getValidAnalyses(genome, ctrack1, ctrack2)
    
    def getLocalResultsAsFeaturesCatalog(self,genome, ctrack):
        return LocalResultsAsFeaturesCatalog.getValidAnalyses(genome, ctrack, [])
    
    def getExpandedTrackNameFromInTrackName(self, inTrackName, outTrackName,uniqueStaticId, genome, upFlank, downFlank):
        GalaxyInterface.expandBedSegmentsFromTrackName(inTrackName, outTrackName, uniqueStaticId, genome, upFlank, downFlank)
        return outTrackName
    
def getController(transaction = None, job = None):
    return ClusteringToolController(transaction, job)
