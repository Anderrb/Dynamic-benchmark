# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#note cannot import HB.GalaxyInterface here due to rpy threading issue

from urllib import quote, unquote
#import re

def getDataFilePath(root, id):
    hashDir = '/%03d/' % (int(id) / 1000)
    return root + hashDir + 'dataset_' + str(id) + '.dat'

def fileToParams(filename):
    params = {}
    for line in open(filename, 'r'):
        try:
            #print line
            line = line.strip()
            fields = line.split('\t')
            params[fields[0]] = unquote(fields[1]).replace('\r','')
        except:
            continue
    return params


#defaultFileTypes = ['bed','point.bed','category.bed','marked.bed','wig','point.wig','meansd.wig','mapping.wig','targetcontrol.wig','customtrack', 'microarray', 'hbfunction']

class GalaxyWrapper:
    _data_file_root = None
    trans = None
    params = {}
    
    def __init__(self, trans):
        self.trans = trans
        self.setDataFileRoot(trans.environ['paste.config']['here'] + '/' + trans.environ['paste.config']['file_path'])
        for key in trans.request.params.keys():
            try:
                self.params[key] = str(trans.request.params[key]) if trans.request.params[key] != None else None
            except:
                self.params[key] = trans.request.params[key]

    def setDataFileRoot(self, root):
        self._data_file_root = root

    def getDataFilePath(self, id):
        hashDir = '/%03d/' % (int(id) / 1000)
        return self._data_file_root + hashDir + 'dataset_' + str(id) + '.dat'

    def getHistory(self, ext):
        datasets = []
        for dataset in self.trans.get_history().active_datasets:
            if dataset.extension in ext:
                datasets.append(dataset)
        return datasets

    def getValidRScripts(self):
        datasets = []
        try:
            for dataset in self.getHistory(['R']):
                rfilename = self.getDataFilePath(dataset.dataset_id)
                qid = '[scriptFn:=' + rfilename.encode('hex_codec') + ':] -> CustomRStat'
                #if hyper.isRScriptValid(tracks[0].definition(), tracks[1].definition(), qid):
                datasets.append(dataset)
        except AttributeError:
            pass
        return datasets

    def optionsFromHistory(self, exts, sel = None):
        html = ''
        for dataset in self.trans.get_history().active_datasets:
            if exts == None or dataset.extension in exts:
                name = dataset.name.replace('[', '(')
                name = name.replace(']', ')')
                val = 'galaxy,' + str(dataset.dataset_id) + ',' + dataset.extension + ',' + str(dataset.hid) + quote(' - ' + name)
                html += '<option value="%s" %s>%d - %s</option>\n' % (val, selected(val, sel), dataset.hid, name)
        return html

    def optionsFromHistoryFn(self, exts, sel = None):
        html = ''
        vals = []
        for dataset in self.trans.get_history().active_datasets:
            if exts == None or dataset.extension in exts:
                name = dataset.name.replace('[', '(')
                name = name.replace(']', ')')
                val = ':'.join(['galaxy', dataset.extension, self.getDataFilePath(dataset.dataset_id), str(dataset.hid) + quote(' - ' + name)])
                vals.append(val)
                html += '<option value="%s" %s>%d - %s</option>\n' % (val, selected(val, sel), dataset.hid, name)
        return html, vals

    def getUserName(self):
        user = self.trans.get_user()
        return user.email if user else ''

    def getUserIP(self):
        return self.trans.environ['REMOTE_ADDR']
        
    def getLoginKey(self):
        session = self.trans.get_galaxy_session()
        key = session.session_key if session.is_valid and session.user_id else None
        return key


trackListCache = {}

class TrackWrapper:
    has_subtrack = False
    def __init__(self, name, api, preTracks, galaxy, datasets, genome = ''):
        params = galaxy.params
        self.api = api
        self.galaxy = galaxy
        self.datasets = datasets
        self.nameMain = name
        self.nameFile = self.nameMain + 'file'
        self.nameState = self.nameMain + '_state'
        self.state = params.get(self.nameState)

        if params.has_key(name) and not params.has_key(self.nameLevel(0)):
            parts = params[name].split(':')
            for i in range(len(parts)):
                self.setValueLevel(i, parts[i])
        
        #self.preTracks = preTracks
        self.preTracks = []
        self.extraTracks = []
        #self.extraTracks.append(('UCSC tracks', 'ucsc', False))
        if len(datasets) > 0:
            self.extraTracks.append(('-- From history (bed, wig) --', 'galaxy', False))
        self.extraTracks += preTracks
        #self.main = params.get(self.nameMain)
        #if self.main == '-':
        #    self.main = None
        self.main = self.valueLevel(0)
        self.file = params.get(self.nameFile)
        if not self.file and len(self.datasets) > 0:
            self.file = 'galaxy,' + str(self.datasets[0].dataset_id) + ',' + self.datasets[0].extension + ',' + self.datasets[0].name
        self.tracks = []
        self.genome = genome
        self.numLevels = len(self.asList())

    def getState(self):
        return self.state if self.state else ''

    def fetchTracks(self):
        for i in range(0, self.numLevels + 1):
            self.getTracksForLevel(i)
        self.numLevels = len(self.tracks)
   
    def hasSubtrack(self):
        #sub = self.valueLevel(self.numLevels - 1)
        #print self.has_subtrack, sub, len(self.tracks), self.numLevels, self.valueLevel(self.numLevels - 1)
        ldef = len(self.definition())
        if len(self.tracks) > ldef:
            if len(self.tracks[ldef]) > 0:
                return True
        return False

    def nameLevel(self, level):
        return self.nameMain + '_' + str(level)

    def valueLevel(self, level):
        val = self.galaxy.params.get(self.nameLevel(level))
        #if val in (None, '-'):
        #    return None
        return val

    def setValueLevel(self, level, val):
        self.galaxy.params[self.nameLevel(level)] = val

    def asList(self):
        vals = []
        for i in range(0, 10):
            val = self.valueLevel(i)
            if val != None and val != '-':
                vals.append(val)
            else:
            #    vals.append(None)
                break
        return vals

    def asString(self):
        vals = self.asList()
        return ':'.join(vals)

    def selected(self):
        #self.hasSubtrack()
        #print len(self.tracks[len(self.definition())]), self.hasSubtrack()
        return (len(self.definition()) > 1 and not self.hasSubtrack()) or self.valueLevel(0) == '' 

    def definition(self):
        #if self._definition:
        #    return self._definition
        arr = [self.main]
        if self.main == 'galaxy' and self.file:
            f = self.file.split(',')
            path = self.galaxy.getDataFilePath(f[1])
            #print path
            arr.append(str(f[2]))
            arr.append(str(path))
            #arr.append(f[3])
            #print f[3]
            arr.append(str(unquote(f[3])))
        elif self.valueLevel(0) == '':
            arr = []
        else:
            arr = self.asList()
        return arr

    def getTracksForLevel(self, level):
        #if level < len(self.tracks):
        #    return self.tracks[level]
        self.has_subtrack = False
        tracks = None
        if level == 0:
            tracks = self.mainTracks()
        else:
            trk = []
            for i in range(0, level):
                val = self.valueLevel(i)
                if val != None and val != 'galaxy':
                    trk.append(val)
                else:
                    trk = []
                    break
            if len(trk) > 0 and val not in ['', '-']:
                try:
                    trkHash = ":".join(trk)
                    #print trkHash
                    if trkHash in trackListCache:
                        tracks = trackListCache[trkHash]
                    else:
                        #tracks, self.state = self.api.getSubTrackNames(self.genome, trk, False, self.galaxy.getUserName(),self.state)
                        tracks = self.api.getSubTrackNames(self.genome, trk, False, self.galaxy.getUserName())
                        trackListCache[trkHash] = tracks
                        
                    #print tracks
                except OSError, e:
                    #print e, level, i
                    self.setValueLevel(i, None)
                    self.has_subtrack = False
                    if e.errno != 2:
                        raise e
                if tracks and len(tracks) > 0:
                    self.has_subtrack = True
                    #tracks = None
                #if tracks and len(tracks) == 1 and not tracks[0][1]:
                #    tracks = None
        if tracks == None:
            self.setValueLevel(level, None)
        else:
            self.tracks.append(tracks)
        return tracks

    def mainTracks(self):
        tracks = self.api.getMainTrackNames(self.genome, self.preTracks, self.extraTracks, self.galaxy.getUserName())
#        for i in range(len(tracks)):
#            if tracks[i][1] == self.main:
#                tracks[i] = (tracks[i][0], tracks[i][1], True)
        return tracks

    #return self.api.getMainTrackNames(self.preTracks, [('-- From history (bed-file) --', 'bed', False), ('-- From history (wig-file) --', 'wig', False)])



def selected(opt, sel):
    return ' selected="selected" ' if opt == sel else ''

def checked(opt, sel):
    return ' checked="checked" ' if opt == sel else ''

def disabled(opt, sel):
    return ' disabled="disabled" ' if opt == sel else ''

def _disabled(opt, sel):
    return ' disabled="disabled" ' if opt != sel else ''

def optionListFromDatasets(datasets, exts = None, sel = None):
    list = []
    for dataset in datasets:
        if exts == None or dataset.extension in exts:
            val = 'galaxy,' + str(dataset.dataset_id) + ',' + dataset.extension
            txt = '%d: %s [%s]' % (dataset.hid, dataset.name, val)
            tup = (txt, val, False)
            list.append(tup)
    return list

def optionsFromDatasets(datasets, exts = None, sel = None):
    html = ''
    for dataset in datasets:
        if exts == None or dataset.extension in exts:
            val = 'galaxy,' + str(dataset.dataset_id) + ',' + dataset.extension
            html += '<option value="%s" %s>%d: %s [%s]</option>\n' % (val, selected(val, sel), dataset.hid, dataset.name, val)
    return html

def optionLinksFromDatasets(rel, datasets, exts = None, sel = None):
    html = ''
    for dataset in datasets:
        if exts == None or dataset.extension in exts:
            val = 'galaxy,' + str(dataset.dataset_id) + ',' + dataset.extension
            html += '<a href="javascript:;" rel="%s" rev="%s" class="%s option">%d: %s [%s]</a>\n' % (rel, val, selected(val, sel), dataset.hid, dataset.name, val)
            #html += '<label class="option"><input type="radio" name="%s" value="%s" %s>%d: %s [%s]</label>\n' % (rel, val, checked(val, sel), dataset.hid, dataset.name, val)
    return html


def joinAttrs(attrs):
    str = ''
    for k, v in attrs.items():
        str += k + '="' + v + '" '
    return str

class Element:
    def __init__(self):
        pass
    def setHTML(self, html):
        self.html = html
    def getHTML(self):
        self.make()
        return self.html;
    def make(self):
        pass


class SelectElement(Element):
    def __init__(self, id = None, options = [], selected = None):
        Element.__init__(self)
        self.id = id
        self.options = options
        self.attrs = {}
        if self.id:
            self.attrs['id'] = self.id
            self.attrs['name'] = self.id    
        self.selectedOption = selected
        self.onChange = "this.form.action = ''; this.form.submit();"

    def make(self):
        html = '<select ' + joinAttrs(self.attrs) + '>'
        for opt in self.options:
#            if opt[1] == '':
#                val = '*'
            html += '<option value="%s" %s>%s</option>' % (opt[1], ('selected' if opt[2] or (self.selectedOption != None and opt[1] == self.selectedOption) else ''), opt[0])
        html += '</select>\n'
        self.setHTML(html)

    def getScript(self):
        self.script = '<script type="text/javascript">\n $(document).ready(function () {'
        self.script += "$('#%s').change(function (){%s})" % (self.attrs['id'], self.onChange)
        self.script += '}); \n</script>\n'
        return self.script


class TrackSelectElement(SelectElement):
    def __init__(self, track, level):
        SelectElement.__init__(self)
        self.id = track.nameLevel(level)
        self.attrs['id'] = self.id
        self.attrs['name'] = self.id
        self.options = [('----- Select ----- ', '-', False)]
        self.selectedOption = track.valueLevel(level)
        self.onChange = "try{$('#" + track.nameLevel(level + 1) + "').val('')} catch(e){} " + self.onChange
        opts = track.getTracksForLevel(level)
        if opts:
            self.options.extend(opts)


