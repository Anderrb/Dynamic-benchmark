# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import sys, os
#sys.path.append("/web/lookalike/new_hb_develop/trunk")
#sys.path.append("/web/lookalike/python/lib/python2.5/site-packages")
#sys.path.append("/web/lookalike/Komodo-PythonRemoteDebugging-4.3.2-17463-linux-x86")
#from gold.application.GalaxyInterface import *

from galaxy.web.base.controller import *
import logging, sets, time

log = logging.getLogger( __name__ )

import traceback
from multiprocessing import Process, Pipe, Array, Queue

class HyperController( BaseController ):
    #@staticmethod
    #def __index_pipe(pipe, trans, tool):
    #    response = None
    #    try:
    #        #print 'forked index'
    #        from gold.application.GalaxyInterface import GalaxyInterface
    #        template_mako = '/hyperbrowser/' + tool + '.mako'
    #        response = trans.fill_template(template_mako, trans=trans, hyper=GalaxyInterface)
    #    except Exception, e:
    #        response = '<html><body><pre>\n' + str(e) + ':\n' + traceback.format_exc() + '\n</pre></body></html>'
    #    pipe.send(response)
    #    pipe.close()        

    @staticmethod
    def __index_shm(response, trans, tool):
        exc_info = None
        try:
            #print 'forked index'
            from gold.application.GalaxyInterface import GalaxyInterface
            template_mako = '/hyperbrowser/' + tool + '.mako'
            toolController = None
            try:
                toolModule = __import__('hyperbrowser.' + tool, globals(), locals(), ['getController'])
                #reload(toolModule)
                toolController = toolModule.getController(trans)
            except Exception, e:
                print e
                exc_info = sys.exc_info()
                pass
            
            html = trans.fill_template(template_mako, trans=trans, hyper=GalaxyInterface, control=toolController)
            response.value = html
        except Exception, e:
            response.value = '<html><body><pre>\n'
            if exc_info:
                response.value += str(e) + ':\n' + ''.join(traceback.format_exception(exc_info[0],exc_info[1],exc_info[2])) + '\n\n'
            response.value += str(e) + ':\n' + traceback.format_exc() + '\n</pre></body></html>'

    @staticmethod
    def __json(response, trans, module, kwd):
        try:
            toolController = None
            toolModule = __import__('hyperbrowser.' + module, globals(), locals(), ['getController'])
            toolController = toolModule.getController(trans)            
            response.put(toolController.jsonCall(kwd))
        except Exception, e:
            response.put({'exception': str(e), 'backtrace': traceback.format_exc()})


    #@web.expose
    #def index2(self, trans, mako = 'analyze', **kwd):
    #    pipe, child_pipe = Pipe()
    #    proc = Process(target = self.__index_pipe, args = (child_pipe, trans, mako))
    #    proc.start()
    #    response = pipe.recv()
    #    pipe.close()
    #    proc.join()
    #    return response

    @web.expose
    def index(self, trans, mako = 'analyze', **kwd):
        response = Array('c', 2 * 1048576, lock=False)
        if isinstance(mako, list):
            mako = mako[0]
        proc = Process(target=self.__index_shm, args=(response,trans,mako))
        proc.start()
        proc.join(120)
        if proc.is_alive():
            proc.terminate()
            print 'fork did not join in 120 sec, terminated.'
        html = response.value
        response = None
        return html

    @web.json
    def json(self, trans, module = None, **kwd):
        response = Queue()
        proc = Process(target=self.__json, args=(response,trans,module,kwd))
        proc.start()
        dict = response.get(True, 120)
        proc.join(30)
        if proc.is_alive():
            proc.terminate()
            print 'json fork did not join; terminated.'
        response = None
        return dict

    @web.json
    def check_job(self, trans, pid = None, filename = None):
        # Avoid caching
        trans.response.headers['Pragma'] = 'no-cache'
        trans.response.headers['Expires'] = '0'
        rval = {'running': True}
        try:
            os.kill(int(pid), 0)
        except OSError:
            rval['running'] = False
        
        return rval

    @web.expose
    def import_result(self, trans, **kwd):
        return 'OK'
