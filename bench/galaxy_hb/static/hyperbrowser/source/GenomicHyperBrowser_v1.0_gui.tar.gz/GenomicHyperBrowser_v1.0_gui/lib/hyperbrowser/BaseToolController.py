# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.
#

import sys
from gold.application.GalaxyInterface import GalaxyInterface
from hyper_gui import *

class BaseToolController(object):
    def __init__(self, trans = None, job = None):
        if trans:
            self.openTransaction(trans)
        elif job:
            self.openJobParams(job)

    def openTransaction(self, trans):
        self.transaction = trans
        self.galaxy = GalaxyWrapper(trans)
        self.params = self.galaxy.params

    def openJobParams(self, file):
        self.jobFile = file
        self.params = fileToParams(self.jobFile)
        if self.params.has_key('tool_name'):
            self.params['tool_id'] = self.params['tool_name']

    def action(self):
        'to be called from mako'
        pass

    def execute(self):
        'to be called from job-script'
        pass

    def stdoutToHistory(self):
        sys.stdout = open(self.jobFile, "w", 0)

    def stdoutToFile(self, file):
        sys.stdout = open(file, "w", 0)
    
    def isPublic(self):
        return False
    
    def userHasFullAccess(self):
        return self.isPublic() or GalaxyInterface._userHasFullAccess(self.galaxy.getUserName())
    
    def getGenomeElement(self):    
        return SelectElement('dbkey', GalaxyInterface.getAllGenomes(), self.getGenome())

    def getGenome(self):
        if self.transaction.request.POST.has_key('dbkey'):
            return str(self.transaction.request.POST['dbkey'])
        return self.params.get('dbkey', GalaxyInterface.getAllGenomes()[0][1])

    def getTrackElement(self, id, label):
        element = TrackWrapper(id, GalaxyInterface, [], self.galaxy, [], self.getGenome())
        element.fetchTracks()
        element.legend = label
        return element

    def jsonCall(self, args):
        res = {}
        try:
            methodName = args['method']
            if methodName in self.jsonMethods:
                method = getattr(self, methodName)
                res = method(args)
        except Exception, e:
            res['exception'] = str(e)
        return res
