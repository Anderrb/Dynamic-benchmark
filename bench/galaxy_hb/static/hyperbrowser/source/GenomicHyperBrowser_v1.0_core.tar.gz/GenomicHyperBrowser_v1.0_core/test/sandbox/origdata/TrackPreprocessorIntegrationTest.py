# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import profile
import pstats
import unittest
from gold.origdata.GenomeElementSource import GenomeElementSource
from gold.origdata.TrackPreProcessor import TrackPreProcessor
from gold.application.Config import *
def runIntegrationTest():
    #geSource = GenomeElementSource('/Users/sveinung/Documents/HyperBrowser/_hb_new/data/2sSegs.bed', 'NCBI36', ['myregions'])
    #geSource = GenomeElementSource('/Users/sveinung/Documents/HyperBrowser/_hb_new/data/chrMDiffs.wig', 'NCBI36', ['melting2'])
    #print 'hpv'
    #geSource = GenomeElementSource('/titan_home/uag/geirksa/_data/hpv_200kbs.bed', 'NCBI36', ['hpv_200kb'])
    #TrackPreProcessor.process(geSource)
    #print 'tss'
    #geSource = GenomeElementSource('/titan_home/uag/geirksa/_data/allTss.bed', 'NCBI36', ['genes','TSS'])
    #geSource = GenomeElementSource('/titan_home/uag/geirksa/_data/refseqGenes.bed', 'NCBI36', ['genes','whole'])
    #geSource = GenomeElementSource('/titan_home/uag/geirksa/_data/2sSegs.bed', 'NCBI36', ['melting','2state'])
    geSource = GenomeElementSource('/data1/rrresearch/standardizedTracks/NCBI36/bs/2550bs.gff', 'TestGenome', ['test2'])
    
    TrackPreProcessor.process(geSource)

    
if __name__ == "__main__":
    #profile.run( 'runIntegrationTest()' , 'myProf.txt' )
    #p = pstats.Stats('myProf.txt')
    #p.sort_stats('time').print_stats(10) 
    runIntegrationTest()
