from gold.application.RSetup import r
import time
import os
from quick.util.StaticFile import GalaxyRunSpecificFile

#class PvalDistribution(object):
#    def __init__(self, pi0, a=0.5, b=2.5):
#        self._pi0 = pi0
#        self._a = a
#        self._b = b
#        
#    def __iter__(self):
        #while True:
    #        if r.runif(1) < self._pi0:
    #            yield r.runif(1)
    #        else:
    #            yield r.rbeta(1, self._a, self._b)
#            


class ExtremeOrNotSampleGenerator(object):
    'The only thing of interest when doing MC-sampling to estimate a p-value, is to whether a sampled value is more extreme than observation or not.'
    'The probabilty of being more extreme is given by the underlying p-value'
    'This class provides an iterator of True/False to simulate whether a sample was more extreme than observed, initialized with an underlying p-value based on supplied parameters'
    def __init__(self, fromH1, a, b): #a=0.5, b=25): 
        self._fromH1 = fromH1
        self._a = a
        self._b = b
        
        if self._fromH1:
            self._underlyingPval = r.rbeta(1, self._a, self._b)#[0]
        else:
            self._underlyingPval = r.runif(1)#[0]
        #print fromH1, self._underlyingPval   
        
    def __iter__(self):
        'Provides a generator giving True if sample was simulated to be more extreme than observation, else False'
        while True:
            sample = r.runif(1)#[0]
            extreme = (sample < self._underlyingPval)
            #print extreme, sample , self._underlyingPval
            yield extreme
        
class ExtremeSampleCounter(object):
    def __init__(self, extremeOrNotSampleGenerator, maxNumSamples = 1000, h=20, fdrThreshold=0.1):
        'h is here how many extreme samples before stopping sampling according to sequential MC'
        self._extremeOrNotSampleGenerator = extremeOrNotSampleGenerator
        self._h = h
        self._maxNumSamples = maxNumSamples
        self._fdrThreshold = fdrThreshold
        self._extremeCount = 0
        self._notExtremeCount = 0
        self.fdrVal = None
        
    def setFdrThreshold(self, fdrThreshold):
        self._fdrThreshold = fdrThreshold
        
    def getPandQvalsTriple(self):
        return self._extremeOrNotSampleGenerator._underlyingPval, self.getPvalEstimate(), self.fdrVal
    
    def addSamples(self,n):
        count = 0
        for extreme in self._extremeOrNotSampleGenerator:
            #print extreme,
            if extreme:
                self._extremeCount+=1
            else:
                self._notExtremeCount+=1
            count+=1
            if count>=n:
                break
        self.fdrVal = None
        
    def getPvalEstimate(self):
        if self.getTotalNumSamples() == 0:
            return 1.0
        
        return max(self._extremeCount,1) *1.0 / self.getTotalNumSamples()
    
    def enoughExtremeValues(self):
        return self._extremeCount >= self._h
    
    def getTotalNumSamples(self):
        return self._extremeCount + self._notExtremeCount
    
    def isFdrRejected(self):
        return self._fdrThreshold is not None and self.fdrVal is not None and self.fdrVal<=self._fdrThreshold
    
    def isDetermined(self, useH=True, useFdr=True, useMaxNumSamples=True):
        return (useH and self._h is not None and self.enoughExtremeValues() \
            or (useFdr and self.isFdrRejected()) \
            or (useMaxNumSamples and self._maxNumSamples is not None and self.getTotalNumSamples() >= self._maxNumSamples) )
    
    def __cmp__(self, other):
        return cmp(self._extremeOrNotSampleGenerator._underlyingPval, other._extremeOrNotSampleGenerator._underlyingPval)
    
class MultipleTestCollection(object):
    def __init__(self, numH0Tests, numH1Tests,maxNumSamples, h, fdrThreshold,a,b ):#, fdrThreshold=0.2):
        self._numH0Tests = numH0Tests
        self._numH1Tests = numH1Tests
        #self._fdrThreshold = fdrThreshold
        self._sampleCounters = []
        for i in range(numH0Tests):
            self._sampleCounters.append( ExtremeSampleCounter(ExtremeOrNotSampleGenerator(False,a,b), maxNumSamples, h, fdrThreshold ) )
        for i in range(numH1Tests):
            self._sampleCounters.append( ExtremeSampleCounter(ExtremeOrNotSampleGenerator(True,a,b) , maxNumSamples, h, fdrThreshold ) )
        
    def setFdrThresholdAtAllCounters(self, fdrThreshold):
        for counter in self._sampleCounters:
            counter.setFdrThreshold(fdrThreshold)
            
    def addSamples(self,n):
        for counter in self._sampleCounters:
            if not counter.isDetermined(useFdr=False): #don't stop sampling those under fdr threshold individually (until all are ready..)
                counter.addSamples(n)
                
    def getTotalNumRejected(self):
        return sum(1 if counter.isFdrRejected() else 0 for counter in self._sampleCounters)
        
    def getTotalNumSamples(self):
        return sum(counter.getTotalNumSamples() for counter in self._sampleCounters)
    
    def allTestsAreDetermined(self):
        #fdrVals = self.getFdrVals()
        #stoppedByH = [counter.enoughExtremeValues() for counter in self._sampleCounters]

        #assert len(stoppedByH) == len(fdrVals) 
        #return all( (fdrVals[i]<self._fdrThreshold or stoppedByH[i]) for i in range(len(fdrVals)) )
        self.updateFdrValsOfCounters()
        return all( counter.isDetermined() for counter in self._sampleCounters)
    
    def writeAllPandQVals(self, outF):
        outF.write('#'+'\t'.join(['Underlying p','Estimated p','Estimated q','Num samples']))
        for test in sorted(self._sampleCounters):
            outF.write( '\t'.join(['%.5f'%num for num in test.getPandQvalsTriple()] + [str(test.getTotalNumSamples())]) + os.linesep )

    def makeAllPandQValsFigure(self):
        underlyingP, estimatedP, estimatedQ = zip(*[test.getPandQvalsTriple() for test in sorted(self._sampleCounters)])
        r.plot(r.unlist(underlyingP), ylim=r.unlist([0,1]), type='l', xlab='Tests', ylab='P/Q-value' )
        r.lines(r.unlist(estimatedP), col='red' )
        r.lines(r.unlist(estimatedQ), col='green' )

    def makeNumSamplesFigure(self):
        numSamples = [test.getTotalNumSamples() for test in sorted(self._sampleCounters)]
        r.plot(r.unlist(numSamples), type='l', xlab='Tests', ylab='Num samples' )
                                                            
    def getFdrVals(self):
        adjustMethod = 'fdr'
        pvals = [counter.getPvalEstimate() for counter in self._sampleCounters]
        fdrVals = r('p.adjust')(r.unlist(pvals), adjustMethod)
        if type(fdrVals) in [float,int]:
            fdrVals = [fdrVals]
        return fdrVals
    
    def updateFdrValsOfCounters(self):
        fdrVals = self.getFdrVals()
        for i in range(len(self._sampleCounters)):
            self._sampleCounters[i].fdrVal = fdrVals[i]
            
            
class Simulator(object):
    NUM_SAMPLES_PER_CHUNK = 1
    
    def __init__(self, maxNumSamples, h, fdrThreshold,a,b, postFdrThreshold, galaxyFn=None):
        self._h = h
        self._maxNumSamples = maxNumSamples
        self._fdrThreshold = fdrThreshold
        self._postFdrThreshold = postFdrThreshold
        self._a = a
        self._b = b
        self._galaxyFn = galaxyFn
        
    def singleSimulation(self, numH0, numH1, replicateIndex, verbose=False):
        tests = MultipleTestCollection(numH0, numH1, self._maxNumSamples, self._h, self._fdrThreshold,self._a,self._b)
        while not tests.allTestsAreDetermined():
            tests.addSamples(self.NUM_SAMPLES_PER_CHUNK)
            #if verbose:
                #print tests.getTotalNumSamples()
        #As sampling is now anyway over, we set fdrThreshold to a threshold used after computations are finished (i.e. affects final rejection/acception, but not stopping of samples)
        tests.setFdrThresholdAtAllCounters(self._postFdrThreshold)
        
        #print 'FINALLY, #samples: ',
        if self._galaxyFn is not None:
            if self._h is None:
                scheme = 'Basic'
            elif self._fdrThreshold is None:
                scheme = 'Sequential'
            else:
                scheme = 'McFdr'
            staticFile = GalaxyRunSpecificFile([scheme,str(numH1),str(replicateIndex),'PandQvals.txt'], self._galaxyFn)              
            tests.writeAllPandQVals(staticFile.getFile() )                        
            linkToRaw = staticFile.getLink('Raw p and q-vals') + ' under %s scheme with %i true H1, (replication %i)' % (scheme, numH1, replicateIndex)
            
            figStaticFile = GalaxyRunSpecificFile([scheme,str(numH1),str(replicateIndex),'PandQvals.png'], self._galaxyFn)
            figStaticFile.openRFigure()
            tests.makeAllPandQValsFigure()
            figStaticFile.closeRFigure()
            linkToFig = figStaticFile.getLink(' (p/q-figure) ') + '<br>'

            figNumSamplesStaticFile = GalaxyRunSpecificFile([scheme,str(numH1),str(replicateIndex),'NumSamples.png'], self._galaxyFn)
            figNumSamplesStaticFile.openRFigure()
            tests.makeNumSamplesFigure()
            figNumSamplesStaticFile.closeRFigure()
            linkToNumSamplesFig = figNumSamplesStaticFile.getLink(' (numSamples-figure) ') + '<br>'

            catalogStaticFile = GalaxyRunSpecificFile([str(numH1),'cat.html'], self._galaxyFn)
            catalogStaticFile.writeTextToFile(linkToRaw + linkToFig + linkToNumSamplesFig, mode='a')

                        
        #if verbose:
            #print sorted(tests.getFdrVals())
            #print 'NumS ign Below 0.2: ', sum([1 if t<0.2 else 0 for t in tests.getFdrVals()])
        return tests.getTotalNumSamples(), tests.getTotalNumRejected()
    
    def replicatedSimulations(self, numH0, numH1, numReplications=10):
        numSamples = []
        numRejected = []
        for i in range(numReplications):
            samples, rejected = self.singleSimulation(numH0, numH1, i)
            numSamples.append( samples )
            numRejected.append(rejected)
            
        return sum(numSamples)*1.0/numReplications, sum(numRejected)*1.0/numReplications 
            
    def numSamplesAsFunctionOfNumH1(self, totalNumTests, stepSize=1, numReplications=10):
        samplesForNumH1 = {}
        numRejectedForNumH1 = {}
        for numH1 in range(0,totalNumTests+1,stepSize):
            numH0 = totalNumTests - numH1
            samplesForNumH1[numH1], numRejectedForNumH1[numH1] = self.replicatedSimulations(numH0, numH1, numReplications) #FUNKER DETTE?

            #if self._galaxyFn is not None:
            #    catalogStaticFile = GalaxyRunSpecificFile([str(numH1),'cat.html'], self._galaxyFn)
            #    print catalogStaticFile.getLink( 'Tests with #True H1s=%i' % numH1 ), '<br>'
                
                #catalogStaticFile.writeTextToFile(link, mode='a')            

        sortedKeys = sorted(samplesForNumH1.keys()) 
        print 'numH1s: ', ','.join([str(key) for key in sortedKeys])
        print 'numSamples: ', ','.join([str(samplesForNumH1[key]) for key in sortedKeys])
        #r.plot(r.unlist(sortedKeys), r.unlist([samplesForNumH1[key] for key in sortedKeys]))
        return sortedKeys, [samplesForNumH1[key] for key in sortedKeys], [numRejectedForNumH1[key] for key in sortedKeys]
        
class Experiment:
    
    @staticmethod
    def compareCutoffSchemes(maxNumSamples, h, fdrThreshold, totalNumTests, stepSize, numReplications,a,b, galaxyFn=None):
        prevTime= time.time()
        print '<PRE>'
        print 'Comparing cutoff schemes with parameters: maxNumSamples=%i, h=%i, fdrThreshold=%.2f, totalNumTests=%i, stepSize=%i, numReplications=%i' % (maxNumSamples, h, fdrThreshold, totalNumTests, stepSize, numReplications)
        print 'Minimum achieveable p-value is %.5f, which gives minimum Bonferroni-corrected p-value of %.5f (compares to a fdr threshold of %.2f)' % (1.0/maxNumSamples, (1.0/maxNumSamples)*totalNumTests, fdrThreshold)
        
        #estimate time use:
        Simulator(maxNumSamples, None, None,a,b,fdrThreshold).numSamplesAsFunctionOfNumH1( 1, 1, 1)
        baseMeasure = time.time() - prevTime
        numSteps = len(range(0,totalNumTests+1,stepSize))
        withOnlyMaxNumEstimate = baseMeasure * totalNumTests * numSteps * numReplications
        #print 'Estimated running time: between %i and %i seconds.' % (withOnlyMaxNumEstimate, withOnlyMaxNumEstimate*3)
        print 'Estimated running time: around %i seconds.' % (withOnlyMaxNumEstimate)
        
        sortedKeys, onlyMaxCutoff, onlyMaxNumRejected = Simulator(maxNumSamples, None, None,a,b,fdrThreshold, galaxyFn).numSamplesAsFunctionOfNumH1( totalNumTests, stepSize, numReplications)
        sortedKeys, seqMcCutoff, seqMcNumRejected = Simulator(maxNumSamples, h, None,a,b,fdrThreshold, galaxyFn).numSamplesAsFunctionOfNumH1(totalNumTests, stepSize, numReplications)
        sortedKeys, mcFdrCutoff, mcFdrNumRejected = Simulator(maxNumSamples, h, fdrThreshold,a,b,fdrThreshold, galaxyFn).numSamplesAsFunctionOfNumH1(totalNumTests, stepSize, numReplications)
        maxY = max( max(s) for s in [onlyMaxCutoff, seqMcCutoff, mcFdrCutoff])
        #minY = min( min(s) for s in [onlyMaxCutoff, seqMcCutoff, McFdrCutoff])
        minY=0

        print 'Time spent: ',time.time() - prevTime, ' secs'
        print '</PRE>'
        
        #plotStaticFile.getDiskPath(True)
        if galaxyFn is not None:
            plotStaticFile = GalaxyRunSpecificFile(['mainPlot.png'],galaxyFn)
            for numH1 in range(0,totalNumTests+1,stepSize):
                catalogStaticFile = GalaxyRunSpecificFile([str(numH1),'cat.html'], galaxyFn)
                print catalogStaticFile.getLink( 'Tests with #True H1s=%i' % numH1 ), '<br>'

            plotStaticFile.openRFigure()
            #r.png(filename=plotFn, height=600, width=800, units='px', pointsize=12, res=72)
            r.plot(r.unlist(sortedKeys), r.unlist(onlyMaxCutoff), ylim=r.unlist([minY,maxY]), type='l', xlab='Number of true H1s', ylab='Total MC samples' )
            r.lines(r.unlist(sortedKeys), r.unlist(seqMcCutoff), col='red' )
            r.lines(r.unlist(sortedKeys), r.unlist(mcFdrCutoff), col='green' )
            #r('dev.off()')
            plotStaticFile.closeRFigure()

            print plotStaticFile.getLink('View main plot') + ' of sumSamples as function of #H1s.', '<br>'

            numRejectedPlotStaticFile = GalaxyRunSpecificFile(['secondaryPlot.png'],galaxyFn)
            numRejectedPlotStaticFile.openRFigure()
            #r.png(filename=plotFn, height=600, width=800, units='px', pointsize=12, res=72)
            r.plot(r.unlist(sortedKeys), r.unlist(onlyMaxNumRejected), ylim=r.unlist([0,totalNumTests]), type='l', xlab='Number of true H1s', ylab='Num rejected tests' )
            r.lines(r.unlist(sortedKeys), r.unlist(seqMcNumRejected), col='red' )
            r.lines(r.unlist(sortedKeys), r.unlist(mcFdrNumRejected), col='green' )
            r.lines(r.unlist(sortedKeys), r.unlist(sortedKeys), col='black', lty='dotted' ) #As this corresponds to perfect estimation..
            #r('dev.off()')
            numRejectedPlotStaticFile.closeRFigure()

            print numRejectedPlotStaticFile.getLink('View secondary plot') + ' of #true H1s vs #tests rejected.', '<br>'
        
        #r.show()
        
#Experiment.compareCutoffSchemes(1000,20,0.1,100,5,5,0.5,25)
#Experiment.compareCutoffSchemes(1000,20,0.1,100,5,1)
#Experiment.compareCutoffSchemes(1000,20,0.1,10,5,10)
#Experiment.compareCutoffSchemes(1000,20,0.1,1,1,1,0.5,25, False)
#1+''
#Simulator.numSamplesAsFunctionOfNumH1(10,1,1)
#print '95,5: ',Simulator.replicatedSimulations(95,5,10)
#print '5,95: ',Simulator.replicatedSimulations(5,95,10)
#simulate(1,0)

#print 'simulate(95,5)'
#simulate(95,5)
#
#print 'simulate(50,50)'
#simulate(50,50)
#
#print 'simulate(5,95)'
#simulate(5,95)
        
