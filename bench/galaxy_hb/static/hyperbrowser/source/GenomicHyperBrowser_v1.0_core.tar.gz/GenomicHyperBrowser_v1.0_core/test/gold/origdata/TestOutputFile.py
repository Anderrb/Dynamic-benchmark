# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import unittest
import os
import sys
from stat import *
from numpy import memmap
from copy import copy
from gold.origdata.OutputFile import OutputFile
from gold.origdata.GenomeElement import GenomeElement
from test.util.Asserts import AssertList
from test.util.FileUtils import removeFile

sys.stderr = open('/dev/null', 'w')

class Setup:
    def __init__(self, filePrefix, dataType):
        self.path = os.path.dirname(os.tempnam())
        self.filePrefix = filePrefix
        self.dataType = dataType
        self.fn = self.path + os.sep + filePrefix + '.' + dataType
        self.tempfn = self.path + os.sep + 'Temp_' + filePrefix + '.' + dataType
        self._removeFiles()
        
    def __del__(self):
        self._removeFiles()

    def _removeFiles(self):
        removeFile(self.fn)
        removeFile(self.tempfn)
    
class GEList:
    def __init__(self):
        self._starts = []
        self._ends = []
        self._strands = []
        self._vals = []
        self._sources = []

    def __iter__(self):
        self = copy(self)
        self._index = -1
        return self
    
    def next(self):
        self._index += 1
        if self._index >= len(self):
            raise StopIteration
        
        return GenomeElement(start = self._starts[self._index] if self._index<len(self._starts) else None,
                             end = self._ends[self._index] if self._index<len(self._ends) else None,
                             strand = self._strands[self._index] if self._index<len(self._strands) else None,
                             val = self._vals[self._index] if self._index<len(self._vals) else None,
                             source = self._sources[self._index] if self._index<len(self._sources) else None)

    def __len__(self):
        return max(len(self._starts), len(self._ends), len(self._strands), len(self._vals), len(self._sources))
    

class TestOutputFile(unittest.TestCase):
    def setUp(self):
        pass        
        
    def testOpenFileExists(self):
        s = Setup('start', 'int32')
        f = open(s.fn, 'w')
        f.close()
        
        self.assertRaises(IOError, OutputFile, s.path, s.filePrefix, 1)
        s._removeFiles()
        
    def testOpenTempFileExists(self):
        s = Setup('start', 'int32')
        f = open(s.tempfn, 'w+')
        f.write('Text')
        f.close()
        
        of = OutputFile(s.path, s.filePrefix, 1)
        f = open(s.tempfn, 'w+')
        f.seek(0)
        self.assertEqual('', f.readline())
        s._removeFiles()
    #    
    #def testOpenClose(self):
    #    s = Setup('start', 'int32')
    #    
    #    of = OutputFile(s.path, s.filePrefix, 1)
    #    self.assertFalse(os.path.exists(s.fn))
    #    self.assertTrue(os.path.exists(s.tempfn))
    #    self.assertEqual(S_IRWXU|S_IRWXG|S_IRWXO, S_IMODE(os.stat(s.tempfn)[ST_MODE]))
    #
    #    of.close()
    #    self.assertTrue(os.path.exists(s.fn))
    #    self.assertFalse(os.path.exists(s.tempfn))
    #    self.assertEqual(S_IRWXU|S_IRWXG|S_IRWXO, S_IMODE(os.stat(s.fn)[ST_MODE]))

    def _assertWriteElement(self, filePrefix, dataType, contents, assertFunc):
        s = Setup(filePrefix, dataType)
        if filePrefix == 'val':
            valDataType = dataType
        else:
            valDataType = None
            
        geList = GEList()
        geList.__dict__['_' + filePrefix + 's'] = contents
        
        maxLineLen = max([len(el) if type(el)==str else None for el in contents])
        
        of = OutputFile(s.path, s.filePrefix, len(geList), valDataType, 1, maxLineLen)
        for ge in geList:
            of.writeElement(ge)
        of.close()

        self.assertTrue(os.path.exists(s.fn))
        
        fileContents = [el for el in memmap(s.fn, dataType, mode='r')]

        AssertList(contents, fileContents, assertFunc)
        
    def testWriteElement(self):
        self._assertWriteElement('start', 'int32', [1, 5, 7, 10], self.assertEqual)
        self._assertWriteElement('end', 'int32', [2, 7, 8, 12], self.assertEqual)
        self._assertWriteElement('strand', 'bool8', [True, False, False, True], self.assertEqual)
        self._assertWriteElement('val', 'float32', [1.2, 2.3, -2.3, 3.5], self.assertAlmostEqual)
        self._assertWriteElement('val', 'int32', [1, 2, -1, 3], self.assertEqual)
        self._assertWriteElement('source', 'S3', ['1 a','2 a','4 b'], self.assertEqual)
    
    def _assertWrite(self, filePrefix, dataType, contents):
        s = Setup(filePrefix, dataType)

        of = OutputFile(s.path, s.filePrefix, len(contents))
        for i in contents:
            of.write(i)
        of.close()
        
        self.assertTrue(os.path.exists(s.fn))
        fileContents = [i for i in memmap(s.fn, dataType, mode='r')]
        AssertList(contents, fileContents, self.assertAlmostEqual)
    
    def testWrite(self):
        self._assertWrite('leftIndex', 'int32', [0, 2, 5, 10])
        self._assertWrite('rightIndex', 'int32', [2, 5, 7, 12])
        
    def testLen(self):
        s = Setup('start', 'int32')
        size = 123
        of = OutputFile(s.path, s.filePrefix, size)
        self.assertEqual(size, len(of))
    
    def runTest(self):
        self.testOpenClose()
    
if __name__ == "__main__":
    #TestOutputFile().debug()
    unittest.main()
    