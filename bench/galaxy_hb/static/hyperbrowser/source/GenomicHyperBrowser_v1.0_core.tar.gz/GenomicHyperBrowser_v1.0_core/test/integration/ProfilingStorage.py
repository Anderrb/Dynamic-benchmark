# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#!/usr/bin/env python
import os
import sys
import re

#import shelve as safeshelve
import third_party.safeshelve as safeshelve

from gold.util.Profiler import Profiler
from gold.util.CustomExceptions import ShouldNotOccurError
from gold.application.Config import SOURCE_CODE_BASE_DIR

class ProfilingStorage(object):
    STORAGE_FN = SOURCE_CODE_BASE_DIR + '/data/profiles.shelf'

    @staticmethod
    def _getStorage(mode='r'):
        fn = ProfilingStorage.STORAGE_FN
        #if not os.path.exists(os.path.dirname(fn)):
        #    fn = os.path.basename(fn)
        if mode=='c':
            return safeshelve.open(fn, 'c', writeback=True)
        else:
            return safeshelve.open(fn, 'r')
    
    @staticmethod
    def isStored(testName, revision):
        if not os.path.exists(ProfilingStorage.STORAGE_FN):
            return False
        
        storage = ProfilingStorage._getStorage('r')
    
        isStored = False
        if storage.has_key(testName):
            if storage[testName].has_key(str(revision)):
                if any(diskMemo in storage[testName][str(revision)].keys() \
                       for diskMemo in ['False', 'True']):
                    isStored = True
        
        storage.close()
        return isStored
    
    @staticmethod
    def parseAndStoreProfile(stdout, testName, revision, diskMemo):
        offset = 0
        if diskMemo:
            offset = 2
        
        splittedStdout = stdout.split(Profiler.PROFILE_HEADER + os.linesep)
        
        totStats = re.findall('([0-9\.]+)', splittedStdout[offset+1].splitlines()[0])
        funcCalls = totStats[0]
        
        if len(totStats) == 2:
            primCalls = funcCalls
            cpuTime = totStats[1]
        elif len(totStats) == 3:
            primCalls = totStats[1]
            cpuTime = totStats[2]            
        else:
            raise ShouldNotOccurError()
        
        cumProfile = splittedStdout[offset+1].split(Profiler.PROFILE_FOOTER)[0]
        intProfile = splittedStdout[offset+2].split(Profiler.PROFILE_FOOTER)[0]
    
        storage = ProfilingStorage._getStorage('c')

        if not storage.has_key(testName):
            storage[testName] = {}
            
        if not storage[testName].has_key(str(revision)):
            storage[testName][str(revision)] = {}
            
        storage[testName][str(revision)][str(diskMemo)] = {'funcCalls': funcCalls, \
                                                           'primCalls': primCalls, \
                                                           'cpuTime': cpuTime, \
                                                           'cumProfile': cumProfile, \
                                                           'intProfile': intProfile}
        
        storage.close()
    
    @staticmethod
    def printSummary():
        storage = ProfilingStorage._getStorage('r')

        print '--- Profile summary ---' + os.linesep
        for test in sorted(storage.keys()):
            print test + ':' + os.linesep
            print '\t\t\tNot memoized on disk\t\t\t\t\t\t\tMemoized on disk'
            print '\t\t'.join(['SVN Revision'] + ['Function calls','Primitive calls','CPU Time']*2)
            for rev in sorted(storage[test].keys()):
                cols = [''] * 7
                cols[0] = rev
                for diskMemo in storage[test][rev]:
                    offset = 1
                    if diskMemo == 'True':
                        offset = 4
                    cols[offset] = storage[test][rev][diskMemo]['funcCalls']
                    cols[offset+1] = storage[test][rev][diskMemo]['primCalls']
                    cols[offset+2] = storage[test][rev][diskMemo]['cpuTime']
                print '\t\t\t'.join(cols)
                    
            print os.linesep, '-'*153, os.linesep
        storage.close()
    
    @staticmethod
    def printProfiling(testName, revision, diskMemo):
        storage = ProfilingStorage._getStorage('r')

        if storage.has_key(testName):
            if storage[testName].has_key(str(revision)):
                if storage[testName][str(revision)].has_key(str(diskMemo)):            
                    print os.linesep + testName + ':' + os.linesep

                    print Profiler.PROFILE_HEADER
                    print storage[testName][str(revision)][str(diskMemo)]['cumProfile']
                    print Profiler.PROFILE_FOOTER
                    print
                    print Profiler.PROFILE_HEADER
                    print storage[testName][str(revision)][str(diskMemo)]['intProfile']
                    print Profiler.PROFILE_FOOTER
                    
                    storage.close()    
                    return
        
        storage.close()
        print 'Error: Profile not available: ', testName, revision, diskMemo

    @staticmethod
    def getSvnRevision():
        for line in os.popen('svn status -u'):
            rev = re.findall('([0-9]+)', line)
            #print line, rev
            if rev != []:
                if line.startswith('Status'):
                    return int(rev[0])
                else:
                    if not 'shelf' in line and not 'shelve' in line:
                        #Not equal to checked-in version
                        return None
                
if __name__ == "__main__":
    if len(sys.argv) not in [2, 4]:
        print 'Syntax: python ProfilingStorage.py summary'
        print '        python ProfilingStorage.py testMethodName revision memoized'
        print '  (e.g) python ProfilingStorage.py TestStatistics.testCountStat 640 False'
        sys.exit(0)
        
    testName = sys.argv[1]
    
    if testName.lower() == 'summary':
        ProfilingStorage.printSummary()
    else:
        ProfilingStorage.printProfiling(sys.argv[1], int(sys.argv[2]), eval(sys.argv[3]))
