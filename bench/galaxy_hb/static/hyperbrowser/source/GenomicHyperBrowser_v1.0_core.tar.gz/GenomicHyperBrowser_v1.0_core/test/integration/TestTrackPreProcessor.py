# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#!/usr/bin/env python
import unittest
import os
import sys
from subprocess import call

from gold.util.CommonFunctions import createDirPath
from quick.origdata.AllTracksPreProcessor import AllTracksPreProcessor
from gold.origdata.PreProcessAllTracksJob import PreProcessAllTracksJob
from test.integration.ProfiledIntegrationTest import ProfiledIntegrationTest

AllTracksPreProcessor.PASS_ON_EXCEPTIONS = True

class TestTrackPreProcessor(ProfiledIntegrationTest):
    def _preProcess(self, trackName):
        genome = 'TestGenome'
        trackName = ['GESourceTracks'] + trackName
        self._removeDir(createDirPath(trackName, genome, '', False), trackName)
        self._removeDir(createDirPath(trackName, genome, '', True), trackName)
        #self._runWithProfiling('AllTracksPreProcessor.process(' + repr(genome) + ',' + repr(trackName) + ')',\
                               #globals(), locals())
        allTracksJob = PreProcessAllTracksJob(genome, trackName)
        self._runWithProfiling('allTracksJob.process()', globals(), locals())
#        self.assertFalse( any([ fn.startswith('Temp') for fn in os.listdir(procDir + 'chr21') ]) )
        self._storeProfile()

    def _removeDir(self, procDir, trackName):
        self.assertTrue(procDir.endswith(os.sep + trackName[-1] + os.sep))
        if os.path.exists(procDir):
            call('rm -R ' + procDir, shell=True)

    def testPreProcessBed(self):
        self._preProcess(['StdBedGenomeElementSource'])

    def testPreProcessBedPoint(self):
        self._preProcess(['PointBedGenomeElementSource'])
        
    def testPreProcessBedCategory(self):
        self._preProcess(['BedCategoryGenomeElementSource'])
        
    def testPreProcessBedMarked(self):
        self._preProcess(['BedMarkedGenomeElementSource'])
        
    def testPreProcessFasta(self):
        self._preProcess(['FastaGenomeElementSource'])
        
    def testPreProcessGff(self):
        self._preProcess(['GffGenomeElementSource'])

    def testPreProcessMicroarray(self):
        self._preProcess(['BaseMicroarrayGenomeElementSource'])

    def testPreProcessWigBed(self):
        self._preProcess(['WigBedGenomeElementSource'])

    def testPreProcessWigBedMeanSd(self):
        self._preProcess(['WigBedMeanSdGenomeElementSource'])
        
    def testPreProcessWigBedMapping(self):
        self._preProcess(['WigBedMappingGenomeElementSource'])

    def testPreProcessWigBedTargetControl(self):
        self._preProcess(['WigBedTargetControlGenomeElementSource'])

    def testPreProcessWigBedPoint(self):
        self._preProcess(['WigPointBedGenomeElementSource'])

    def testPreProcessWigBedSorted(self):
        self._preProcess(['WigBedGenomeElementSource_sorted'])

    def testPreProcessWigFixed(self):
        self._preProcess(['WigFixedFunctionGenomeElementSource'])

    def testPreProcessWigFixedStep(self):
        self._preProcess(['WigFixedPartitionGenomeElementSource'])

    def testPreProcessWigVariableStepPartition(self):
        self._preProcess(['WigVariablePartitionGenomeElementSource'])

    def testPreProcessWigVariableStepSegments(self):
        self._preProcess(['WigVariableSegmentsGenomeElementSource'])
        
    def testPreProcessHBFunction(self):
        self._preProcess(['HBFunctionGenomeElementSource'])

    def runTest(self):
        self.testPreProcessMicroarray()

if __name__ == "__main__":
    if len(sys.argv) == 2:
        TestTrackPreProcessor.VERBOSE = eval(sys.argv[1])
        sys.argv = sys.argv[:-1]
    #TestTrackPreProcessor().run()
    #TestTrackPreProcessor().debug()
    unittest.main()
