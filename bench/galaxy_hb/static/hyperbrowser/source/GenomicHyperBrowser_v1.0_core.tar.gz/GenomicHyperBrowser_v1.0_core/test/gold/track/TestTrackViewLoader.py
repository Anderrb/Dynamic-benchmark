# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import unittest
from test.util.Asserts import AssertList

from gold.track.GenomeRegion import GenomeRegion
from gold.track.TrackViewLoader import TrackViewLoader 

from test.gold.track.common.SampleTrackView import getRandValList, getRandStrandList
import gold.util.CompBinManager

class TestTrackViewLoader(unittest.TestCase):
    def setUp(self):
        self.trackViewLoader = TrackViewLoader()
        gold.util.CompBinManager.COMP_BIN_SIZE = 100

    def _assertTrackViewLoading_Numbers(self, trackData, start, end):
        trackView = self.trackViewLoader.loadTrackView(trackData, GenomeRegion(start=start, end=end), 'crop',False)
        AssertList(trackData['val'][start:end], [el.val() for el in trackView], self.assertAlmostEqual)
        AssertList(trackData['strand'][start:end], [el.strand() for el in trackView], self.assertEqual)
    
    def _getTrackData_Numbers(self, size):
        return {'val' : getRandValList(size), 'strand' : getRandStrandList(size)}
    
    def testLoadTrackView_Numbers(self):
        trackData = self._getTrackData_Numbers(900)
        
        self._assertTrackViewLoading_Numbers(trackData, 0, 100)
        self._assertTrackViewLoading_Numbers(trackData, 0, 900)
        self._assertTrackViewLoading_Numbers(trackData, 300, 700)
        
        self._assertTrackViewLoading_Numbers(trackData, 312, 700)
        self._assertTrackViewLoading_Numbers(trackData, 300, 687)
        self._assertTrackViewLoading_Numbers(trackData, 312, 687)
        
        self._assertTrackViewLoading_Numbers(trackData, 0, 0)
        self._assertTrackViewLoading_Numbers(trackData, 300, 300)
        self._assertTrackViewLoading_Numbers(trackData, 400, 300)
        
        trackData = self._getTrackData_Numbers(891)
        self._assertTrackViewLoading_Numbers(trackData, 800, 880)
        self._assertTrackViewLoading_Numbers(trackData, 800, 891)
        self._assertTrackViewLoading_Numbers(trackData, 700, 880)
        
    def _assertTrackViewLoading_Segments(self, trackData, indexList, start, end):
        trackView = self.trackViewLoader.loadTrackView(trackData, GenomeRegion(start=start, end=end),'crop',False)
        i = -1
        for i,el in enumerate(trackView):
            if i < len(indexList):
                index = indexList[i]
            else:
                self.fail()
            self.assertEqual(max(0, trackData['start'][index] - start), el.start())
            self.assertEqual(min(end, trackData['end'][index]) - start, el.end())
            self.assertAlmostEqual(trackData['val'][index], el.val())
            self.assertEqual(trackData['strand'][index], el.strand())
        self.assertEqual(len(indexList), i+1)
    
    def testLoadTrackView_Segments(self):
        trackData = {'start' : [10, 210, 260, 410],\
                     'end' : [20, 240, 310, 710],\
                     'val' : getRandValList(4),\
                     'strand' : getRandStrandList(4),\
                     'leftIndex' : [0, 1, 1, 1, 3, 3, 3, 3, 4],\
                     'rightIndex' : [1, 1, 3, 3, 4, 4, 4, 4, 4]}
        
        self._assertTrackViewLoading_Segments(trackData, [0], 0, 100)
        self._assertTrackViewLoading_Segments(trackData, [1, 2], 200, 300)
        self._assertTrackViewLoading_Segments(trackData, [0, 1, 2, 3], 0, 900)
        self._assertTrackViewLoading_Segments(trackData, [2, 3], 300, 700)

        self._assertTrackViewLoading_Segments(trackData, [3], 310, 700)
        self._assertTrackViewLoading_Segments(trackData, [2], 300, 410)
        self._assertTrackViewLoading_Segments(trackData, [], 310, 410)

        self._assertTrackViewLoading_Segments(trackData, [], 0, 0)
        self._assertTrackViewLoading_Segments(trackData, [], 300, 300)
        self._assertTrackViewLoading_Segments(trackData, [], 400, 400)
        
    def runTest(self):
        self.testLoadTrackView_Numbers()
    
if __name__ == "__main__":
    TestTrackViewLoader().debug()
    #unittest.main()
