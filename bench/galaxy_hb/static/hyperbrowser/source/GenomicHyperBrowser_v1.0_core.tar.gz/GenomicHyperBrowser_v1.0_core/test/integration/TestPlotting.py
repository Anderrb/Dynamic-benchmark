# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#!/usr/bin/env python
import unittest
import random
import sys

from gold.application.GalaxyInterface import GalaxyInterface

sys.stdout = open('/dev/null', 'w')

class TestPlotting(unittest.TestCase):
    def setUp(self):
        pass
    #def testScatterPlotter(self):
    #    self.assertEqual([(-19247.708999999992, -1.9247708999999991), (-13936.835999999996, -1.3936835999999995), (-5140.0289999999941, -0.51400289999999937), (-18613.61699999998, -1.861361699999998)],\
    #        GalaxyInterface.runPlotting(["nums"],'SumStat',["nums"],'MeanStat','TestGenome:chr21:18850000-18890000,10000','ScatterPlotter','newFile.txt'))
    #
    #def testHistPlotter(self):
    #    self.assertEqual([(-1.5, [-142095.13500000004]), (-1.0, [-65960.591000000029, -91954.231999999989]), (-0.5, [-27985.246999999992]), (0.0, [12286.749000000018])],\
    #        GalaxyInterface.runPlotting(["nums"],'MeanStat',["nums"],'SumStat','TestGenome:chr21:17900000-18400000,100000','HistPlotter','newFile.txt'))
    #
    #def testLinePlotter(self):
    #    self.assertEqual([(-1.5, -142095.13500000004), (-1.0, -78957.411500000017), (-0.5, -27985.246999999992), (0.0, 12286.749000000018)],\
    #        GalaxyInterface.runPlotting(["nums"],'MeanStat',["nums"],'SumStat','TestGenome:chr21:17900000-18400000,100000','LinePlotter','newFile.txt'))
    #
    def runTest(self):
        pass

if __name__ == "__main__":
    #TestPlotting().debug()
    unittest.main()
