# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

# NB: TrackFormat == TrackFormat is not tested

import unittest
from gold.track.TrackFormat import TrackFormat
from gold.track.TrackFormat import TrackFormatReq

class TestTrackFormat(unittest.TestCase):
    def setUp(self):
        pass

    def _assertFunctions(self, tf, formatName, dense, marked, interval, reprDense, strand):
        self.assertEqual(dense, tf.isDense())
        self.assertEqual(marked, tf.isMarked())
        if marked:
            self.assertEqual('Number', tf.getMarkName())
        self.assertEqual(interval, tf.isInterval())
        if reprDense != None:
            self.assertEqual(reprDense, tf.reprIsDense())
        self.assertEqual(strand, tf.hasStrand())

        if not str(tf).startswith('Requirement'):
            self.assertEqual(formatName, tf.getFormatName())
            #To test TrackFormatReq(name=formatName) on the standard formats in an easy way
            self.assertTrue(TrackFormatReq(name=formatName).isCompatibleWith(tf))

    def _assertTrackFormat(self, tf, start, end, val, strand):
        if start and not end and not val:
            self._assertFunctions(tf, 'Unmarked points', dense=False, marked=False, interval=False, reprDense=False, strand=strand)
        if start and not end and val:
            self._assertFunctions(tf, 'Marked points', dense=False, marked=True, interval=False, reprDense=False, strand=strand)
        if start and end and not val:
            self._assertFunctions(tf, 'Unmarked segments', dense=False, marked=False, interval=True, reprDense=False, strand=strand)
        if start and end and val:
            self._assertFunctions(tf, 'Marked segments', dense=False, marked=True, interval=True, reprDense=False, strand=strand)
        if not start and end and not val:
            self._assertFunctions(tf, 'Unmarked partition', dense=True, marked=False, interval=True, reprDense=False, strand=strand)
        if not start and end and val:
            self._assertFunctions(tf, 'Marked partition', dense=True, marked=True, interval=True, reprDense=False, strand=strand)
        if not start and not end and val:
            self._assertFunctions(tf, 'Function', dense=True, marked=True, interval=False, reprDense=True, strand=strand)
        
    def testFormats(self):
        for start in [None, []]:
            for end in [None, []]:
                for val in [None, []]:
                    for strand in [None, []]:
                        if [] in [start, end, val]:
                            tf = TrackFormat(start, end, val, strand)
                            self._assertTrackFormat(tf, start==[], end==[], val==[], strand==[])

    def _assertIsCompatibleWith(self, tfReq, reqList):
        for start in [None, []]:
            for end in [None, []]:
                for val in [None, []]:
                    for strand in [None, []]:
                        if [] in [start, end, val]:
                            tf = TrackFormat(start, end, val, strand)
                            propList = [tf.isDense(), tf.isMarked(), tf.isInterval(), tf.hasStrand()]
                            isCompatible = (not False in [(r==None or r==p) for r,p in zip(reqList, propList)])
                            self.assertEqual(isCompatible, tfReq.isCompatibleWith(tf))

    def _assertFormatsReqs(self, tfReq, dense, marked, interval, strand):
        self._assertFunctions(tfReq, '', dense, marked, interval, None, strand)
        reqList = [dense,marked,interval,strand]
        self._assertIsCompatibleWith(tfReq, reqList)

    def testFormatsReqs(self):
        for dense in (False, True, None):
            for marked in (False, True, None):
                for interval in (False, True, None):
                    for strand in (False, True, None):
                        tfReq = TrackFormatReq(dense=dense, mark='ordinal' if marked else marked, interval=interval, strand=strand)
                        self._assertFormatsReqs(tfReq, dense, marked, interval, strand)
                        
    def testFormatsReqsCombinedNames(self):
        for formatName, dense, marked, interval in (('Points', False, None, False),\
                                                    ('Segments', False, None, True),\
                                                    ('Partition', True, None, True)):
            for strand in (False, True, None):
                tfReq = TrackFormatReq(name=formatName, strand=strand)
                self._assertFormatsReqs(tfReq, dense, marked, interval, strand)

    def testMerge(self):
        mergedTFR = TrackFormatReq.merge( TrackFormatReq(dense=False), TrackFormatReq(interval=True) )
        self.assertFalse(mergedTFR.isDense())
        self.assertTrue(mergedTFR.isInterval())
        
        mergedTFR = TrackFormatReq.merge( TrackFormatReq(dense=False, mark='tc'), TrackFormatReq(interval=True, mark='ordinal') )
        self.assertEqual(None, mergedTFR)
        
    def testMarkFormats(self):
        tf = TrackFormat.createInstanceFromPrefixList(['start', 'val'], 'float32', 2)
        self.assertTrue(tf.isMarked(specificMarkType='meansd'))
        self.assertEqual('Mean and std.dev.', tf.getMarkName())
        self.assertEqual('Marked points', tf.getFormatName())
        
        tfq = TrackFormatReq(interval=False, mark='tc')
        self.assertFalse(tfq.isCompatibleWith(tf))

    def testCompatibilityWithExceptions(self):
        tf = TrackFormat.createInstanceFromPrefixList(['start', 'val'], 'float32', 1)
        
        self.assertFalse(TrackFormatReq(interval=True, strand=True, mark='ordinal')\
                         .isCompatibleWith(tf))
        self.assertFalse(TrackFormatReq(interval=True, strand=True, mark='ordinal')\
                         .isCompatibleWith(tf, ['interval']))
        self.assertTrue(TrackFormatReq(interval=True, strand=True, mark='ordinal')\
                        .isCompatibleWith(tf, ['interval', 'hasStrand']))
        self.assertFalse(TrackFormatReq(interval=True, strand=True, mark='tc')\
                         .isCompatibleWith(tf, ['interval', 'hasStrand']))
    
if __name__ == "__main__":
    unittest.main()
