


#result_list = []
#result_list+="vegard"
#result_list+="hei"

result_list = ["a", "hallo"]

print "hallo" + str(result_list)