# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.origdata.GenomeElement import GenomeElement

class MyGeIter:
    def __init__(self):
        self.iter = []

    def __iter__(self):
        return self.iter.__iter__()

    def getPrefixList(self):
        return [prefix for prefix in ['start', 'end', 'val', 'strand', 'source'] \
                if self.iter[0].__dict__.get(prefix) is not None]

def _getIter(elList):
    geIter = MyGeIter()
    for i in xrange(len(elList)):
        ge = GenomeElement(chr=elList[i][1], start=elList[i][2], end=elList[i][3])
        ge.subtype = elList[i][0]
        if elList[i][0] != None:
            ge.genome = elList[i][0][0]
        geIter.iter.append(ge)
    return geIter

def assertDecorator(decoratorClass, assertFunc, processedList, origList):
    decorated = decoratorClass(_getIter(origList))
    for i in range(3):
        j = -1
        for j, el in enumerate(decorated):
            assert( j < len(processedList) ) 
            assertFunc(processedList[j][0], el.subtype)
            assertFunc(processedList[j][1], el.chr)
            assertFunc(processedList[j][2], el.start)
            assertFunc(processedList[j][3], el.end)
        assertFunc(len(processedList), j+1)

    