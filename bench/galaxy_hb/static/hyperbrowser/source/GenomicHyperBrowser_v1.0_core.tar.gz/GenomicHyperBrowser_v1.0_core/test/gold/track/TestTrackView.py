# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import unittest
import functools
from numpy import array, nan
from gold.track.GenomeRegion import GenomeRegion
from gold.track.TrackView import TrackView
from gold.util.CustomExceptions import NotImplementedError
from test.util.Asserts import smartRecursiveAssertList

class TestTrackView(unittest.TestCase):
    def setUp(self):
        self.genome = 'NCBI36'
        self.chr = 'chr1'
    
    def testInit(self):
        starts = [1, 11, 21]
        ends = [9, 19, 29]
        values = [5.2, -5, 0]
        strands = [False, True, False]
        genomeAnchor = GenomeRegion(self.genome, self.chr, 0, 100)

        self.assertRaises(AssertionError, TrackView, genomeAnchor, [], ends, values, strands, None,'crop', False)
        self.assertRaises(AssertionError, TrackView, genomeAnchor, starts, [], values, strands, None, 'crop', False)
        self.assertRaises(AssertionError, TrackView, genomeAnchor, starts, ends, [], strands, None, 'crop', False)
        self.assertRaises(AssertionError, TrackView, genomeAnchor, starts, ends, values, [], None, 'crop', False)

        t = TrackView(genomeAnchor, None, [0] + ends, [nan] + values, [True] + strands, None, 'crop', False)
        t = TrackView(genomeAnchor, starts, None, values, strands, None, 'crop', False)
        t = TrackView(genomeAnchor, starts, ends, None, strands, None, 'crop', False)
        t = TrackView(genomeAnchor, starts, ends, values, None, None, 'crop', False)

        self.assertRaises(AssertionError, TrackView, genomeAnchor, starts[0:-1], ends, values, strands, None, 'crop', False)
        self.assertRaises(AssertionError, TrackView, genomeAnchor, starts, ends[0:-1], values, strands, None, 'crop', False)
        self.assertRaises(AssertionError, TrackView, genomeAnchor, starts, ends, values[0:-1], strands, None, 'crop', False)
        self.assertRaises(AssertionError, TrackView, genomeAnchor, starts, ends, values, strands[0:-1], None, 'crop', False)
                  
    def _parseElementListSPP(self, elList):
        dict = {}
        dict['start'] = [el[0] for el in elList]
        dict['end'] = [el[1] for el in elList]
        dict['val'] = [el[2] for el in elList]
        dict['strand'] = [el[3] for el in elList]
        return dict
    
    def _parseElementListF(self, elList):
        dict = {}
        dict['val'] = [el[0] for el in elList]
        dict['strand'] = [el[1] for el in elList]
        return dict
      
    def _getPointEnds(self, target):
        return [el[0]+1 for el in target]

    def _getPartitionStarts(self, target):
        prevEnd = 0
        starts = []
        for el in target:
            starts.append(prevEnd)
            prevEnd = el[1]
        return starts

    def _runAllSPP(self, target, targetRegion, source, sourceRegion, func, mayHaveOverlaps=False):
        self._runAllSegPoint(target, targetRegion, source, sourceRegion, func, mayHaveOverlaps)
        self._runAllPart(target, targetRegion, source, sourceRegion, func, mayHaveOverlaps)

    def _runAllSegPoint(self, target, targetRegion, source, sourceRegion, func, mayHaveOverlaps=False):
        sDict, tDict = [self._parseElementListSPP(elList) for elList in [source, target]]
        for ends,tEnds in ((None,self._getPointEnds(target)), (sDict['end'],tDict['end'])):
            self._runAllCommon(sDict['start'], tDict['start'], ends, tEnds,\
                               sDict, tDict, sourceRegion, targetRegion, func, mayHaveOverlaps)
            
    def _runAllPart(self, target, targetRegion, source, sourceRegion, func, mayHaveOverlaps=False):
        sDict, tDict = [self._parseElementListSPP(elList) for elList in [source, target]]
        sDict['val'] = [nan] + sDict['val']
        sDict['strand'] = [True] + sDict['strand']
        self._runAllCommon(None, self._getPartitionStarts(target), [0] + sDict['end'], tDict['end'],\
                           sDict, tDict, sourceRegion, targetRegion, func, mayHaveOverlaps)
                
    def _runAllSegments(self, target, targetRegion, source, sourceRegion, func, mayHaveOverlaps=False):
        sDict, tDict = [self._parseElementListSPP(elList) for elList in [source, target]]
        self._runAllCommon(sDict['start'], tDict['start'], sDict['end'], tDict['end'],\
                           sDict, tDict, sourceRegion, targetRegion, func, mayHaveOverlaps)
        
    def _createTrackView(self, starts, ends, vals, strands, sourceRegion, mayHaveOverlaps):
        genomeAnchor = GenomeRegion(genome=self.genome, chr=self.chr, start=sourceRegion[0], end=sourceRegion[1])
        tv = TrackView(genomeAnchor, \
                       array(starts) if starts is not None else None, \
                       array(ends) if ends is not None else None, \
                       array(vals, dtype='float32') if vals is not None else None, \
                       array(strands) if strands is not None else None, \
                       None, 'crop', mayHaveOverlaps)
        return tv
    
    def _runFunc(self, tv, func):
        if func != None:
            return func(tv)
        else:
            return tv
    
    def _smartAssertListWithNone(self, target, source):
        if target is None:
            self.assertEqual(None, source)
        else:
            smartRecursiveAssertList(target, [x for x in source], self.assertEqual, \
                                     functools.partial(self.assertAlmostEqual, places=5))
    
    def _assertLists(self, tv, starts, ends, vals, strands, region):
        for attr in [starts, ends, vals, strands]:
            if attr != None:
                #for el in tv:
                #    print el.start(), '-', el.end(), ',' ,
                #print
                self.assertEqual(len(attr), sum(1 for x in tv))
        
        self.assertEqual(GenomeRegion(genome=self.genome, chr=self.chr, start=region[0], end=region[1]),\
                         tv.genomeAnchor)
        
        for i, el in enumerate(tv):
            self.assertEqual(starts[i] if starts != None else None, el.start())
            self.assertEqual(ends[i] if ends != None else None, el.end())
            if vals is None:
                self.assertEqual(None, el.val())
            else:
                self.assertAlmostEqual(vals[i], el.val(), places=5)
            self.assertEqual(strands[i] if strands != None else None, el.strand())
        
        self._smartAssertListWithNone(starts, tv.startsAsNumpyArray())
        self._smartAssertListWithNone(ends, tv.endsAsNumpyArray())
        self._smartAssertListWithNone(vals, tv.valsAsNumpyArray())
        self._smartAssertListWithNone(strands, tv.strandsAsNumpyArray())
        
    def _runAllCommon(self, starts, tStarts, ends, tEnds, sDict, tDict, sourceRegion, targetRegion, func, mayHaveOverlaps):
        for vals,tVals in ((None,None), (sDict['val'],tDict['val'])):
            for strands,tStrands in ((None,None), (sDict['strand'],tDict['strand'])):
                tv = self._createTrackView(starts, ends, vals, strands, sourceRegion, mayHaveOverlaps)
                newTv = self._runFunc(tv, func)
                self.assertEqual(tv.trackFormat, newTv.trackFormat)
                self._assertLists(newTv, tStarts, tEnds, tVals, tStrands, targetRegion)
    
    def _runAllF(self, target, targetRegion, source, sourceRegion, func):
        sDict, tDict = [self._parseElementListF(elList) for elList in [source, target]]
        vals, tVals = sDict['val'], tDict['val']
        for strands,tStrands in ((None,None), (sDict['strand'],tDict['strand'])):
            tv = self._createTrackView(None, None, vals, strands, sourceRegion, mayHaveOverlaps=False)
            newTv = self._runFunc(tv, func)
            self.assertEqual(tv.trackFormat, newTv.trackFormat)
            self._assertLists(newTv, None, None, tVals, tStrands, targetRegion)
    
    def testElementIteration(self):
        self._runAllSPP([[2, 5, 1.0, True], [6, 7, 2.0, False], [8, 9, -0.5, True]], [0, 10], \
                        [[2, 5, 1.0, True], [6, 7, 2.0, False], [8, 9, -0.5, True]], [0, 10], None)
        self._runAllSPP([[0, 3, 1.0, True], [4, 5, 2.0, False], [6, 7, -0.5, True]], [2, 10], \
                        [[2, 5, 1.0, True], [6, 7, 2.0, False], [8, 9, -0.5, True]], [2, 10], None)
        
        self._runAllF([[1.0, True], [2.0, False], [-0.5, True], [9.87, False]], [3, 7], \
                      [[1.0, True], [2.0, False], [-0.5, True], [9.87, False]], [3, 7], None)

    def testElementIterationWithOverlaps(self):
        self._runAllSegPoint([[2, 5, 1.0, True], [4, 7, 2.0, False], [4, 8, -0.5, True]], [10, 20], \
                             [[12, 15, 1.0, True], [14, 17, 2.0, False], [14, 18, -0.5, True]], [10, 20], None, True)
        self._runAllPart([[None, 5, 1.0, True], [None, 5, 2.0, False], [None, 10, -0.5, True]], [10, 20], \
                         [[None, 15, 1.0, True], [None, 15, 2.0, False], [None, 20, -0.5, True]], [10, 20], None, True)
        
        self._runAllSegments([[0, 5, 1.0, True], [4, 6, -0.5, True]], [10, 20], \
                             [[5, 15, 1.0, True], [7, 10, 2.0, False], [14, 16, -0.5, True]], [10, 20], None, True)
        
    def testSlicing(self):
        self._runAllSegPoint([[2, 4, 1.0, True], [5, 7, 2.0, False]], [0, 10], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [0, 10], lambda x: x[:])
        self._runAllPart([[None, 4, 1.0, True], [None, 10, 2.0, False]], [0, 10], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [0, 10], lambda x: x[:])
        self._runAllF([[1.0, True], [2.0, False], [-0.5, True]], [0, 3], \
                      [[1.0, True], [2.0, False], [-0.5, True]], [0, 3], lambda x: x[:])
        
        self._runAllSegPoint([[0, 2, 1.0, True], [3, 5, 2.0, False]], [2, 10], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[:])
        self._runAllPart([[None, 2, 1.0, True], [None, 8, 2.0, False]], [2, 10], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[:])    
        self._runAllF([[1.0, True], [2.0, False], [-0.5, True]], [2, 5], \
                      [[1.0, True], [2.0, False], [-0.5, True]], [2, 5], lambda x: x[:])
        
        self._runAllSegPoint([[0, 2, 1.0, True], [3, 5, 2.0, False]], [2, 7], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[:5])
        self._runAllPart([[None, 2, 1.0, True], [None, 5, 2.0, False]], [2, 7], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[:5])
        self._runAllF([[1.0, True], [2.0, False]], [2, 4], \
                      [[1.0, True], [2.0, False], [-0.5, True]], [2, 5], lambda x: x[:2])
        
        self._runAllSegPoint([[1, 3, 2.0, False]], [4, 10], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[2:])
        self._runAllPart([[None, 6, 2.0, False]], [4, 10], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[2:])
        self._runAllF([[2.0, False], [-0.5, True]], [3, 5], \
                      [[1.0, True], [2.0, False], [-0.5, True]], [2, 5], lambda x: x[1:])
        
        self._runAllSegPoint([[1, 3, 2.0, False]], [4, 7], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[2:5])
        self._runAllPart([[None, 3, 2.0, False]], [4, 7], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[2:5])
        self._runAllF([[2.0, False]], [3, 4], \
                      [[1.0, True], [2.0, False], [-0.5, True]], [2, 5], lambda x: x[1:2])
 
        # Slicing of border segments makes no meaning for points, therefore runAllSegments
        self._runAllSegments([[0, 1, 1.0, True], [2, 3, 2.0, False]], [3, 6], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[1:4])
        self._runAllPart([[None, 1, 1.0, True], [None, 3, 2.0, False]], [3, 6], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[1:4])
        
        self._runAllSegPoint([], [4, 5], 
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[2:3])
        self._runAllPart([[None, 1, 2.0, False]], [4, 5], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[2:3])
        
        self._runAllSegPoint([], [7, 7], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[5:5])
        self._runAllPart([], [7, 7], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[5:5])
        self._runAllF([], [4, 4], \
                      [[1.0, True], [2.0, False], [-0.5, True]      ], [2, 5], lambda x: x[2:2])
 
        self._runAllSegPoint([[0, 2, 1.0, True], [3, 4, 2.0, False]], [2, 6], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[:-4])
        self._runAllPart([[None, 2, 1.0, True], [None, 4, 2.0, False]], [2, 6], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[:-4])
        self._runAllF([[1.0, True], [2.0, False]], [2, 4], \
                      [[1.0, True], [2.0, False], [-0.5, True]], [2, 5], lambda x: x[:-1])
        
        # Slicing of border segments makes no meaning for points, therefore runAllSegments
        self._runAllSegments([[0, 1, 1.0, True], [2, 3, 2.0, False]], [3, 6], \
                             [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[1:-4])
        self._runAllPart([[None, 1, 1.0, True], [None, 3, 2.0, False]], [3, 6], \
                         [[None, 4, 1.0, True], [None, 10, 2.0, False]], [2, 10], lambda x: x[1:-4])
        self._runAllF([[2.0, False]], [3, 4], \
                      [[1.0, True], [2.0, False], [-0.5, True]], [2, 5], lambda x: x[1:-1])
        
        #We do not currently want to support slicing outside trackview, as we are not sure about what result should be..
        #self._runAllSegments([], [22, 32], \
        #                     [[2, 4, 1.0, True], [5, 7, 2.0, False]], [2, 10], lambda x: x[20:30])

#    def testAsNumpyArray(self):
#        tv = self._createTrackView(None, None, [5,6,8,5], None, [10,14], False)
#        self.assertEqual(8, tv[2])
        
#        tv = self._createTrackView([10,50,60], [20,60,77], array([5,6,8],dtype='float32'), None, [10,100], False)
        #self.assertEqual(5.0, tv[8])
        #self.assertRaises(IndexError, lambda:tv[90])
        #self.assertTrue(numpy.isnan(tv[15]))
        
#        self.assertRaises(NotImplementedError, lambda:tv[8])
        
    #def testSandbox(self):
    #    tf = createTrackFormat(False, False, True, False)
    #    genomeAnchor = GenomeRegion(start=0, end=10)
    #    t = TrackView(tf, None, None, range(10), None, genomeAnchor)
    #    
    #    print [float(x) for x in t._valList]
    #    slT = t[3:5]
    #    print [float(x) for x in t._valList]
    #    print [float(x) for x in slT._valList]
    #    for el in slT:
    #        print el.val()
    
    def runTest(self):
        pass
        self.testElementIterationWithOverlaps()
        #self.testSandbox()
        #self.testAsNumpyArray()
    
if __name__ == "__main__":
    #TestTrackView().debug()
    unittest.main()    
