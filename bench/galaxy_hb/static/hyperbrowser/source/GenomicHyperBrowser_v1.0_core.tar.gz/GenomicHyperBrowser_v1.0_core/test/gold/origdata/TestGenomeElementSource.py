# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import unittest
import tempfile
import os
import numpy
import copy
from gold.origdata.GenomeElementSource import GenomeElementSource
from gold.origdata.GenomeElementSorter import GenomeElementSorter
from gold.origdata.BedGenomeElementSource import BedGenomeElementSource, PointBedGenomeElementSource, \
                                                 BedCategoryGenomeElementSource, BedMarkedGenomeElementSource, \
                                                 StdBedGenomeElementSource
from gold.origdata.GffGenomeElementSource import GffGenomeElementSource
from gold.origdata.FastaGenomeElementSource import FastaGenomeElementSource
from gold.origdata.HBFunctionGenomeElementSource import HBFunctionGenomeElementSource
#from gold.origdata.UCSCGenomeElementSource import UCSCGenomeElementSource
from gold.origdata.WigGenomeElementSource import WigBedGenomeElementSource, WigPointBedGenomeElementSource, \
                                                 WigBedMappingGenomeElementSource, \
                                                 WigBedMeanSdGenomeElementSource, WigBedTargetControlGenomeElementSource, \
                                                 WigFixedFunctionGenomeElementSource, WigFixedPartitionGenomeElementSource, \
                                                 WigVariablePartitionGenomeElementSource, WigVariableSegmentsGenomeElementSource
from gold.origdata.MicroarrayGenomeElementSource import BaseMicroarrayGenomeElementSource
from gold.origdata.GenomeElement import GenomeElement
from test.util.Asserts import TestCaseWithImprovedAsserts

class Sample:
    def __init__(self, genome, lines, suffix, trackName, assertElementList,\
                 addSourceLineToAssertEl, targetClass, prefixList, valDataType, valDim=1):
        self.genome = genome
        self.tf = tempfile.NamedTemporaryFile(suffix=suffix)
        self.tf.write( os.linesep.join(lines) )
        self.tf.seek(0)
        self.lines = lines
        self.name = self.tf.name
        self.trackName = trackName
        self.assertElementList = assertElementList
        if addSourceLineToAssertEl:
            for i in xrange( len(self.assertElementList) ):
                self.assertElementList[i].source = lines[i + targetClass._numHeaderLines]
        self.targetClass = targetClass
        self.prefixList = prefixList
        self.valDataType = valDataType
        self.valDim = valDim

class TestGenomeElementSource(TestCaseWithImprovedAsserts):
    def setUp(self):
        self.allSf = {}
        self.allSf['bed'] = Sample('TestGenome',
                                   ['\t'.join(['chrM','71','72']),
                                    '\t'.join(['chrM','103','105']),
                                    '\t'.join(['chr21','3','13'])],
                                   '.bed',
                                   ['My','bed-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13)],
                                   True,
                                   StdBedGenomeElementSource,
                                   ['start', 'end', 'source'],
                                   'float32',
                                   1)
        
        self.allSf['bed_strand'] = Sample('TestGenome',
                                   ['\t'.join(['chrM','71','72','a','0','+']),
                                    '\t'.join(['chrM','103','105','b','1','+']),
                                    '\t'.join(['chr21','3','13','c','2','-'])],
                                   '.bed',
                                   ['My','bed-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, strand=True),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, strand=True),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, strand=False)],
                                   True,
                                   StdBedGenomeElementSource,
                                   ['start', 'end', 'strand', 'source'],
                                   'float32',
                                   1)

        self.allSf['bed_point_strand'] = Sample('TestGenome',
                                   ['\t'.join(['chrM','71','72','a','0','+']),
                                    '\t'.join(['chrM','103','104','b','1','+']),
                                    '\t'.join(['chr21','3','4','c','2','-'])],
                                   '.point.bed',
                                   ['My','point-bed-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, strand=True),
                                    GenomeElement('TestGenome', 'chrM', start=103, strand=True),
                                    GenomeElement('TestGenome', 'chr21', start=3, strand=False)],
                                   True,
                                   PointBedGenomeElementSource,
                                   ['start', 'strand', 'source'],
                                   'float32',
                                   1)
        
        self.allSf['bed_category'] = Sample('TestGenome',
                                   ['\t'.join(['chrM','71','72','aaa','0','+']),
                                    '\t'.join(['chrM','103','105','bbb','1','+']),
                                    '\t'.join(['chr21','3','13','aaa','2','-'])],
                                   '.category.bed',
                                   ['My','bed-category-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, val='aaa', strand=True),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, val='bbb', strand=True),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, val='aaa', strand=False)],
                                   True,
                                   BedCategoryGenomeElementSource,
                                   ['start', 'end', 'val', 'strand', 'source'],
                                   'S150',
                                   1)
        
        self.allSf['bed_marked'] = Sample('TestGenome',
                                   ['\t'.join(['chrM','71','72','a','0.2','+']),
                                    '\t'.join(['chrM','103','105','b','1','+']),
                                    '\t'.join(['chr21','3','13','c','-1.23e-3','-'])],
                                   '.marked.bed',
                                   ['My','bed-marked-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, val=0.2, strand=True),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, val=1, strand=True),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, val=-0.00123, strand=False)],
                                   True,
                                   BedMarkedGenomeElementSource,
                                   ['start', 'end', 'val', 'strand', 'source'],
                                   'float32',
                                   1)


        self.allSf['microarray'] = Sample('TestGenome',
                                   ['track type="array" expScale=3.0 expStep=0.5 expNames=\'A,B,C,\'',
                                    '\t'.join(['chrM','71','72','a','0','+','71','72','0','1','1','0','3','0,1,2,','0.01,-0.5,1.2']),
                                    '\t'.join(['chrM','103','105','b','1','+','103','105','0','1','2','0','2','1,2,','2.5,3.2']),
                                    '\t'.join(['chr21','3','13','c','2','-','3','13','0','1','10','0','1','0','1.4'])],
                                   '.microarray',
                                   ['My','microarray-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, strand=True, val=[0.01, -0.5, 1.2]),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, strand=True, val=[numpy.nan, 2.5, 3.2]),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, strand=False, val=[1.4, numpy.nan, numpy.nan])],
                                   True,
                                   BaseMicroarrayGenomeElementSource,
                                   ['start', 'end', 'val', 'strand', 'source'],
                                   'float32',
                                   3)

        self.allSf['bedGraph'] = Sample('TestGenome',
                                   ['track type=bedGraph name=track_label',
                                    '\t'.join(['chrM','71','72','1.0']),
                                    '\t'.join(['chrM','103','105','-1.5']),
                                    '\t'.join(['chr21','3','13','nan'])],
                                    '.bedGraph',
                                   ['My','bedGraph-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, val=1.0),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, val=-1.5),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, val=numpy.nan)],
                                   True,
                                   WigBedGenomeElementSource,
                                   ['start', 'end', 'val', 'source'],
                                   'float32',
                                   1)
        
        self.allSf['wig_bed'] = Sample('TestGenome',
                                   ['track type=wiggle_0 name=track_label',
                                    '\t'.join(['chrM','71','72','1.0']),
                                    '\t'.join(['chrM','103','105','-1.5']),
                                    '\t'.join(['chr21','3','13','nan'])],
                                    '.wig',
                                   ['My','wig-bed-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, val=1.0),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, val=-1.5),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, val=numpy.nan)],
                                   True,
                                   WigBedGenomeElementSource,
                                   ['start', 'end', 'val', 'source'],
                                   'float32',
                                   1)

        self.allSf['wig_bed_point'] = Sample('TestGenome',
                                   ['track type=wiggle_0 name=track_label',
                                    '\t'.join(['chrM','71','72','1.0']),
                                    '\t'.join(['chrM','103','104','-1.5']),
                                    '\t'.join(['chr21','3','4','None'])],
                                   '.point.wig',
                                   ['My','point-wig-bed-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, val=1.0),
                                    GenomeElement('TestGenome', 'chrM', start=103, val=-1.5),
                                    GenomeElement('TestGenome', 'chr21', start=3, val=numpy.nan)],
                                   True,
                                   WigPointBedGenomeElementSource,
                                   ['start', 'val', 'source'],
                                   'float32',
                                   1)

        self.allSf['wig_bed_meansd'] = Sample('TestGenome',
                                   ['track type=wiggle_0 name=track_label',
                                    '\t'.join(['chrM','71','72','1.0/0.1']),
                                    '\t'.join(['chrM','103','105','-1.5/1.0']),
                                    '\t'.join(['chr21','3','13','nan/nan'])],
                                    '.meansd.wig',
                                   ['My','meansd-wig-bed-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, val=[1.0,0.1]),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, val=[-1.5,1.0]),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, val=[numpy.nan,numpy.nan])],
                                   True,
                                   WigBedMeanSdGenomeElementSource,
                                   ['start', 'end', 'val', 'source'],
                                   'float32',
                                   2)

        self.allSf['wig_bed_mapping'] = Sample('TestGenome',
                                   ['track type=wiggle_0 name=track_label',
                                    '\t'.join(['chrM','71','72','1,10']),
                                    '\t'.join(['chrM','103','105','4,0']),
                                    '\t'.join(['chr21','3','13','10,201'])],
                                    '.mapping.wig',
                                   ['My','mapping-wig-bed-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, val=[1,10]),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, val=[4,0]),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, val=[10,201])],
                                   True,
                                   WigBedMappingGenomeElementSource,
                                   ['start', 'end', 'val', 'source'],
                                   'int32',
                                   2)

        self.allSf['wig_bed_tc'] = Sample('TestGenome',
                                   ['track type=wiggle_0 name=track_label',
                                    '\t'.join(['chrM','71','72','0']),
                                    '\t'.join(['chrM','103','105','1']),
                                    '\t'.join(['chr21','3','13','1'])],
                                    '.targetcontrol.wig',
                                   ['My','wig-bed-track'],
                                   [GenomeElement('TestGenome', 'chrM', start=71, end=72, val=False),
                                    GenomeElement('TestGenome', 'chrM', start=103, end=105, val=True),
                                    GenomeElement('TestGenome', 'chr21', start=3, end=13, val=True)],
                                   True,
                                   WigBedTargetControlGenomeElementSource,
                                   ['start', 'end', 'val', 'source'],
                                   'bool8',
                                   1)

        self.allSf['wigFixed_function'] = Sample('TestGenome',
                                        ['track type=wiggle_0 name=track_label',
                                         ' '.join(['fixedStep','chrom=chrM','start=1','step=1']),
                                         '4.5',
                                         '-3.7',
                                         'nan'],
                                        '.wig',
                                        ['My','wigFixed-function-track'],
                                        [GenomeElement('TestGenome', 'chrM', val=4.5),
                                         GenomeElement('TestGenome', 'chrM', val=-3.7),
                                         GenomeElement('TestGenome', 'chrM', val=numpy.nan)],
                                        False,
                                        WigFixedFunctionGenomeElementSource,
                                        ['val'],
                                        'float32',
                                        1)

        self.allSf['wigFixed_partition'] = Sample('TestGenome',
                                        ['track type=wiggle_0 name=track_label',
                                         ' '.join(['fixedStep','chrom=chr21','start=1','step=100']),
                                         '4.5',
                                         ' '.join(['fixedStep','chrom=chrM','start=1','step=100']),
                                         '-3.7',
                                         'nan'],
                                        '.wig',
                                        ['My','wigFixed-partition-track'],
                                        [GenomeElement('TestGenome', 'chr21', end=0, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chr21', end=100, val=4.5),
                                         GenomeElement('TestGenome', 'chr21', end=46944323, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=0, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=100, val=-3.7),
                                         GenomeElement('TestGenome', 'chrM', end=200, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=16571, val=numpy.nan)],
                                        False,
                                        WigFixedPartitionGenomeElementSource,
                                        ['end', 'val'],
                                        'float32',
                                        1)

        self.allSf['wigFixed_partition_start>1'] = Sample('TestGenome',
                                        ['track type=wiggle_0 name=track_label',
                                         ' '.join(['fixedStep','chrom=chr21','start=51','step=100']),
                                         '4.5',
                                         ' '.join(['fixedStep','chrom=chrM','start=51','step=100']),
                                         '-3.7',
                                         'nan'],
                                        '.wig',
                                        ['My','wigFixed-partition-start>1-track'],
                                        [GenomeElement('TestGenome', 'chr21', end=0, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chr21', end=50, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chr21', end=150, val=4.5),
                                         GenomeElement('TestGenome', 'chr21', end=46944323, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=0, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=50, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=150, val=-3.7),
                                         GenomeElement('TestGenome', 'chrM', end=250, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=16571, val=numpy.nan)],
                                        False,
                                        WigFixedPartitionGenomeElementSource,
                                        ['end', 'val'],
                                        'float32',
                                        1)
        
        self.allSf['wigFixed_variable'] = Sample('TestGenome',
                                        ['track type=wiggle_0 name=track_label',
                                         ' '.join(['variableStep','chrom=chr21']),
                                         '1\t4.5',
                                         ' '.join(['variableStep','chrom=chrM']),
                                         '1\tNA',
                                         '151\t3.7',
                                         '351\t2.7'],
                                        '.wig',
                                        ['My','wigFixed_variable_track'],
                                        [GenomeElement('TestGenome', 'chr21', end=0, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chr21', end=46944323, val=4.5),
                                         GenomeElement('TestGenome', 'chrM', end=0, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=150, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', end=350, val=3.7),
                                         GenomeElement('TestGenome', 'chrM', end=16571, val=2.7)],
                                        False,
                                        WigVariablePartitionGenomeElementSource,
                                        ['end', 'val'],
                                        'float32',
                                        1)

        self.allSf['wigFixed_variable_span'] = Sample('TestGenome',
                                        ['track type=wiggle_0 name=track_label',
                                         ' '.join(['variableStep','chrom=chr21', 'span=50']),
                                         '1\t4.5',
                                         ' '.join(['variableStep','chrom=chrM', 'span=100']),
                                         '21\tNA',
                                         '151\t3.7',
                                         '351\t2.7'],
                                        '.wig',
                                        ['My','wigFixed_variable_span_track'],
                                        [GenomeElement('TestGenome', 'chr21', start=0, end=50, val=4.5),
                                         GenomeElement('TestGenome', 'chrM', start=20, end=120, val=numpy.nan),
                                         GenomeElement('TestGenome', 'chrM', start=150, end=250, val=3.7),
                                         GenomeElement('TestGenome', 'chrM', start=350, end=450, val=2.7)],
                                        False,
                                        WigVariableSegmentsGenomeElementSource,
                                        ['start', 'end', 'val'],
                                        'float32',
                                        1)

#        self.allSf['ucsc'] = Sample('TestGenome',
#                                   ['\t'.join(['695','197','135','54','0','chr21',\
#                                              '140028','140065','-35261367','+'\
#                                              ,'MIRb','SINE','MIR','86','124','-144','1']),
#                                    '\t'.join(['695','2085','186','36','43','chr21',\
#                                              '140447','140886','-35260546','-',\
#                                              'MER4B-int','LTR','ERV1','-5911','847','412','2']),
#                                    '\t'.join(['695','1745','205','36','117','chr21',\
#                                              '140887','141417','-35260015','-',\
#                                              'MER4E1','LTR','ERV1','-294','487','1'])],
#                                   '.txt',
#                                   ['My','ucsc-track'],
#                                   [GenomeElement('TestGenome', 'chr21', start=140028, end=140065,\
#                                                 strand=True, subtype=['SINE','MIRb','MIR']),
#                                    GenomeElement('TestGenome', 'chr21', start=140447, end=140886,\
#                                                 strand=False, subtype=['LTR','MER4B-int','ERV1']),
#                                    GenomeElement('TestGenome', 'chr21', start=140887, end=141417,\
#                                                 strand=False, subtype=['LTR','MER4E1','ERV1'])],
#                                   True,
#                                   UCSCGenomeElementSource,
#                                   ['start', 'end', 'strand', 'source'],
#                                   'float32',
#                                   1)
#        
        
        self.allSf['gff'] = Sample('TestGenome',
                                   ['\t'.join(['TestGenome_chr21','Transfac','Protein_binding',\
                                               '216936','216956','.','+','.','CHR',\
                                               'chr21;PWMS;GENOME','TestGenome;transfac_id','R08851']),
                                    '\t'.join(['MT','Transfac','Protein_binding',\
                                               '2433','2444','.','-','.','CHR',\
                                               'chr21;PWMS;GENOME','TestGenome;transfac_id','R08501']),
                                    '\t'.join(['XXI','Transfac','Protein_binding',\
                                               '758943','758953','.','+','.','CHR',\
                                               'chr210;PWMS;GENOME','TestGenome;transfac_id','R08500'])],
                                   '.gff',
                                   ['My','gff-track'],
                                   [GenomeElement('TestGenome', 'chr21', start=216935, end=216956,\
                                                 strand=True),
                                    GenomeElement('TestGenome', 'chrM', start=2432, end=2444,\
                                                 strand=False),
                                    GenomeElement('TestGenome', 'chr21', start=758942, end=758953,\
                                                 strand=True)],
                                   True,
                                   GffGenomeElementSource,
                                   ['start', 'end', 'strand', 'source'],
                                   'float32',
                                   1)
                                        
        self.allSf['fasta'] = Sample('TestGenome',
                                   ['>chrM Description',
                                    'ac',
                                    'gt'],
                                   '.fa',
                                   ['My','fasta-track'],
                                   [GenomeElement('TestGenome', 'chrM', val='a'),
                                    GenomeElement('TestGenome', 'chrM', val='c'),
                                    GenomeElement('TestGenome', 'chrM', val='g'),
                                    GenomeElement('TestGenome', 'chrM', val='t')],
                                   False,
                                   FastaGenomeElementSource,
                                   ['val'],
                                   'S1',
                                   1)

        self.allSf['hbfunction'] = Sample('TestGenome',
                                   ['Whatever'],
                                   '.hbfunction',
                                   ['My','intensity-track'],
                                   [GenomeElement('TestGenome', 'chr21', val=0.0)],
                                   False,
                                   HBFunctionGenomeElementSource,
                                   ['val'],
                                   'float64',
                                   1)
    
    def _testIterator(self, sf, geSource):
        geSourceLen = sum([1 for ge in geSource])
        self.assertEqual(len(sf.assertElementList), geSourceLen)
        for i, el in enumerate( geSource ):
            try:
                assertEl = copy.copy(sf.assertElementList[i])
            
                self.assertListsOrDicts(assertEl.val, el.val)
                assertEl.val = el.val = None
    
                self.assertEqual(assertEl, el)
            except Exception, e:
                print str(sf.trackName) + ': ' + str(assertEl) + ' != ' + str(el)
                raise e

    def testIterator(self):
        for key in self.allSf.keys():
            sf = self.allSf[key]
            geSource = GenomeElementSource(sf.name, sf.genome)
            for i in range(2):
                self._testIterator(sf, geSource)
        
    def _assertNew(self, sf):
        elSource = GenomeElementSource(sf.name, sf.genome)
        self.assertEqual(elSource.__class__, sf.targetClass)
        
    def testNew(self):
        for sf in self.allSf.values():
            self._assertNew(sf)
            
    def _assertPrefixList(self, sf):
        elSource = GenomeElementSource(sf.name, sf.genome)
        self.assertListsOrDicts(sf.prefixList, elSource.getPrefixList())
        
    def testGetPrefixList(self):
        for sf in self.allSf.values():
            self._assertPrefixList(sf)
    
    def _assertValDataType(self, sf):
        elSource = GenomeElementSource(sf.name, sf.genome)
        self.assertEqual(sf.valDataType, elSource.getValDataType())
            
    def testGetValDataType(self):
        for sf in self.allSf.values():
            self._assertValDataType(sf)
    
    def _assertValDim(self, sf):
        elSource = GenomeElementSource(sf.name, sf.genome)
        self.assertEqual(sf.valDim, elSource.getValDim())
            
    def testGetValDim(self):
        for sf in self.allSf.values():
            self._assertValDim(sf)
    
#    def runTest(self):
#        self.testDirtyFlagSortedWigFixedElementSource()
    
if __name__ == "__main__":
#    TestGenomeElementSource().debug()
    unittest.main()         
