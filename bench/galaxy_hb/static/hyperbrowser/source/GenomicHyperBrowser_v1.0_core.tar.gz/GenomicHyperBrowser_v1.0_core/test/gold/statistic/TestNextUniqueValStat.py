# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import unittest
from gold.statistic.AllStatistics import *

from test.gold.statistic.StatUnitTest import StatUnitTest
from test.gold.track.common.SampleTrackView import SampleTV, SampleTV_Num
from gold.origdata.GenomeElementSource import GenomeElementSource

class TestNextUniqueValStatUnsplittable(StatUnitTest):
    classToCreate = NextUniqueValStat

    #def testIncompatibleTracks(self):
    #    pass
     
    def test_compute(self):
        self._assertIterativeComputes([-1.5,2.0], SampleTV_Num( anchor=[10,13], vals=[2.0,-1.5,2.0] ), testWithConverter=True)
        self._assertIterativeComputes(['a','b','c'], SampleTV( anchor=[10,100], segments=[[1,10],[11,20],[21,30],[41,50],[91,100]], \
                                                               vals=['a','b','a','c','a'], \
                                      valDType=GenomeElementSource.CATEGORY_DATA_TYPE ), testWithConverter=True)
        self._assertIterativeComputes([None], SampleTV( anchor=[10,100], segments=[], vals=[] ), testWithConverter=True)

    #def test_createChildren(self):
    #    self._assertCreateChildren([], SampleTV_Num( anchor= ))

    #def runTest(self):
    #    pass

class TestNextUniqueValStatSplittable(StatUnitTest):
    classToCreate = NextUniqueValStat

    def test_compute(self):
        self._assertIterativeComputes([2.0,-1.5], SampleTV_Num( anchor=[99,102], vals=[2.0,-1.5,2.0] ), testWithConverter=True)
        self._assertIterativeComputes(['a','b','c'], SampleTV( segments=[[1,10],[11,20],[21,130],[141,150],[191,210]], \
                                                               vals=['a','b','a','c','a'], \
                                      valDType=GenomeElementSource.CATEGORY_DATA_TYPE ), testWithConverter=True)
        self._assertIterativeComputes([None], SampleTV( anchor=[10,1000], segments=[], vals=[] ), testWithConverter=True)
       
#    def test_createChildren(self):
#        pass
    
    #def runTest(self):
    #    pass
    
if __name__ == "__main__":
    #TestNextUniqueValStatSplittable().debug()
    #TestNextUniqueValStatUnsplittable().debug()
    unittest.main()
