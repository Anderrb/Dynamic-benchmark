# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import unittest
import copy
from gold.formatconversion.IterateUniqueValsFormatConverter import IterateUniqueValsFormatConverter, IterateUniqueValsAndSegmentToStartPointFormatConverter
from gold.track.TrackView import TrackView
from gold.track.TrackFormat import TrackFormatReq
from test.gold.track.common.SampleTrackView import SampleTV, SampleTV_Num
from gold.util.CustomExceptions import NoMoreUniqueValsError
from gold.origdata.GenomeElementSource import GenomeElementSource

class TestIterateUniqueValsFormatConverter(unittest.TestCase):
    _formatConverterCls = IterateUniqueValsFormatConverter
    _interval = None
    
    def setUp(self):
        pass
    
    def _assertTv(self, targetSegments, targetStrands, targetVals, convertedTv):
        self.assertEqual(targetSegments, [[el.start(), el.end()] for el in convertedTv])
        self.assertEqual(targetStrands, [el.strand() for el in convertedTv])
        self.assertEqual(targetVals, [el.val() for el in convertedTv])
    
    def _assertIterateVals(self, target, sourceTv, markType):
        iterateValsFormat = TrackFormatReq(mark=markType, iterateUniqueVals=True, interval=self._interval)
        self.assertFalse(iterateValsFormat.isCompatibleWith(sourceTv.trackFormat))
        self.assertTrue(self._formatConverterCls.canHandle(sourceTv.trackFormat, iterateValsFormat))
    
        converter = self._formatConverterCls(sourceTv.trackFormat, iterateValsFormat)
         
        for t in target:
            convertedTv = converter.convert(sourceTv)
            self._assertTv(t[0], t[1], t[2], convertedTv)
            
            newTv = sourceTv[0:3]
            newTv.genomeAnchor.chr = 'chr2'
            convertedTv = converter.convert(newTv)
            self.assertTrue(len(convertedTv.valsAsNumpyArray()) <= len(t[2]))
        
        if len(target) == 0:
            convertedTv = converter.convert(sourceTv)
            self._assertTv([], [], [], convertedTv)
        else:
            self.assertRaises(NoMoreUniqueValsError, converter.convert, sourceTv)
                
    def testConversion(self):
        self._assertIterateVals([( [[10,20]],[False],['a'] ), ( [[2,6]],[True],['b'] )], \
                                  SampleTV( segments=[[2,6], [10,20]], strands=[True,False], vals=['b','a'], \
                                            valDType=GenomeElementSource.CATEGORY_DATA_TYPE ), markType='category')
        self._assertIterateVals([( [[2,6], [5,10]],[True,False],['a','a'] ), ( [[4,8]],[False],['b'] )], \
                                  SampleTV( segments=[[2,6], [4,8], [5,10]], strands=[True,False,False], vals=['a','b','a'], \
                                            valDType=GenomeElementSource.CATEGORY_DATA_TYPE ), markType='category')
        self._assertIterateVals([( [[1,2], [8,9]],[None,None],['a','a'] ), ( [[5,6]], [None],['b'] )], \
                                  SampleTV( starts=[1,5,8], strands=False, vals=['a','b','a'], \
                                            valDType=GenomeElementSource.CATEGORY_DATA_TYPE ), markType='category')
        
        self._assertIterateVals([( [[4,8]],[False],[False] ), ( [[2,6], [5,10]],[True,False],[True,True] )], \
                                  SampleTV( segments=[[2,6], [4,8], [5,10]], strands=[True,False,False], vals=[True,False,True], \
                                            valDType='bool8' ), markType='tc')
        
        self._assertIterateVals([( [[None,None]], [None], ['a'] ), ( [[None,None]]*3, [None]*3, ['b']*3 )], \
                                  SampleTV_Num( strands=False, vals=['b','a','b','b'], valDType=GenomeElementSource.CATEGORY_DATA_TYPE), \
                                  markType='category')
        
        self._assertIterateVals([], \
                                  SampleTV( segments=[], strands=[], vals=[], valDType=GenomeElementSource.CATEGORY_DATA_TYPE), markType='category')
        

    def _assertFailedConversion(self, sourceTv, tfReq):
        self.assertFalse(self._formatConverterCls.canHandle(sourceTv.trackFormat, tfReq))
 
    def testConversionFails(self):
        segSourceTv = SampleTV(segments=[[2,20], [7,11]], vals=['a','b'], valDType=GenomeElementSource.CATEGORY_DATA_TYPE)
        self._assertFailedConversion(segSourceTv, \
                                     TrackFormatReq(interval=False, dense=False, mark='category', iterateUniqueVals=True))
        self._assertFailedConversion(segSourceTv, \
                                     TrackFormatReq(interval=True, mark='category'))
        self._assertFailedConversion(segSourceTv, \
                                     TrackFormatReq(mark='tc', iterateUniqueVals=True))
        
        segSourceTv2 = SampleTV(ends=[10,90], vals=['a','b'], valDType=GenomeElementSource.CATEGORY_DATA_TYPE)
        self._assertFailedConversion(segSourceTv2, \
                                     TrackFormatReq(mark='category', iterateUniqueVals=True))

class TestIterateUniqueValsAndSegmentToStartPointFormatConverter(TestIterateUniqueValsFormatConverter):         
    _formatConverterCls = IterateUniqueValsAndSegmentToStartPointFormatConverter
    _interval = False
    
    def testConversion(self):
        self._assertIterateVals([( [[19,20]],[False],['a'] ), ( [[2,3]],[True],['b'] )], \
                                  SampleTV( segments=[[2,6], [10,20]], strands=[True,False], vals=['b','a'], \
                                            valDType=GenomeElementSource.CATEGORY_DATA_TYPE ), markType='category')
        self._assertIterateVals([( [[2,3], [9,10]],[True,False],['a','a'] ), ( [[7,8]],[False],['b'] )], \
                                  SampleTV( segments=[[2,6], [4,8], [5,10]], strands=[True,False,False], vals=['a','b','a'], \
                                            valDType=GenomeElementSource.CATEGORY_DATA_TYPE ), markType='category')
        
        self._assertIterateVals([( [[7,8]],[False],[False] ), ( [[2,3], [9,10]],[True,False],[True,True] )], \
                                  SampleTV( segments=[[2,6], [4,8], [5,10]], strands=[True,False,False], vals=[True,False,True], \
                                            valDType='bool8' ), markType='tc')
        self._assertIterateVals([], \
                                  SampleTV( segments=[], strands=[], vals=[], valDType=GenomeElementSource.CATEGORY_DATA_TYPE), markType='category') 
        
    def testConversionFails(self):
        segSourceTv = SampleTV(segments=[[2,20], [7,11]], vals=['a','b'], valDType=GenomeElementSource.CATEGORY_DATA_TYPE)
        self._assertFailedConversion(segSourceTv, \
                                     TrackFormatReq(interval=True, dense=False, mark='category', iterateUniqueVals=True))
        self._assertFailedConversion(segSourceTv, \
                                     TrackFormatReq(interval=True, mark='category'))
        self._assertFailedConversion(segSourceTv, \
                                     TrackFormatReq(mark='tc', iterateUniqueVals=True))
        
        segSourceTv2 = SampleTV(ends=[10,90], vals=['a','b'], valDType=GenomeElementSource.CATEGORY_DATA_TYPE)
        self._assertFailedConversion(segSourceTv2, \
                                     TrackFormatReq(mark='category', iterateUniqueVals=True))


if __name__ == "__main__":
    unittest.main()
