# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import numpy
from numpy import array, nan
import random
from gold.track.TrackView import TrackView
from gold.track.GenomeRegion import GenomeRegion

def getRandSegments(size, start, end):
   segments = sorted(random.sample(xrange(start*2, end*2), size*2))
   starts, ends = [], []
   for i in xrange(size):
      starts.append(segments[i*2]/2)
      ends.append((segments[i*2+1]+1)/2)
   return [array(starts), array(ends)]

def getRandValList(size, dtype='float32'):
   if dtype == 'float32':
      return array([random.random() - 0.5 for i in xrange(size)], dtype=dtype)
   elif dtype == 'bool8':
      return array([bool(random.getrandbits(1)) for i in xrange(size)], dtype=dtype)
   else:
      return array([], dtype=dtype)

def getRandStrandList(size):
   return array([random.randint(0, 1) for i in xrange(size)], dtype='bool8')

class SampleTV(TrackView):
    @staticmethod
    def _createList(targetList, sourceList, dtype):
        if type(targetList) == bool:
            if targetList == True:
                targetList = sourceList
            else:
                return None
        return array(targetList, dtype=dtype)

    def __init__(self, segments=None, starts=True, ends=True, vals=True, strands=False, anchor=None, numElements=None, valDType='float32', borderHandling='crop', mayHaveOverlaps=False):
        if type(starts) != bool and ends == True:
          ends = False
        if type(ends) != bool and starts == True:
          starts = False
        
        assert(not (starts==False and ends==False))
        assert(segments!=False and segments!=True)
        assert(starts!=None and ends!=None and vals!=None and strands!=None)
        assert(segments==None or (starts==True and ends==True))
        
        assert (any( type(x) not in [bool,type(None)] for x in [segments,starts,ends,vals,strands]) and numElements==None) \
               or numElements!=None
        #assert(( (type(segments)!=bool or type(starts)!=bool or type(ends)!=bool or \
        #       type(vals)!=bool or type(strands)!=bool) and numElements==None )\
        #       or numElements!=None)
        #
        if anchor==None:
            anchor = [10,1000]
        
        if segments != None:
            starts = []
            ends = []        
            for seg in segments:
                starts.append(seg[0])
                ends.append(seg[1])
        
        for list in [starts, ends, vals, strands]:
            if type(list) != bool  and numElements == None:
                numElements = len(list)
            assert(type(list) == bool or len(list) == numElements)
        
        for coordList in [starts, ends]:
            if type(coordList) != bool:
                for j in range(len(coordList)):
                    coordList[j] += anchor[0]

        randSegmentLists = getRandSegments(numElements, anchor[0], anchor[1])
        starts = self._createList(starts, randSegmentLists[0], 'int32')
        ends = self._createList(ends, randSegmentLists[1], 'int32')
        
        vals = self._createList(vals, getRandValList(numElements, valDType), valDType)
        strands = self._createList(strands, getRandStrandList(numElements), 'bool8')
        
        if starts == None:
            if ends[0] != 0:
               ends = numpy.append([anchor[0]], ends)
               if vals != None:
                  vals = numpy.append([nan], vals)
               if strands != None:
                  strands = numpy.append([True], strands)
            if ends[-1] != anchor[1]:
                ends[-1] = anchor[1]
        
#        print (starts, ends, vals, strands, anchor)
        TrackView.__init__(self, GenomeRegion('NCBI36', 'chr1', anchor[0], anchor[1]), starts, ends, vals, strands, None, borderHandling, mayHaveOverlaps)

class SampleTV_Num(SampleTV):
    def __init__(self, vals=True, strands=True, anchor=None, valDType='float32'):
        assert(vals!=True or anchor!=None)
        
        if anchor==None:
            numElements = len(vals)
            anchor = [10, 10 + numElements]
        else:
            numElements = anchor[1] - anchor[0]
        
        vals = self._createList(vals, getRandValList(numElements), valDType)
        strands = self._createList(strands, getRandStrandList(numElements), 'bool8')
        
        #print (vals, strands, anchor)
        TrackView.__init__(self, GenomeRegion('NCBI36', 'chr1', anchor[0], anchor[1]), None, None, vals, strands, None, 'crop', False)
#
#def printTv(tv):
#    for el in tv:
#        print el.start(), el.end(), el.val(), el.strand(), tv.genomeAnchor.start, tv.genomeAnchor.end
#    print '--'
#
#tv = SampleTV(anchor=[22,123], numElements=2)
#printTv(tv)
#printTv(tv[0:50])
#
#printTv(SampleTV(numElements=5))
#
#printTv(SampleTV_Num(strands=False, anchor=[2,10]))
#
#printTv(SampleTV(segments=[[1,2],[3,4]]))
#printTv(SampleTV(segments=[[1,2],[3,4]], anchor=[20,30]))
#printTv(SampleTV(segments=[[1,2],[3,4]], vals=False))
#printTv(SampleTV(segments=[[1,2],[3,4]], strands=False))
#printTv(SampleTV(segments=[[1,2],[3,4]], vals=False, strands=False))
#
#printTv(SampleTV(starts=[1,3], ends=[2,4]))
#printTv(SampleTV(starts=[20,40]))
#printTv(SampleTV(ends=[20,40,990]))
#
#printTv(SampleTV(vals=False, strands=False, anchor=[22,100], numElements=9))
#printTv(SampleTV(starts=False, vals=False, strands=False, anchor=[22,100], numElements=9))

