# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from timeit import Timer
from time import sleep
import gc
import copy

def doTiming(title, setup, expressions, numIterations=int(1e6)):
    print title + ':'
    for expr in expressions:
        print '\t', expr[0]+': ', Timer(stmt=expr[1], setup=setup).timeit(numIterations)
    print

def template():
    title = 'Template'

    setup = '''
pass
    '''

    expressions =  [['Test 1', 'pass'],\
                    ['Test 2', 'pass']]

    doTiming(title, setup, expressions)

def objects():
    title = 'Objects'

    setup = '''
class A:
    pass

class B(object):
    pass

class C(object):
    def a():
        return 1
        
    def b():
        return 2
        
    def c():
        return 3
        
    def d():
        return 4
        
    def e():
        return 5
        
class D(object):
    def __init__(self, a):
        self.a = a

class E(object):
    def __init__(self, a, b, c, d, e):
        self.a = a
        self.b = b
        self.c = c
        self.d = d
        self.e = e

class F(object):
    def __init__(self, **kwArgs):
        self.args = kwArgs
    '''

    expressions =  [['Create empty object (oldstyle)', 'a = A()'],\
                    ['Create empty object (newstyle)', 'b = B()'],\
                    ['Create object (5 methods)', 'c = C()'],\
                    ['Create object (1 arg)', 'd = D(5)'],\
                    ['Create object (5 args)', 'e = E(1,2,3,4,5)'],\
                    ['Create object (5 kwArgs)', 'f = F(a=1, b=2, c=3, d=4, e=5)']]

    doTiming(title, setup, expressions)
###################################Dictionaries##################################################
def dicts():
    title = 'Dictionaries'
#why three '?
    setup = '''         
d = {1:15, 5:0, 10:20}
    '''

    expressions =  [['Create empty dict', 'a = {}'],\
                    ['Access dict, d[key]', 'd[10]'],\
                    ['Access dict, d.get(key)', 'd.get(10)'],\
                    #['key in d, key in d', 'for k, v in d.items():'],\ #why does it hang here?
                    ['Access dict, d.keys()', 'd.keys()'],\
                    ['Access dict, d.values()', 'd.values()'],\
                    ['Access dict, d.items()', 'd.items()'],\
                    ]
    doTiming(title, setup, expressions)

##########################################ListOperations###########################################
#def listOperations():
#    title = 'Dictionaries'
#
#    setup = '''
#l = [1,5,8]
#    '''
#
#    expressions =  [[]]
###############################################ListIteration#######################################
#def listIteration():
#    title = 'Dictionaries'
#
#    setup = '''
#l = [1,5,8]
#    '''
#
#    expressions =  [[]]
####################################################If##################################
#def testOfIf():
#    title = 'Dictionaries'
#
#    setup = '''
#l = [1,5,8]
#    '''
#
#    expressions =  [[]]
####################################################Basic calls#################################
def basicCalls():
    title = 'Function calls'

    setup = '''
def a(p):
    return p
    '''

    expressions =  [['Method call, 1 param', 'a(5)']]
    doTiming(title, setup, expressions)
    
######################################################Try/except###############################
def tryExcept():
    title = 'Dictionaries'

    setup = '''
l = [1,5,8]
    '''

    expressions =  [[]]
    doTiming(title, setup, expressions)

###################################################### Looping ###############################
def looping():
    title = 'Looping'

    setup = '''
import numpy
loopSize = 10000
a = numpy.arange(loopSize)
d = dict(zip(range(loopSize),range(loopSize)))
    '''

    expressions =  [['for', '''
temp = 0
for i in xrange(loopSize):
    temp+=i
                     '''],\
                    ['for-loop creating list', '''
myList = []
for i in xrange(loopSize):
    myList.append(i)
sum(myList)
                     '''],
                    ['for with if', '''
temp = 0
for i in xrange(loopSize):
    if i%2==0:
        temp+=i
                     '''],
                    ['for with dict', '''
temp = 0
for i in xrange(loopSize):
    temp+=d[i]
                     '''],\
                    ['sum implicit', 'sum(xrange(loopSize))'],
                    ['sum explicit', 'sum(range(loopSize))' ],
                    ['explicit set comprehension', 'sum([i for i in xrange(loopSize)])'],
                    ['implicit set comprehension', 'sum(i for i in xrange(loopSize))'],
                    ['explicit set comprehension with if', 'sum([i for i in xrange(loopSize) if i%2==0])'],
                    ['implicit set comprehension with if', 'sum(i for i in xrange(loopSize) if i%2==0)'],
                    ['set compr with dict','sum(d[i] for i in xrange(loopSize))'],
                    ['set compr with numpy-access','sum(a[i] for i in xrange(loopSize))'],
                    ['sum on numpy','sum(a)'],
                    ['numpy-sum','a.sum()'],
                    ['numpy-if','a[a%2==0].sum()']]

    doTiming(title, setup, expressions, 1000)

def checkMemory(infoInsteadOfEval=False):
    #This will run a series of statements.
    #Between statements the program will give a prompt and sleep to allow the user to check mem usage by e.g. top.
    #The user will put values seen in top back to this script
    smallDict = dict(zip(range(10),range(10)))
    largeDict = dict(zip(range(100),range(100)))
    
    newstyleObjCode = '''
class A(object):
    def __init__(self,i):
        self.i = i
    
temp=[ A(i) for i in xrange(numRepl)]
'''

    oldstyleObjCode = '''
class B:
    def __init__(self,i):
        self.i = i
    
temp=[ B(i) for i in xrange(numRepl)]
'''
    numRepl = 100000
    #list of: [prompt to user while checking mem, numReplication, code, value put in by user while checking mem usage(MB)..]
    promptSetupList = [['Initial mem',0,'pass',2.24],
        ['baseline holder-list',numRepl,'temp=[1]*numRepl',2.64],
        ['unique int',numRepl,'temp=[ i for i in xrange(12345678, 12345678 + numRepl)]',3.8],
        ['lists of 2 el',numRepl,'temp=[ [1]*2 for i in xrange(numRepl)]',7.77],
        ['lists of 10 el',numRepl,'temp=[ [1]*10 for i in xrange(numRepl)]',11],
        ['lists of 100 el',numRepl,'temp=[ [1]*100 for i in xrange(numRepl)]',45],
        ['lists of 1000 el',numRepl,'temp=[ [1]*1000 for i in xrange(numRepl)]',398],
        ['dict of 2 el',numRepl,'temp=[ {1:1, 2:2} for i in xrange(numRepl)]',16],
        ['dict of 10 el',numRepl,'temp=[ copy.copy(smallDict) for i in xrange(numRepl)]',53],
        ['dict of 100 el',numRepl,'temp=[ copy.copy(largeDict) for i in xrange(numRepl)]',310],
        ['minimal new-style object',numRepl,newstyleObjCode,21],
        ['minimal old-style object',numRepl,oldstyleObjCode,22],
        #[,],
        ]
    
    if infoInsteadOfEval:
        for prompt,numReplications,code,userVal in promptSetupList[1:]:
            print prompt,'(KB) : ', '%.3f' % (1000.0*(userVal-promptSetupList[0][-1])/numReplications)
    else:
        for prompt,numReplications,code,userVal in promptSetupList:
            exec(code)
            print prompt,
            sleep(8)
            print '..OK..'
            temp=None
            gc.collect()
            sleep(5)
        
#objects()
dicts()
basicCalls()
#looping()
#listOperations()
checkMemory(True)