# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import unittest
from gold.origdata.GenomeElement import GenomeElement

class TestGenomeElement(unittest.TestCase):
    def setUp(self):
        pass
    
    def testAssignAndRetrieve(self):
        e = GenomeElement('NCBI36', start=5)
        self.assertEqual(e.genome, 'NCBI36')
        self.assertEqual(e.chr, None)
        self.assertEqual(e.start, 5)
        self.assertEqual(e.end, None)
        self.assertEqual(e.val, None)
        self.assertEqual(e.strand, None)
        self.assertEqual(e.subtype, None)
        self.assertEqual(e.source, None)
        
        self.assertRaises(AttributeError, lambda : e.nonExisting)
        
        #self.assertEqual(e.get('start'), e.start)
        #self.assertEqual(e.get('end'), e.end)

    def testContains(self):
        self.assertTrue(GenomeElement('NCBI36','chr1',10,100).contains( \
                        GenomeElement('NCBI36','chr1',10,100)))
        
        self.assertTrue(GenomeElement('NCBI36','chr1',10,100).contains( \
                        GenomeElement('NCBI36','chr1',20,80)))
        
        self.assertFalse(GenomeElement('NCBI36','chr1',10,100).contains( \
                        GenomeElement('NCBI36','chr1',10,101)))
        
        self.assertFalse(GenomeElement('NCBI36','chr1',10,100).contains( \
                        GenomeElement('NCBI36','chr1',9,100)))
        
        self.assertFalse(GenomeElement('NCBI36','chr1',10,100).contains( \
                        GenomeElement('NCBI36','chr1',9,101)))
        
        self.assertFalse(GenomeElement('NCBI36','chr1',10,100).contains( \
                        GenomeElement('NCBI36','chr1',0,10)))

        self.assertFalse(GenomeElement('NCBI36','chr1',10,100).contains( \
                        GenomeElement('NCBI36','chr2',20,80)))

    def testOverlaps(self):
        self.assertTrue(GenomeElement('NCBI36','chr1',10,100).overlaps( \
                        GenomeElement('NCBI36','chr1',10,100)))
        
        self.assertTrue(GenomeElement('NCBI36','chr1',10,100).overlaps( \
                        GenomeElement('NCBI36','chr1',20,80)))
        
        self.assertTrue(GenomeElement('NCBI36','chr1',10,100).overlaps( \
                        GenomeElement('NCBI36','chr1',10,101)))
        
        self.assertTrue(GenomeElement('NCBI36','chr1',10,100).overlaps( \
                        GenomeElement('NCBI36','chr1',9,100)))
        
        self.assertTrue(GenomeElement('NCBI36','chr1',10,100).overlaps( \
                        GenomeElement('NCBI36','chr1',9,101)))
        
        self.assertFalse(GenomeElement('NCBI36','chr1',10,100).overlaps( \
                        GenomeElement('NCBI36','chr1',0,10)))

        self.assertFalse(GenomeElement('NCBI36','chr1',10,100).overlaps( \
                        GenomeElement('NCBI36','chr1',100,110)))

        self.assertFalse(GenomeElement('NCBI36','chr1',10,100).overlaps( \
                        GenomeElement('NCBI36','chr2',20,80)))

    def testExclude(self):
        self.assertEqual([GenomeElement('NCBI36','chr1',100,200)],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr1',90,100) ))
        self.assertEqual([GenomeElement('NCBI36','chr1',100,200)],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr1',200,210) ))
        self.assertEqual([GenomeElement('NCBI36','chr1',100,200)],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr2',100,110) ))

        self.assertEqual([GenomeElement('NCBI36','chr1',110,200)],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr1',100,110) ))
        self.assertEqual([GenomeElement('NCBI36','chr1',110,200)],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr1',90,110) ))
        
        self.assertEqual([GenomeElement('NCBI36','chr1',100,190)],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr1',190,200) ))
        self.assertEqual([GenomeElement('NCBI36','chr1',100,190)],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr1',190,210) ))
        
        self.assertEqual([],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr1',90,210) ))
        
        self.assertEqual([GenomeElement('NCBI36','chr1',100,140), GenomeElement('NCBI36','chr1',160,200)],\
                         GenomeElement('NCBI36','chr1',100,200).exclude( GenomeElement('NCBI36','chr1',140,160) ))

    def testExtend(self):
        self.assertEqual(GenomeElement('NCBI36','chr1',100,200),\
                         GenomeElement('NCBI36','chr1',100,200).extend( 0 ))

        self.assertEqual(GenomeElement('NCBI36','chr1',0,200),\
                         GenomeElement('NCBI36','chr1',100,200).extend( -100 ))
        self.assertEqual(GenomeElement('NCBI36','chr1',-100,200),\
                         GenomeElement('NCBI36','chr1',100,200).extend( -200, ensureValidity=False ))
        self.assertEqual(GenomeElement('NCBI36','chr1',0,200),\
                         GenomeElement('NCBI36','chr1',100,200).extend( -200, ensureValidity=True ))

        self.assertEqual(GenomeElement('NCBI36','chr1',100,300),\
                         GenomeElement('NCBI36','chr1',100,200).extend( 100 ))
        self.assertEqual(GenomeElement('NCBI36','chr1',100,250000200),\
                         GenomeElement('NCBI36','chr1',100,200).extend( 250000000, ensureValidity=False ))
        self.assertEqual(GenomeElement('NCBI36','chr1',100,247249719),\
                         GenomeElement('NCBI36','chr1',100,200).extend( 250000000, ensureValidity=True ))        

    def testEqual(self):
        self.assertEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                         GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'))

        self.assertNotEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                            GenomeElement('NCBI46','chr1',10,100,5,True,['genes','tss'],'source'))

        self.assertNotEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                            GenomeElement('NCBI36','chr2',10,100,5,True,['genes','tss'],'source'))

        self.assertNotEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                            GenomeElement('NCBI36','chr1',11,100,5,True,['genes','tss'],'source'))

        self.assertNotEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                            GenomeElement('NCBI36','chr1',10,101,5,True,['genes','tss'],'source'))

        self.assertNotEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                            GenomeElement('NCBI36','chr1',10,100,6,True,['genes','tss'],'source'))

        self.assertNotEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                            GenomeElement('NCBI36','chr1',10,100,5,False,['genes','tss'],'source'))

        self.assertNotEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                            GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tst'],'source'))

        self.assertNotEqual(GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source'),
                            GenomeElement('NCBI36','chr1',10,100,5,True,['genes','tss'],'source2'))

if __name__ == "__main__":
    unittest.main()