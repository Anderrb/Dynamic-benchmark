# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.util.CustomExceptions import ShouldNotOccurError, NotSupportedError
import copy
import numpy
from gold.application.LogSetup import HB_LOGGER, logging, logMessage
from gold.track.SmartMemmap import SmartMemmap
from gold.origdata.GenomeElementSource import GenomeElementSource

def inferMark(valList):
    'infers type of mark/value stored?'
    if valList is None:
        return False
    elif type(valList) in [list,tuple]:
        return 'ordinal'
    elif isinstance(valList, numpy.ndarray) or isinstance(valList, SmartMemmap):
        if len( valList.shape ) == 1:
            if any(valList.dtype == numpy.dtype(x) for x in ['int32', 'float32', 'float64']):
                return 'ordinal'
            elif valList.dtype == numpy.dtype('bool8'):
                return 'tc'
            elif valList.dtype == numpy.dtype('S1'):
                return 'nucleotide'
            elif any([ str(valList.dtype).startswith(x) and int(str(valList.dtype)[len(x):-1]) > 1 \
                      for x in ['S','|S'] ]):
                return 'category'
            else:
                raise ShouldNotOccurError('shape: '+str(valList.shape)+', dtype: '+str(valList.dtype))
        elif valList.shape[1] == 2 and valList.dtype == numpy.dtype('float32'):
            return 'meansd'
        elif valList.shape[1] == 2 and valList.dtype == numpy.dtype('int32'):
            return 'mapping'
        elif valList.shape[1] > 2:
            assert( valList.dtype == numpy.dtype('float32') )
            return 'population'
        else:
            logging.getLogger(HB_LOGGER).warn('Shape or dtype not recongized: ' + str(valList.shape) + ' and ' + str(valList.dtype) )
            raise ShouldNotOccurError()
    else:
        logging.getLogger(HB_LOGGER).warn('Type of valList not recognized: ' + str(type(valList)))
        raise ShouldNotOccurError()


class TrackFormat:
    #dense, marked, interval
    FORMAT_DICT = {\
        'unmarked points': (False, False, False),\
        'marked points': (False, True, False),\
        'points': (False, None, False),\
        'unmarked segments': (False, False, True),\
        'marked segments': (False, True, True),\
        'segments': (False, None, True),\
        'unmarked partition': (True, False, True),\
        'marked partition': (True, True, True),\
        'partition': (True, None, True),\
        'function': (True, True, False)
        }
    
    MARK_NAME_DICT = {
        'ordinal': 'Number',\
        'category' : 'Category',\
        'tc' : 'Case-control',\
        'nucleotide' : 'Nucleotide',\
        'meansd' : 'Mean and std.dev.',\
        'mapping' : 'Mapping to other genome',\
        'population' : 'Population vector',\
    }

    @staticmethod
    def createInstanceFromGeSource(geSource):
        return TrackFormat.createInstanceFromPrefixList(geSource.getPrefixList(), \
                                                        geSource.getValDataType(), \
                                                        geSource.getValDim())
    @staticmethod
    def createInstanceFromPrefixList(prefixList, valDataType, valDim):
        lists = [ [] if prefix in prefixList else None for prefix in ['start','end'] ]
        if 'val' in prefixList:
            lists.append( numpy.array([], dtype=valDataType).reshape(0 if valDim == 1 else (0, valDim)) )
        else:
            lists.append(None)
        lists.append([] if 'strand' in prefixList else None)
        return TrackFormat( *lists )
    
    def __init__(self, startList=None, endList=None, valList=None, strandList=None, *args, **kwArgs):
        "Sets flags that defines the format"
        self._dense = (startList == None) #not trackData.has_key('start')
        self._mark = inferMark(valList) #trackData.has_key('val')
        self._interval = (endList != None) #trackData.has_key('end')
        self._reprDense = (valList != None and startList == None and endList == None)
        #trackData.has_key('val') and not trackData.has_key('start') and not trackData.has_key('end')
        self._hasStrand = (strandList != None) #trackData.has_key('strand')
        
        assert(len(args)==0)
    
    def isDense(self):
        return self._dense
    
    def isMarked(self, specificMarkType=None):
        if specificMarkType is not None:
            return self._mark == specificMarkType
        else:
            # mark is always None at this point!
            return self._mark != False if not self._mark is None else None
    
    def getMarkName(self):
        if self.isMarked():
            return self.MARK_NAME_DICT[self._mark]
        else:
            return ''
        
    def isInterval(self):
        return self._interval
    
    def reprIsDense(self):
        return self._reprDense
    
    def hasStrand(self):
        return self._hasStrand
    
    def getFormatName(self):
        for formatName, format in TrackFormat.FORMAT_DICT.iteritems():
            if (self._dense, (self._mark != False), self._interval) == format:
                return formatName.capitalize()
        #print (self._dense, self._mark, self._interval)
        return 'Original elements'
        #raise ShouldNotOccurError
        
    def __str__(self):
        return self.getFormatName()
    
    def __eq__(self, other):
        if not isinstance(other, TrackFormat):
            return False
        return self._dense == other._dense and self._mark == other._mark and \
                            self._interval == other._interval and \
                            self._reprDense == other._reprDense and \
                            self._hasStrand == other._hasStrand
                            
    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash( tuple( [self.__dict__[key] for key in sorted(self.__dict__.keys())] ) )
        
class TrackFormatReq(TrackFormat):
    """
    if name is legalname, then mark is overridden.
    """
    def __init__(self, dense=None, mark=None, interval=None, strand=None,\
                 allowOverlaps=False, borderHandling='crop', iterateUniqueVals=None, forceAllowOverlaps=None, name=None):

        assert borderHandling in [None, 'crop','discard','include','duplicate']
        assert mark in [None, False, 'ordinal','category','all_categories','tc','meansd','mapping','population']
        assert (name is None) or (dense is None and mark is None and interval is None)
        assert iterateUniqueVals in [None, True]
        assert forceAllowOverlaps in [None, True]
        
        if not name is None:
            name = name.lower()
            if TrackFormatReq.FORMAT_DICT.has_key(name):
                self._dense, self._mark, self._interval = TrackFormatReq.FORMAT_DICT[name]
                if self._mark:
                    self._mark = inferMark([])
            else:
                raise NotSupportedError('Format name is not recognized: ' + name)
        else:
            self._dense = dense
            self._mark = mark
            self._interval = interval
        
        self._hasStrand = strand
        self._allowOverlaps = allowOverlaps
        self._forceAllowOverlaps = forceAllowOverlaps
        self._borderHandling = borderHandling
        self._iterateUniqueVals = iterateUniqueVals
        
    def __str__(self):
        return 'Requirement: ' + ', '.join([ prop + ': ' + str(getattr(self, '_'+prop))\
                                for prop in ['dense','mark','interval', 'hasStrand', 'allowOverlaps', 'borderHandling', 'iterateUniqueVals', 'forceAllowOverlaps'] if getattr(self, '_'+prop) != None])
    
    def allowsOverlaps(self):
        return self._allowOverlaps
    
    def forceAllowsOverlaps(self):
        return self._forceAllowOverlaps
    
    def borderHandling(self):
        return self._borderHandling
    
    def iterateUniqueVals(self):
        return self._iterateUniqueVals
    
    # Compatibility with other TrackFormat, not TrackFormatReq. Does not need to handle allowsOverlap and borderHandling
    def isCompatibleWith(self, sourceFormat, exceptionList=[]):
        assert( not isinstance(sourceFormat, TrackFormatReq) )
        pairedAttrs = [ [getattr(obj, attr) for obj in [self,sourceFormat]] \
            for attr in ['_dense','_mark','_interval','_hasStrand'] if attr[1:] not in exceptionList ]
        res = (not False in [s is None or s==sf for s,sf in pairedAttrs]) and \
              (not self._iterateUniqueVals or 'iterateUniqueVals' in exceptionList)
        return res

    @staticmethod
    def merge(mainReq, otherReq):
        "Tries to merge all not-None requirements of mainReq with other. Returns mainReq if successfull else returns None"
        outReq = copy.copy(mainReq)
        for attr in ['_dense','_mark','_interval','_hasStrand','_allowOverlaps','_borderHandling','_iterateUniqueVals','_forceAllowOverlaps']:
            otherAttr = getattr(otherReq, attr)
            if otherAttr is not None:
                mainAttr = getattr(mainReq, attr)
                if mainAttr is None:
                    setattr(outReq, attr, otherAttr)
                elif mainAttr == otherAttr:
                    pass
                else:
                    return None
        return outReq
        
class NeutralTrackFormatReq(TrackFormatReq):
    def __init__(self):
        TrackFormatReq.__init__(self, allowOverlaps=None, borderHandling=None)
