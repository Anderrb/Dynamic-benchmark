# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#!/usr/bin/env python
import os
import sys
from gold.description.TrackInfo import TrackInfo, TrackInfoDataCollector
from gold.origdata.GenomeElementSource import GenomeElementSource
from gold.origdata.GESourceManager import GESourceManager
from gold.origdata.PreProcessGeSourceJob import PreProcessGeSourceJob
from quick.origdata.OrigTrackFnSource import OrigTrackNameSource
from quick.util.GenomeInfo import GenomeInfo
from gold.util.CommonFunctions import createOrigPath
from gold.origdata.PreProcessUtils import PreProcessUtils
from gold.util.CustomExceptions import NotSupportedError
import traceback

class PreProcessAllTracksJob(object):
    PASS_ON_EXCEPTIONS = False
    
    def __init__(self, genome, trackNameFilter=[]):
        self._genome = genome
        self._trackNameFilter = trackNameFilter
        self._status = ''
        
    def process(self):
        avoidLiterature = len(self._trackNameFilter) == 0 or (self._trackNameFilter != GenomeInfo.getLiteratureTrackName(self._genome))
        for trackName in OrigTrackNameSource(self._genome, self._trackNameFilter, avoidLiterature):
            try:                
                for rawGESource in self._allFileGESources():
                    geSourceManager = GESourceManager(rawGESource)
                    for allowOverlaps in [True, False]:
                        for chr in geSourceManager.getAllChrs():
                            geSource = geSourceManager.getSortedGESource(chr, allowOverlaps)
                            
                            TrackInfoDataCollector(self._genome, trackName).updateFileSizeInfoForPreProc \
                                (allowOverlaps, \
                                 geSourceManager.getNumElements(chr, allowOverlaps), \
                                 geSourceManager.getMaxSourceLineLen(chr))
                            
                            geSourceJob = PreProcessGeSourceJob(trackName, allowOverlaps, chr, geSource)
                            if geSourceJob.shouldPreProcess():
                                geSourceJob.process()
                                
                            TrackInfoDataCollector(self._genome, trackName).updatePreProcDirtyStatus \
                                (geSourceJob.hasModifiedData())
                            #trackJob.process(allowOverlaps)
                            #trackJob.ensureChrCreated(allowOverlaps)
                                            
                #if trackFinalizer.dirty():
                    #finalize..
                    #pass
                for allowOverlaps in [True,False]:
                    PreProcessUtils.ensureAllChrsCreated(self._genome, trackName, allowOverlaps)
                TrackInfoDataCollector(self._genome, trackName).finalizeIfDirty()

            except NotSupportedError, e:
                self._printExceptionMsg(e, Error=False)
                if self.PASS_ON_EXCEPTIONS:
                    raise
            except Exception, e:
                self._printExceptionMsg(e, Error=True)
                if self.PASS_ON_EXCEPTIONS:
                    raise

    #def _updateTrackInfo(self, trackName, allowOverlaps, numElements, maxLineLen):
    #    ti = TrackInfo(self._genome, trackName)
    #    
    #    ti.maxSourceLineLen = maxLineLen
        
    def _allFileGESources(self):
        baseDir = createOrigPath(self._genome, self._trackNameFilter,'')

        self._status = 'Trying os.listdir on: ' + baseDir
        for relFn in sorted(os.listdir( baseDir )):
            fn = baseDir + relFn

            self._status = 'Checking file: ' + fn
            if os.path.isdir(fn):
                continue
            
            fnPart = os.path.split(fn)[-1]
            if fnPart[0] in ['.','_','#'] or fnPart[-1] in ['~','#']: #to avoid hidden files..
                continue

            self._status = 'Trying to create geSource from fn: ' + fn
            yield GenomeElementSource(fn, self._genome)
            
    def _printExceptionMsg(self, e, Error=False):
        print (os.linesep + '--- BEGIN ERROR ---' + os.linesep *2 if Error else 'Warning! ') + 'Could not pre-process track. Status: ' + self._status
        print e.__class__.__name__ + ':', e
        if Error:
            traceback.print_exc(file=sys.stdout)
            print os.linesep + '--- END ERROR ---' + os.linesep
        
if __name__ == "__main__":
    if not len(sys.argv) in [2,3,4]:
        print 'Syntax: python PreProcessAllTracksJob.py genome [trackName:subType] [mode=Real/Simulated/UpdateMeta]'
        sys.exit(0)
        
    if len(sys.argv) == 2:
        tn = []
        mode = 'Real'
    elif len(sys.argv) == 3:
        if sys.argv[2] in ['Real', 'Simulated', 'UpdateMeta']:
            tn = []
            mode = sys.argv[2]
        else:
            tn = sys.argv[2].split(':')
            mode = 'Real'
    else:
        tn = sys.argv[2].split(':')
        mode = sys.argv[3]

    PreProcessGeSourceJob.MODE = mode
    assert PreProcessGeSourceJob.MODE in ['Real', 'Simulated', 'UpdateMeta']
    #fixme: UpdateMeta and Simulated should also hinder ensureChrCreated()
    PreProcessAllTracksJob(sys.argv[1], tn).process()

#TrackPreProcessor...:
#
#import os
#import sys
#import numpy
#from gold.application.Config import DEFAULT_GENOME
#from gold.origdata.GenomeElement import GenomeElement
#from gold.origdata.GenomeElementSorter import GenomeElementSorter
#from gold.origdata.GEOverlapClusterer import GEOverlapClusterer
#from gold.origdata.SortedAndNoOverlapsAsserter import SortedAndNoOverlapsAsserter
#from gold.origdata.OutputDirectory import OutputDirectory
#from gold.track.TrackFormat import TrackFormat
#from gold.util.CommonFunctions import createDirPath, parseDirPath
#from gold.origdata.GenomeElementSource import GenomeElementSource
#from quick.util.GenomeInfo import GenomeInfo
#from gold.util.CustomExceptions import NotValidGESequence, ShouldNotOccurError
#
#class TrackPreProcessor:
#    #@staticmethod
#    #def process(geSource, allowOverlaps = False):
#    #    try:
#    #        return TrackPreProcessor._process(SortedAndNoOverlapsAsserter(geSource), allowOverlaps)
#    #    except NotValidGESequence, e:
#    #        print 'Sorting and overlap removal is being performed on data source, due to: ', e, '<br>' 
#    #        if allowOverlaps:
#    #            sortedGESource = GenomeElementSorter(geSource)
#    #        else:
#    #            sortedGESource = GEOverlapClusterer(GenomeElementSorter(geSource))
#    #        sortedGESource.__iter__() #to load and sort data first for more accurate progress indication.. 
#    #        print 'Continuing preprocessing of data source..<br>'
#    #        return TrackPreProcessor._process(sortedGESource, allowOverlaps)
#    #
#    #@staticmethod    
#    #def _process(geSource, allowOverlaps):
#    #    dirMetaInfoDict, newDirsStartList = TrackPreProcessor._inferMetaData(geSource)
#    #    return TrackPreProcessor._createPreProcFiles(geSource, dirMetaInfoDict, newDirsStartList, allowOverlaps)
#
#    #@staticmethod
#    #def preProcFilesExists(geSource, allowOverlaps=False):
#    #    try:
#    #        ge = geSource.__iter__().next()
#    #        dirPath = createDirPath(geSource.getTrackName() + \
#    #                              (ge.subtype if ge.subtype is not None else []), ge.genome, ge.chr, allowOverlaps)
#    #        dir = OutputDirectory(dirPath, geSource.getPrefixList(), 1, 1, geSource.getValDataType(), geSource.getValDim())
#    #        return False
#    #    except IOError, e:
#    #        if str(e).strip().endswith('allready exists.'):
#    #            return True
#    #        else:
#    #            raise
#            
#    @staticmethod    
#    def _inferMetaData(geSource):
#        format = TrackFormat.createInstanceFromGeSource(geSource)
#    
#        #dir is here chr-directories
#        dirMetaInfoDict = {}
#        newDirsStartList = [0]
#        
#        if format  .reprIsDense():
#            geSource = geSource.__iter__() #fixme: should be called a geIter..
#            try:
#                ge = geSource.next()
#            except StopIteration:
#                raise ShouldNotOccurError
#            
#            dirMetaInfoDict[TrackPreProcessor._getSubDir(ge)] = \
#                (GenomeInfo.getChrLen(ge.genome, ge.chr), 0)
#        else:
#            prevSubDir = ''
#            maxLineLen = 0
#            i = 0
#            for i, ge in enumerate(geSource):
#                subDir = TrackPreProcessor._getSubDir(ge)
#                if subDir != prevSubDir:
#                    TrackPreProcessor._updateMetaData(dirMetaInfoDict, newDirsStartList, \
#                                                      prevSubDir, i, maxLineLen)
#                    maxLineLen = 0
#                    prevSubDir = subDir
#            
#                if ge.source is not None:
#                    maxLineLen = max(maxLineLen, len(ge.source))
#                    
#            TrackPreProcessor._updateMetaData(dirMetaInfoDict, newDirsStartList, prevSubDir, i+1, maxLineLen)
#        
#        return dirMetaInfoDict, newDirsStartList
#        #print newDirsStartList
#        #print dirMetaInfoDict        
#        #print sum(1 for ge in geSource)
#        
#    @staticmethod    
#    def _createPreProcFiles(geSource, dirMetaInfoDict, newDirsStartList, allowOverlaps):
#        dirDict = {}
#        newDirIndex = 0
#        for i, ge in enumerate(geSource):
#            if i == newDirsStartList[newDirIndex]:
#                if len(newDirsStartList) > newDirIndex+1:
#                    newDirIndex += 1
#                
#                if ge.subtype == None:
#                    trackName = geSource.getTrackName()
#                else:
#                    trackName = geSource.getTrackName() + ge.subtype
#                
#                dirPath = createDirPath(trackName, ge.genome, ge.chr, allowOverlaps)
#                if dirDict.has_key(dirPath):
#                    dir = dirDict[dirPath]
#                else:
#                    metaInfo = dirMetaInfoDict[TrackPreProcessor._getSubDir(ge)]
#                    dir = OutputDirectory(dirPath, geSource.getPrefixList(), metaInfo[0],\
#                                          GenomeInfo.getChrLen(ge.genome, ge.chr), \
#                                          geSource.getValDataType(), geSource.getValDim(), metaInfo[1])
#                    dirDict[dirPath] = dir
#            
#            dir.writeElement(ge)
#            
#        for dirPath, dir in dirDict.iteritems():
#            dir.close()
#
#        return i+1 #The number of genome elements processed
#
#    @staticmethod
#    def _getSubDir(ge):
#        return os.sep.join((ge.subtype if ge.subtype is not None else []) + [ge.chr])
#
#    @staticmethod
#    def _updateMetaData(dirMetaInfoDict, newDirsStartList, prevSubDir, i, maxLineLen):
#        if prevSubDir != '':
#            oldMeta = dirMetaInfoDict.get(prevSubDir)
#            if oldMeta is None:
#                oldMeta = (0,0)
#                
#            dirMetaInfoDict[prevSubDir] = (oldMeta[0] + (i - newDirsStartList[-1]),
#                                           max(oldMeta[1], maxLineLen))
#        if i != 0:
#            newDirsStartList.append(i)
#
#    @staticmethod
#    def ensureChrCreatedNew(genome, trackName, geSource, chrList=[], allowOverlaps=False):
#        TrackPreProcessor.ensureChrCreated(genome, trackName, geSource.getPrefixList(), geSource.getValDataType(), geSource.getValDim(), chrList, allowOverlaps)
#
#    # Create empty files for chromosomes in chrList that are not created yet for the trackname of geSource
#    @staticmethod
#    def ensureChrCreated(genome, trackName, prefixList, valDataType, valDim, chrList=[], allowOverlaps=False):
#        for chr in chrList:
#            dirPath = createDirPath(trackName, genome, chr, allowOverlaps)
#            #print dirPath
#            if not os.path.exists(dirPath):
#                print 'WARNING: Filling in empty chromosome: ', chr, '<br>'
#                chrLen = GenomeInfo.getChrLen(genome, chr)
#                format = TrackFormat.createInstanceFromPrefixList(prefixList, valDataType, valDim)
#                emptyGE = EmptyGenomeElement(genome, chr, prefixList)
#                
#                dir = OutputDirectory(dirPath, prefixList, chrLen if format.reprIsDense() else 1,
#                                      chrLen, valDataType, valDim)
#                if format.reprIsDense():
#                    for i in xrange(chrLen):
#                        dir.writeElement(emptyGE)
#                else:
#                    dir.writeElement(emptyGE)
#                dir.close()
#
#class EmptyGenomeElement(GenomeElement):
#    def __init__(self, genome, chr, prefixList):
#        emptyEl = {'start':-1, 'end':0, 'val':numpy.nan, 'strand':True, 'source':''}
#        kwArgs = {}
#        for prefix in prefixList:
#            kwArgs[prefix] = emptyEl[prefix]
#        GenomeElement.__init__(self, genome, chr, **kwArgs)
##
##if __name__ == "__main__":
##    if len(sys.argv) <=2:
##        print 'Syntax: python TrackPreprocessor.py fn trackname:subtype [genome]'
##        sys.exit(0)
##    fn = sys.argv[1]
##    trackName = sys.argv[2].split(':')
##    if len(sys.argv) > 3:
##        genome = sys.argv[3]
##    else:
##        genome = DEFAULT_GENOME
##    geSource = GenomeElementSource(fn, genome, trackName)
##    TrackPreProcessor.process(geSource)
##    TrackPreProcessor.ensureChrCreated(genome, geSource)
#    
