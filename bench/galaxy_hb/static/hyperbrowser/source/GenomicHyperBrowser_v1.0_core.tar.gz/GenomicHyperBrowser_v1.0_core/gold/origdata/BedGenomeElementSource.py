# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.origdata.GenomeElementSource import GenomeElementSource, SourceLineGESource
from gold.util.CommonFunctions import getStrandFromString
from gold.util.CustomExceptions import InvalidFormatError
import numpy

class BedGenomeElementSource(GenomeElementSource, SourceLineGESource):
    _VERSION = '1.1'
    _numHeaderLines = 0
    MIN_NUM_COLS = 3
    
    def __new__(cls, fn, *args, **kwArgs):
        if fn.endswith('.point.bed'):
            #return PointBedGenomeElementSource.__new__(PointBedGenomeElementSource, chr)
            geSource = PointBedGenomeElementSource.__new__(PointBedGenomeElementSource)
        elif fn.endswith('.category.bed'):
            geSource = BedCategoryGenomeElementSource.__new__(BedCategoryGenomeElementSource)
        elif fn.endswith('.marked.bed'):
            geSource = BedMarkedGenomeElementSource.__new__(BedMarkedGenomeElementSource)
        else:
            geSource = StdBedGenomeElementSource.__new__(StdBedGenomeElementSource)
        
        f = open(fn)
        possibleHeader = f.readline()
        if possibleHeader.startswith('track'):
            geSource._numHeaderLines = 1
        return geSource

class StdBedGenomeElementSource(BedGenomeElementSource):
    def __new__(cls, *args, **kwArgs):
        return object.__new__(cls)

    def _next(self, line):
        cols = line.split()
        if len(cols) < self.MIN_NUM_COLS:
            raise InvalidFormatError('File must contain at least '+ str(self.MIN_NUM_COLS) +' columns: ' + str(cols))

        self._genomeElement.chr = self._checkValidChr(cols[0])
        self._genomeElement.start = self._checkValidStart(self._genomeElement.chr, int(cols[1]))
        self._parseEnd( self._checkValidEnd(self._genomeElement.chr, int(cols[2])) )
        self._parseVal( cols )
        
        if len(cols) >= 6:
            self._genomeElement.strand = getStrandFromString(cols[5])
        
        return self._genomeElement
    
    def _parseEnd(self, end):
        self._genomeElement.end = end

    def _parseVal(self, cols):
        pass

class PointBedGenomeElementSource(StdBedGenomeElementSource):    
    def _parseEnd(self, end):
        if end != self._genomeElement.start + 1:
            raise InvalidFormatError('Point bed files can only have segments of length 1')

class BedMarkedGenomeElementSource(StdBedGenomeElementSource):
    _VERSION = '1.0'
    MIN_NUM_COLS = 5    
    
    def _parseVal(self, cols):
        self._genomeElement.val = numpy.float(self._handleNan(cols[4]))
    
class BedCategoryGenomeElementSource(StdBedGenomeElementSource):
    _VERSION = '1.5'
    MIN_NUM_COLS = 4    
    def _parseVal(self, cols):
        valStr = cols[3]
        if len(valStr) > self.CATEGORY_MAX_STRLEN:
            raise InvalidFormatError('Category string length exceeds maximum of ' + str(self.CATEGORY_MAX_STRLEN))
        
        #if self._depth == 0:
        self._genomeElement.val = cols[3]
        #elif self._depth == 1:
        #    self._genomeElement.subtype = [cols[3]]
        #else:
        #   raise InvalidFormatError('Bed category file should have depth of 0 or 1. Depth: ' + str(self._depth))
    
    def getValDataType(self):
        return self.CATEGORY_DATA_TYPE

    #def getCategorySet(self):