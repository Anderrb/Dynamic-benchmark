# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from math import floor, ceil
from gold.track.TrackView import TrackView
from gold.formatconversion.FormatConverter import FormatConverter
from gold.track.VirtualNumpyArray import VirtualNumpyArray
import numpy

class VirtualStartFromInterval(VirtualNumpyArray):
    def __init__(self, startArray, endArray, strandArray):
        self._startArray = startArray
        self._endArray = endArray
        self._strandArray = strandArray
            
    def __getslice__(self, i, j):
        if self._strandArray != None:
            return self.__class__(self._startArray[i:j], self._endArray[i:j], self._strandArray[i:j])
        else:
            return self.__class__(self._startArray[i:j], self._endArray[i:j], None)
    
    def __len__(self):
        return len(self._startArray)
    
class VirtualStartFromIntervalStart(VirtualStartFromInterval):
    def __getitem__(self, key):
        if self._strandArray == None or self._strandArray[key]:
            return self._startArray[key]
        else:
            return self._endArray[key] - 1
        
    def _asNumpyArray(self):
        if self._strandArray == None:
            return self._startArray
        else:
            return numpy.where(self._strandArray, self._startArray, self._endArray-1)
            #return self._startArray * self._strandArray + (self._endArray-1) * (1-self._strandArray)
            #return numpy.array([ (self._startArray[i] if self._strandArray[i] else self._endArray[i]-1) \
                                 #for i in xrange(len(self._startArray))])
        
class VirtualStartFromIntervalMid(VirtualStartFromInterval):
    def __getitem__(self, key):
        return (self._endArray[key] + self._startArray[key]) / 2
        #if self._strandArray == None or self._strandArray[key]:
        #    return (self._endArray[key]-1 + self._startArray[key]) / 2
        #else:
        #    return (self._endArray[key] + self._startArray[key]) / 2

    def _asNumpyArray(self):
        return (self._endArray + self._startArray) / 2

#class VirtualStartFromIntervalMidCeil(VirtualStartFromInterval):
#    def __getitem__(self, key):
#        if self._strandArray == None or self._strandArray[key]:
#            return int(ceil((self._endArray[key]-1 + self._startArray[key]) / 2.0))
#        else:
#            return int(floor((self._endArray[key]-1 + self._startArray[key]) / 2.0))

class VirtualStartFromIntervalEnd(VirtualStartFromInterval):
    def __getitem__(self, key):
        if self._strandArray == None or self._strandArray[key]:
            return self._endArray[key] - 1
        else:
            return self._startArray[key]

    def _asNumpyArray(self):
        if self._strandArray == None:
            return self._endArray - 1
        else:
            return numpy.where(self._strandArray, self._endArray-1, self._startArray)
            #return (self._endArray-1) * self._strandArray + self._startArray * (1-self._strandArray)
            
            #return numpy.array([ (self._endArray[i]-1 if self._strandArray[i] else self._startArray[i]) \
            #                     for i in xrange(len(self._startArray))])


class SegmentToPointFormatConverter(FormatConverter):
    @classmethod
    def convert(cls, tv):
        startList = cls._virtualListClass(tv._startList, tv._endList, tv._strandList)
        valList = tv._valList
        strandList = tv._strandList
        mayContainOverlaps = tv.mayHaveOverlaps
        
        if mayContainOverlaps and len(startList) >= 2:
            #What we really want to do is:
            #sortedZippedList = sorted(zip(startList, valList, strandList) ))
            #startList, valList, strandList = zip(*sortedZippedList)
            #But, since valList or strandList may be None:

            sortedZippedList = sorted(zip(*( [startList] + \
                                             ([valList] if valList is not None else []) + \
                                             ([strandList] if strandList is not None else []) )))
            x = zip(*sortedZippedList)
            startList = x.pop(0)
            if valList is not None:
                valList = x.pop(0)
            if strandList is not None:
                strandList = x.pop(0)
            assert(x == [])
            
        newTv = TrackView(tv.genomeAnchor, startList, None, valList, strandList, None, tv.borderHandling, tv.mayHaveOverlaps)
        newTv = newTv[:]
        return newTv
    
    @classmethod
    def _canHandle(cls, sourceFormat, reqFormat):
        isSegmentToPoint = sourceFormat.isInterval() and not sourceFormat.isDense() and not reqFormat.isInterval() and not reqFormat.isDense()
        return isSegmentToPoint
    
    @classmethod
    def _getTrackFormatExceptionList(cls):
        return ['interval','dense']
    
class SegmentToStartPointFormatConverter(SegmentToPointFormatConverter):
    _virtualListClass = VirtualStartFromIntervalStart
    def getOutputDescription(self, sourceFormatName):
        return "The upstream end point of every segment (converted from '" + sourceFormatName + "')"
    
class SegmentToMidPointFormatConverter(SegmentToPointFormatConverter):
    _virtualListClass = VirtualStartFromIntervalMid
    def getOutputDescription(self, sourceFormatName):
        return "The middle point of every segment (converted from '" + sourceFormatName + "')"

class SegmentToEndPointFormatConverter(SegmentToPointFormatConverter):
    _virtualListClass = VirtualStartFromIntervalEnd
    def getOutputDescription(self, sourceFormatName):
        return "The downstream end point of every segment (converted from '" + sourceFormatName + "')"
