# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.


from copy import copy
import numpy
import weakref
from gold.track.GenomeRegion import GenomeRegion
from gold.track.TrackFormat import TrackFormat
from gold.track.VirtualPointEnd import VirtualPointEnd
from gold.util.CustomExceptions import NotImplementedError
from gold.track.SmartMemmap import SmartMemmap
from gold.application.LogSetup import logMessageOnce
from gold.util.CommonFunctions import getClassName
from gold.application.Config import VERBOSE
import traceback

numpy.seterr(all='raise', under='ignore', invalid='ignore')

class TrackElement(object):
    def __init__(self, trackView):
        """trackview has a trackelement variable.
        trackelement has a weak ref back. Should that be necessary?
        index is never changed locally (but through trackview ...)"""
        # Weak proxy is used to remove memory leak caused by circular reference when TrackView is deleted
        self._trackView = weakref.proxy(trackView)
        self._index = -1
        
    def start(self):
        """startpossisjonen gitt som offset fra genomeAnchor.start, 
        gitt at genomeAnchor ligger bak startList[index].        
        ?"""
        candidate = self._trackView._startList[self._index] - self._trackView.genomeAnchor.start
        return candidate if candidate>0 else 0

    def end(self):
        "min(rawEnd,anchorEnd) - genomeAnchor.start?"
        rawEnd = self._trackView._endList[self._index]
        anchorEnd = self._trackView.genomeAnchor.end
        return (rawEnd if rawEnd<anchorEnd else anchorEnd) - self._trackView.genomeAnchor.start
    
    def val(self):
        return self._trackView._valList[self._index]

    def strand(self):
        ''
        return self._trackView._strandList[self._index]

    def source(self):
        '??'
        return self._trackView._sourceList[self._index]

    def none(self):
        return None
    
    def __len__(self):
        ''
        length = self.end() - self.start()
        assert(length >= 0)
        return length
    
class AutonomousTrackElement(TrackElement):
    "Uses absoulute positions and not offset from genomeAnchor. ?"
    def __init__(self, start = None, end = None, val = None, strand = None, source = None, trackEl=None):
        
        if trackEl is None:
            self._start = start
            self._end = end
            self._val = val
            self._strand = strand
            self._source = source
        else:
            assert(all(el is None for el in [start,end,val,strand,source]))
            self._start = trackEl.start()
            self._end = trackEl.end()
            self._val = trackEl.val()
            self._strand = trackEl.strand()
            self._source = trackEl.source()
            
    def start(self):
        return self._start

    def end(self):
        return self._end
    
    def val(self):
        return self._val

    def strand(self):
        return self._strand
    
    def source(self):
        return self._source
        
class TrackView(object):

    def _handlePointsAndPartitions(self):
        "create a dense view of partition if format is dense.?"
        if self.trackFormat.isDense() and not self.trackFormat.reprIsDense():
            self._startList = self._endList[:-1]
            self._endList = self._endList[1:]
            if self._valList!=None:
                self._valList = self._valList[1:]
            if self._strandList!=None:
                self._strandList = self._strandList[1:]
            if self._sourceList!=None:
                self._sourceList = self._sourceList[1:]
        if not self.trackFormat.isDense() and not self.trackFormat.isInterval():
            self._endList = VirtualPointEnd(self._startList)
    
    def __init__(self, genomeAnchor, startList, endList, valList, strandList, sourceList, borderHandling, mayHaveOverlaps):
        "genomeAnchor er en instans av GenomeRegion"
        assert(startList!=None or endList!=None or valList!=None)
        assert(borderHandling in ['crop']) # ? crop?  
        
        self.genomeAnchor = copy(genomeAnchor)
        self.trackFormat = TrackFormat(startList, endList, valList, strandList) # trackformat? TODO
        self.borderHandling = borderHandling
        self.mayHaveOverlaps = mayHaveOverlaps
        
        self._trackElement = TrackElement(self)
        self._bpLevelArray = None

        self._startList = startList
        self._endList = endList
        self._valList = valList
        self._strandList = strandList
        self._sourceList = sourceList
        
        self._handlePointsAndPartitions()
        
        if self._startList == None:
            self._trackElement.start = self._trackElement.none
        if self._endList == None:
            self._trackElement.end = self._trackElement.none
        if self._valList == None:
            self._trackElement.val = self._trackElement.none
        if self._strandList == None:
            self._trackElement.strand = self._trackElement.none
        if self._sourceList == None:
            self._trackElement.source = self._trackElement.none
        
        self._updateNumListElements()

        for list in [self._startList, self._endList, self._valList, self._strandList, self._sourceList]:
            assert list == None or len(list) == self._numListElements, 'List: ' + str(list) + ' (expected %s elements)' % str(self._numListElements)
    
    def __iter__(self):
        "lar trackelement refere til neste element(bin).?"
        self._trackElement._index = -1
        return self
    
    def _updateNumListElements(self):
        ""
        self._numListElements = self._computeNumListElements()

    def _computeNumListElements(self):
        "length of first array with value. all arrays must have equal length?"
        for list in [self._startList, self._endList, self._valList, self._strandList, self._sourceList]:
            if list != None:
                return len(list)
        return 0
            
    def __len__(self):
        ""
        return self._bpSize()
    
    def getNumElements(self):
        ""
        return self._numListElements
    
    def _bpSize(self):
        "genomeAnchor.... ggrr... binsize?"
        return len(self.genomeAnchor)
    
    def next(self):
        """gir neste element i iterasjonen. while-testen boer skrives om.
        skjoenner litt av poenget, men ikke alt. ?
        """
        self._trackElement._index += 1
        
        #To remove any blind passengers - segments entirely in front of genomeanchor,
        # but sorted after a larger segment crossing the border
        if self.mayHaveOverlaps and not self.trackFormat.reprIsDense():
            while self._trackElement._index < self._numListElements and self._endList[self._trackElement._index] <= self.genomeAnchor.start: #self._trackElement.end() <= 0:
                self._trackElement._index += 1
            
        if self._trackElement._index < self._numListElements:
            return self._trackElement
        else:
            raise StopIteration

    def _findLeftIndex(self):
        'first end index inside bin?'
        leftIndex = 0
        #remove track elements entirely to the left of the anchor
        while leftIndex < len(self._endList) and self._endList[leftIndex] <= self.genomeAnchor.start:
            leftIndex += 1
        return leftIndex
    
    def _findRightIndex(self):
        'last start index inside bin?'
        rightIndex = self._numListElements
        while rightIndex > 0 and self._startList[rightIndex-1] >= self.genomeAnchor.end:
            rightIndex -= 1
        return rightIndex
    
    def sliceElementsAccordingToGenomeAnchor(self):
        assert( not self.trackFormat.reprIsDense() )
        self._doScatteredSlicing()
        
    def _doScatteredSlicing(self):
        "slicer ned til bin (genomeAnchor) size? "
        leftIndex = self._findLeftIndex()  
        rightIndex = self._findRightIndex()    
        
        if self._bpSize() == 0:
            rightIndex = leftIndex
        
        self._startList = self._startList[leftIndex:rightIndex]
        self._endList = self._endList[leftIndex:rightIndex]

        if self._valList != None:
            self._valList = self._valList[leftIndex:rightIndex]
        if self._strandList != None:
            self._strandList = self._strandList[leftIndex:rightIndex]
        if self._sourceList != None:
            self._sourceList = self._sourceList[leftIndex:rightIndex]
        self._updateNumListElements()

    def _doDenseSlicing(self, i, j):
        "litt usikker paa dense..?"
        if self._valList != None:
            self._valList = self._valList[i:j]
        if self._strandList != None:
            self._strandList = self._strandList[i:j]
        if self._sourceList != None:
            self._sourceList = self._sourceList[i:j]
        self._updateNumListElements()
            
    def __getslice__(self, i, j):
        "gir tilbake et nytt view tilpasset slicen."
        slicedTV = TrackView(self.genomeAnchor, self._startList, self._endList, \
                             self._valList, self._strandList, self._sourceList, \
                             self.borderHandling, self.mayHaveOverlaps)
        slicedTV.trackFormat = self.trackFormat
        
        slicedTV.genomeAnchor.start += i
        if j>=0:
            slicedTV.genomeAnchor.end = min(self.genomeAnchor.end, self.genomeAnchor.start + j)
        if j<0:
            slicedTV.genomeAnchor.end += j

        if self.trackFormat.reprIsDense():
            slicedTV._doDenseSlicing(i,j)
        else:
            slicedTV._doScatteredSlicing()
        return slicedTV

    def __getitem__(self, key):
        self._createBpLevelArray()
        return self._bpLevelArray[key]
    
    def startsAsNumpyArray(self):
        "returnerer numpy array med offset fra genomeAnchor.start?"
        try:
            assert(self.borderHandling in ['crop'])
            assert not self.mayHaveOverlaps, '..asNumpyArray not supported with overlaps'
            #if self.mayHaveOverlaps or not (isinstance(self._startList, numpy.ndarray) or isinstance(self._startList, SmartMemmap)):
                #return numpy.array([el.start() for el in self])
            
            starts = self._startList - self.genomeAnchor.start #starts here becomes a standard numpy-array even if self._startList is a virtual array. If this line is removed, we should ensure this conversion in other ways..
            index=0
            while index<len(starts) and starts[index]<0:
                starts[index]=0
                index+=1
            return starts
        except Exception, e:
            if VERBOSE or getClassName(e) != 'AssertionError':                
                logMessageOnce('Had to rely on slow construction of startsAsNumpyArray with list class: ' + \
                              getClassName(self._startList) + ' and exception: ' + getClassName(e) + ': ' + str(e) +'. ')
            if VERBOSE:
                logMessageOnce(traceback.format_exc())
            if self._startList is None:
                return None
            else:
                return numpy.array([el.start() for el in self])
        
        
    def endsAsNumpyArray(self):
        "returnerer numpy array med offset fra genomeAnchor.start?"        
        try:
            assert(self.borderHandling in ['crop'])
            assert(not self.mayHaveOverlaps)
            #if self.mayHaveOverlaps or not (isinstance(self._endList, numpy.ndarray) or isinstance(self._endList, SmartMemmap)):
            #return numpy.array([el.end() for el in self])
            ends = self._endList - self.genomeAnchor.start
            index=len(ends)-1
            while index>=0 and ends[index]>len(self.genomeAnchor): #Only works with not self.mayHaveOverlaps, as ends need not be sorted otherwise
                ends[index]=len(self.genomeAnchor)
                index-=1
            return ends
        except Exception, e:
            if VERBOSE or getClassName(e) != 'AssertionError':
                logMessageOnce('Had to rely on slow construction of endsAsNumpyArray with list class: ' + \
                            getClassName(self._endList) + ' and exception: ' + getClassName(e) + ': ' + str(e) +'. ')
    
            if self._endList is None:
                return None
            else:
                return numpy.array([el.end() for el in self])
            
    def valsAsNumpyArray(self):
        ''
        try:
            assert(self.borderHandling in ['crop'])
            assert(not self.mayHaveOverlaps)
            return self._valList
        except Exception, e:
            if VERBOSE or getClassName(e) != 'AssertionError':
                logMessageOnce('Had to rely on slow construction of ..asNumpyArray with list class: ' + \
                            getClassName(self._valList) + ' and exception: ' + getClassName(e) + ': ' + str(e) +'. ')
    
            if self._valList is None:
                return None
            else:
                return numpy.array([el.val() for el in self])
    
    def strandsAsNumpyArray(self):
        ''
        try:
            assert(self.borderHandling in ['crop'])
            assert(not self.mayHaveOverlaps)
            return self._strandList
        except Exception, e:
            if VERBOSE or getClassName(e) != 'AssertionError':
                logMessageOnce('Had to rely on slow construction of ..asNumpyArray with list class: ' + \
                            getClassName(self._strandList) + ' and exception: ' + getClassName(e) + ': ' + str(e) +'. ')
    
            if self._strandList is None:
                return None
            else:
                return numpy.array([el.strand() for el in self])        
    
class TrackViewSlider(object):
    def __init__(self, fullTV):
        self._fullTV = fullTV
        self._slideTV = None
        self._prevStart = None
        self._prevEnd = None
        self._prevLeftIndex = None
        self._prevRightIndex = None
        
    def slideTo(self, start, end):
        if self._fullTV.trackFormat.reprIsDense():
            return self._fullTV[start:end]
        
        if self._slideTV is None:
            self._slideTV = self._fullTV[start:end]
            self._prevStart = start
            self._prevEnd = end
            
            tempFullTVStart = self._fullTV.genomeAnchor.start
            tempFullTVEnd = self._fullTV.genomeAnchor.end
            self._fullTV.genomeAnchor.start = start
            self._fullTV.genomeAnchor.end = end
            self._prevLeftIndex = self._fullTV._findLeftIndex()  
            self._prevRightIndex = self._fullTV._findRightIndex()
            self._fullTV.genomeAnchor.start = tempFullTVStart
            self._fullTV.genomeAnchor.end = tempFullTVEnd
        else:        
            assert start in [self._prevStart, self._prevStart+1]
            assert end in [self._prevEnd, self._prevEnd+1]
        
            if start == self._prevStart+1:
                self._slideStart()
            if end == self._prevEnd+1:
                self._slideEnd()
        return self._slideTV

    def _slideStart(self):
        start = self._prevStart+1
        if len(self._slideTV._endList) == 0:
            self._prevStart += 1
            return
        
        if self._slideTV._endList[0] <= start:
            self._slideTV._startList = self._slideTV._startList[1:]
            self._slideTV._endList = self._slideTV._endList[1:]
    
            if self._slideTV._valList != None:
                self._slideTV._valList = self._slideTV._valList[1:]
            if self._slideTV._strandList != None:
                self._slideTV._strandList = self._slideTV._strandList[1:]
            if self._slideTV._sourceList != None:
                self._slideTV._sourceList = self._slideTV._sourceList[1:]
            self._slideTV._updateNumListElements()
            self._prevLeftIndex += 1
            
        self._slideTV.genomeAnchor.start += 1         
        self._prevStart = start
        
    def _slideEnd(self):
        end = self._prevEnd+1
        endIndex = self._prevRightIndex
        if endIndex >= len(self._fullTV._startList):
            self._prevEnd += 1
            return

        if self._fullTV._startList[endIndex] < end:
            self._slideTV._startList = self._fullTV._startList[self._prevLeftIndex:endIndex+1]
            self._slideTV._endList = self._fullTV._endList[self._prevLeftIndex:endIndex+1]
    
            if self._slideTV._valList != None:
                self._slideTV._valList = self._fullTV._valList[self._prevLeftIndex:endIndex+1]
            if self._slideTV._strandList != None:
                self._slideTV._strandList = self._fullTV._strandList[self._prevLeftIndex:endIndex+1]
            if self._slideTV._sourceList != None:
                self._slideTV._sourceList = self._fullTV._sourceList[self._prevLeftIndex:endIndex+1]
            self._slideTV._updateNumListElements()
            self._prevRightIndex = endIndex + 1
        
        self._slideTV.genomeAnchor.end += 1         
        self._prevEnd = end
                