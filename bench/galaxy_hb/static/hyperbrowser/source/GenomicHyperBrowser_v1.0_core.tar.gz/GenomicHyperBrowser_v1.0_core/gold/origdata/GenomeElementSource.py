# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.origdata.GenomeElement import GenomeElement
from quick.util.GenomeInfo import GenomeInfo
from gold.application.Config import FILE_READ_BUFFER_SIZE
from gold.util.CustomExceptions import NotSupportedError, InvalidFormatError, InvalidFormatWarning, Warning
import os.path
import os
from copy import copy
from gold.application.LogSetup import logException

class GenomeElementSource(object):
    CATEGORY_MAX_STRLEN = 150
    CATEGORY_DATA_TYPE = 'S' + str(CATEGORY_MAX_STRLEN)
    _VERSION = '0.0'

    def __new__(cls, fn, *args, **kwArgs):
        if fn.endswith('.bed'):
            return BedGenomeElementSource.__new__(BedGenomeElementSource, fn, *args, **kwArgs)
#        elif fn.endswith('.txt'):
#            return UCSCGenomeElementSource.__new__(UCSCGenomeElementSource, fn, *args, **kwArgs)
        elif fn.endswith('.gff') or fn.endswith('.gtf'):
            return GffGenomeElementSource.__new__(GffGenomeElementSource, fn, *args, **kwArgs)
        elif fn.endswith('.fa') or fn.endswith('.fas') or fn.endswith('.fasta'):
            return FastaGenomeElementSource.__new__(FastaGenomeElementSource, fn, *args, **kwArgs)
        elif fn.endswith('.wig') or fn.endswith('.customtrack') or fn.endswith('.bedGraph'):
            return WigGenomeElementSource.__new__(WigGenomeElementSource, fn, *args, **kwArgs)
        elif fn.endswith('.microarray'):
            return MicroarrayGenomeElementSource.__new__(MicroarrayGenomeElementSource, fn, *args, **kwArgs)
        elif fn.endswith('.hbfunction'):
            return HBFunctionGenomeElementSource.__new__(HBFunctionGenomeElementSource, fn, *args, **kwArgs)
        else:
            raise NotSupportedError('File type ' + os.path.splitext(fn)[1] + ' not supported.')
    
    def __init__(self, fn, genome=None, trackName=None): #, depth=0
        self._fn = fn
        self._genome = genome
        self._genomeElement = GenomeElement(genome)
        self._trackName = trackName
        #self._depth = depth
        self._prefixList = None
        self._storeSourceLine = isinstance(self, SourceLineGESource)
        
    def getTrackName(self):
        return self._trackName

    def getGenome(self):
        return self._genome
    
    def getFileName(self):
        return self._fn
    
    def getFileSuffix(self):
        fnParts = os.path.basename(self._fn).split('.')
        return '.'.join(fnParts[-2:] if len(fnParts) > 2 else fnParts[-1:])
    
    def next(self):
        line = self._file.readline().strip()
        if line=='' and not self._anyPendingElements():
            raise StopIteration
        if self._storeSourceLine:
            self._genomeElement.source = line
        try:
            return self._next(line)
        except Warning, e:
            print os.linesep + 'Warning in line: ' + line + ' - ' + str(e) + '. Skipping line.'
            return self.next()
        except Exception, e:
            print os.linesep + 'Error in line: ' + line + ' - ' + str(e)
            raise
    
    def _anyPendingElements(self):
        return False
    
    def _readHeaders(self, file):
        self.headers = [file.readline() for i in xrange(self._numHeaderLines)]
    
    def _getFileNoHeaders(self):
        file = open(self._fn, 'U', FILE_READ_BUFFER_SIZE)
        self._readHeaders(file)
        return file
        
    def __iter__(self):
        self._file = self._getFileNoHeaders()
        return copy(self)._iter()

    def _iter(self):
        return self
    
    def _checkValidChr(self, chr):
        fixedChr = GenomeInfo.fixChr(chr)
        if not GenomeInfo.isValidChr(self.genome, fixedChr):
            #if fixedChr in GenomeInfo.getExtendedChrList(self.genome):
                #pass
                #if not hasattr(self,'_chrsNotPresent'):
                    #self._chrsNotPresent = set()
                #if fixedChr not in self._chrsNotPresent:
                #    self._chrsNotPresent.add(fixedChr)
                    #print 'Warning: chromosome ' + fixedChr + ' not part of standard chromosome set..'
            #else:
            raise InvalidFormatWarning('Chromosome incorrectly specified: ' + chr)
        return fixedChr
    
    def _checkValidStart(self, chr, start):
        if GenomeInfo.isValidChr(self.genome, chr) and \
            start > GenomeInfo.getChrLen(self.genome, chr):
                raise InvalidFormatError('Start position is larger than chromosome size (%s)' % \
                                         GenomeInfo.getChrLen(self.genome, chr))
        return start
    
    def _checkValidEnd(self, chr, end):
        if GenomeInfo.isValidChr(self.genome, chr) and \
            end-1 > GenomeInfo.getChrLen(self.genome, chr):
#                return GenomeInfo.getChrLen(self.genome, chr)
                raise InvalidFormatError('End position is larger than chromosome size (%s)' % \
                                         GenomeInfo.getChrLen(self.genome, chr))
        return end
    
    def _handleNan(self, str):
        if str.lower() in ['na', 'nan', 'not a number', 'n/a', 'none']:
            return 'nan'
        return str
    
    def getPrefixList(self):
        if self._prefixList is None:
            try:
                ge = self.__iter__().next()
            except StopIteration:
                raise InvalidFormatError('Source file is empty')
            except Exception, e:
                logException(e)
                raise e
            self._prefixList = [prefix for prefix in ['start', 'end', 'val', 'strand', 'source'] if ge.__dict__.get(prefix) != None]
        return self._prefixList
        
    def getValDataType(self):
        return 'float32'

    def getValDim(self):
        return 1
    
    def getVersion(self):
        return self._VERSION
    
    genome = property(getGenome)
    
class SourceLineGESource(object):
    pass

# To avoid circular imports
from gold.origdata.BedGenomeElementSource import BedGenomeElementSource
from gold.origdata.GffGenomeElementSource import GffGenomeElementSource
from gold.origdata.FastaGenomeElementSource import FastaGenomeElementSource
from gold.origdata.HBFunctionGenomeElementSource import HBFunctionGenomeElementSource
#from gold.origdata.UCSCGenomeElementSource import UCSCGenomeElementSource
from gold.origdata.WigGenomeElementSource import WigGenomeElementSource
from gold.origdata.MicroarrayGenomeElementSource import MicroarrayGenomeElementSource
