# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.result.Results import Results
from gold.result.HtmlCore import HtmlCore
from gold.result.GlobalValuePresenter import GlobalValuePresenter, ForgivingGlobalValuePresenter
from gold.result.MatrixGlobalValuePresenter import MatrixGlobalValueFromNumpyPresenter, MatrixGlobalCountsPresenter, \
     MatrixGlobalPvalPresenter, MatrixGlobalSignificancePresenter, MatrixGlobalValueFromDictOfDictsPresenter
#from gold.result.FDRSummaryPresenter import FDRSummaryPresenter
from gold.result.TablePresenter import TablePresenter
from gold.result.TableFromDictOfDictsPresenter import TableFromDictOfDictsPresenter
#from gold.result.WigPresenter import WigPresenter
from gold.result.BedGraphPresenter import BedGraphPresenter
from gold.result.HistogramPresenter import HistogramPresenter, HistogramGlobalListPresenter
from gold.result.DensityPresenter import DensityPresenter, DensityGlobalListPresenter
from gold.result.HeatmapPresenter import HeatmapFromNumpyPresenter, HeatmapFromDictOfDictsPresenter
from gold.result.ScatterPresenter import ScatterPresenter
from gold.result.GlobalVectorPresenter import GlobalMeanSdVectorPresenter
from gold.result.GwPlotPresenter import GwPlotPresenter
from quick.presenter.RawTextTablePresenter import RawTextTablePresenter
from gold.util.CommonFunctions import getClassName, strWithPrecision, strWithDecimals
from gold.util.CustomExceptions import InvalidRunSpecException, ShouldNotOccurError, AbstractClassError
#from quick.application.LocalOSConfig import brk
from quick.presenter.ProcessedScatterPresenter import MeanLinePresenter,BinHistPresenter
from gold.description.AnalysisDefHandler import AnalysisDefHandler
from gold.application.LogSetup import logException, logMessage
from copy import copy
from logging import WARNING
from quick.util.CommonFunctions import getRelativeUrlFromWebPath

import os
import re

class ResultsViewerCollection(object):
    def __init__(self, resultsList, baseDir):
        self._viewers = []
        if len(resultsList) > 1:
            self._viewers.append(MultiBatchResultsViewer(resultsList, baseDir))
        for i,results in enumerate(resultsList):
            self._viewers.append(ResultsViewer(results, os.sep.join([baseDir,str(i)]) ))

    def __str__(self):
        core = HtmlCore()
        
        #core.begin()
        for i,viewer in enumerate(self._viewers):
            core.paragraph(str(viewer))
            if i < len(self._viewers)-1:
                core.divider(withSpacing=True)
        #core.end()

        return str(core)

class ResultsViewer(object):
    def __new__(self, results, baseDir):
        presCollectionType = results.getPresCollectionType()
        if presCollectionType == 'standard':
            return StandardResultsViewer.__new__(StandardResultsViewer, results, baseDir)
        elif presCollectionType == 'distribution':
            return DistributionResultsViewer.__new__(DistributionResultsViewer, results, baseDir)
        elif presCollectionType == 'dictofdicts':
            return MatrixResultsViewer.__new__(DictOfDictsResultsViewer, results, baseDir)
        elif presCollectionType == 'matrix':
            return MatrixResultsViewer.__new__(MatrixResultsViewer, results, baseDir)
        if presCollectionType == 'scatter':
            return ScatterResultsViewer.__new__(ScatterResultsViewer, results, baseDir)
        if presCollectionType == 'binscaled':
            return BinscaledResultsViewer.__new__(BinscaledResultsViewer, results, baseDir)

class ResultsViewerBase(ResultsViewer):
    def __new__(self, results, baseDir):
        return object.__new__(self)
    
    def __init__(self, results, baseDir):
        self._results = results
        self._baseDir = baseDir
        self._str = None
        
    def __str__(self):
        if self._str is not None:
            return self._str
                
        self._results.inferAdjustedPvalues()
        self._presenters = []
        if len(self._results.getAllRegionKeys()) > 0:
            self._addAllPresenters()        
        #print self._generateHeader()
        #print self._generateErrorText()
        #print self._generateTable(presenters)
        
        hideTable = False
        coreCls = HtmlCore
        
        try:
            if self._results.isSignificanceTesting():
                startText = self._generateAnswerText(coreCls)
                hideTable = True
            else:
                startText = self._generateHeader(coreCls)
        except Exception,e:
            startText = self._generateHeader(coreCls)
            logException(e, message='Error producing autogenerated result')
            logException(e,message='Error in auto-generated answer')
        
        return startText + self._generateRunDescription() + self._generateErrorText(coreCls) + \
               self._generateTable(coreCls, hideTable)

    def _getH0andH1Text(self, coreCls):
        h0 = self._results._analysis.getH0()
        h1 = self._results._analysis.getH1()
        if not None in (h0,h1):
            core = coreCls()
            core.descriptionLine('H0', h0, indent=True)
            core.line('vs')
            core.descriptionLine('H1', h1, indent=True)
            return str(core)
        else:
            logMessage('Did not find H0 or H1. Their values: ' + str(h0) +' and ' + str(h1))
            return None

    def _getTestStatisticAndExpectedValues(self):
        globalRes = self._results.getGlobalResult()
        if globalRes is not None:
            tsValue = globalRes.get(self._results.getTestStatisticKey() )
            expTsValue = globalRes.get(self._results.getExpectedValueOfTsKey() )
            return tsValue,expTsValue
        else:
            return None, None

    def _generateAnswerText(self, coreCls):
        onlyLocalPvals = self._results.hasOnlyLocalPvals()
        globalPval = self._results.getGlobalResult().get(self._results.getPvalKey()) if not onlyLocalPvals else None

        localPvalsUrl = getRelativeUrlFromWebPath(os.sep.join([self._baseDir, 'table.html'])) #problematic dependency towards fn in tablePresenter..
        #Change to something like this when StaticFile has been used throughout presenters..
        #from quick.util.StaticFile import GalaxyRunSpecificFile
        #GalaxyRunSpecificFile([], '', self._galaxyFn)
        
        core = coreCls()
        core.styleInfoBegin(styleClass="infomessagesmall answerbox question")
        core.header('You asked:')
        core.line(str(coreCls().highlight(self._getHeader())))
        core.styleInfoEnd()
        
        #Simplistic answer
        core.styleInfoBegin(styleClass="infomessagesmall answerbox simplisticanswer")
        core.header(str(coreCls().link('Simplistic answer:', '#', \
                                        args='''onclick="return toggle('simplistic_answer_expl')"''')))
        
        core.styleInfoBegin(styleId="simplistic_answer_expl", styleClass="infomessagesmall explanation")
        if onlyLocalPvals :
            core.line('''
Under "simplistic answer" you will find a simple statement on whether there were any findings for the local analysis. The number of significant bins at 10% false discovery rate (FDR) is provided.<br>
<br>
It is not possible to draw a decisive conclusion based on a p-value, so the statements are only meant as simple indications.<br>
                  ''')
        else:
            core.line('''
Under "simplistic answer" you will find a yes/maybe/no-conclusion answer to the question asked, based on a simple thresholding scheme on the p-value:<br>
"yes" if p-value < 0.01<br>
"maybe" if  0.01 < p-value < 0.1<br>
"no conclusion" if p-value > 0.1<br>
<br>
It is not possible to draw a decisive conclusion based on a p-value, so the statements are only meant as simple indications.<br>                  
                  ''')
            
        core.styleInfoEnd()
        
        if onlyLocalPvals:
            numSign, numTested, numIgnored = self._results.getFdrSignBins()
            if numSign == numTested and numSign != 0:
                simplisticPhrase = 'Yes - the data suggests this for all bins'
            elif numSign>0:
                simplisticPhrase = 'Yes - the data suggests this at least in some bins'
                numSign, numTested, numIgnored = self._results.getFdrSignBins()
                simplisticPhrase += ' (%i significant bins out of %i, at %i%% FDR' % (numSign, numTested, self._results.FDR_THRESHOLD*100)
            else:
                simplisticPhrase = 'No support from data for this conclusion in any bin'
            
                
            core.line(str(coreCls().highlight(simplisticPhrase)))
        else:
            assert globalPval is not None
            
            directionality = ''
            if self._results._analysis.isTwoSidedTest():
                tsValue, expTsValue = self._getTestStatisticAndExpectedValues()
                if tsValue is not None and expTsValue is not None and tsValue!=expTsValue:
                    directionality = '(higher) ' if tsValue > expTsValue else '(lower) '
                    
            if globalPval < 0.01:
                simplisticPhrase = 'Yes %s- the data suggests this' % directionality
            elif globalPval < 0.1:
                simplisticPhrase = 'Maybe %s- weak evidence' % directionality
            else:
                simplisticPhrase = 'No support from data for this conclusion'
                
            core.line(str(coreCls().highlight(simplisticPhrase + ' (p-value: ' + strWithPrecision(globalPval) + ')' )))
        core.styleInfoEnd()
        
        #Precise answer
        core.styleInfoBegin(styleClass="infomessagesmall answerbox preciseanswer")
        core.header(str(coreCls().link('Precise answer:', '#', \
                                       args='''onclick="return toggle('precise_answer_expl')"''')))
        
        core.styleInfoBegin(styleId="precise_answer_expl", styleClass="infomessagesmall explanation")
        if onlyLocalPvals :
            core.line('''
Significance testing evaluates a <b>null hypothesis (H0)</b> versus an <b>alternative hypothesis (H1)</b>. Low <b>p-values</b> are evidence against H0. The testing involves comparing the observed value of a  <b>test statistic</b> to the distribution of the test statistic under a <b>null model</b>. The testing was performed in each local bin, with a list of FDR-corrected p-values per bin provided.                  
                  ''')
        else:
            core.line('''
Significance testing evaluates a <b>null hypothesis (H0)</b> versus an <b>alternative hypothesis (H1)</b>. Low <b>p-values</b> are evidence against H0. The testing involves comparing the observed value of a  <b>test statistic</b> to the distribution of the test statistic under a <b>null model</b>. 
                  ''')

        core.styleInfoEnd()
        
        EffectSizeText = 'Please note that both the effect size and the p-value should be considered in order to assess the practical significance of a result.'
        
        FDR_text = '* False Discovery Rate: The expected proportion of false positive results among the significant bins is no more than %i%%.' \
                    % (self._results.FDR_THRESHOLD*100)
        
        if onlyLocalPvals:
            numSign, numTested, numIgnored = self._results.getFdrSignBins()
            
            core.line(str(coreCls().highlight('%i significant bins out of %i, at %i' \
                                              % (numSign, numTested, self._results.FDR_THRESHOLD*100) + '% FDR*')))
            core.line('')
            localPvalsLink = str(coreCls().link('collection of FDR-corrected p-values per bin', localPvalsUrl))
            notComputeLink = str(coreCls().link('Not able to compute', '#', \
                                               args='''onclick="return toggle('no_global_pval_expl')"'''))
            core.line('A ' + localPvalsLink + ' was computed. ' + notComputeLink + ' a global p-value for this analysis.')
            core.styleInfoBegin(styleId="no_global_pval_expl", styleClass="infomessagesmall explanation")
            core.line('(Explanation to appear in box)')
            core.styleInfoEnd()
            
            if numIgnored > 0:
                core.line('')
                core.line('%s bin%s excluded due to lack of data.' % (numIgnored, 's' if numIgnored > 1 else ''))
                
            core.line('')
            core.line(EffectSizeText)
            core.line('')
            core.line(FDR_text)

            h0h1Text = self._getH0andH1Text(coreCls)
            if h0h1Text is not None:
                core.divider(withSpacing=True)
                core.line('In each bin, the test of')
                core.append(h0h1Text)
                core.line('was performed.')
        else:
            h0h1Text = self._getH0andH1Text(coreCls)
            if h0h1Text is not None:
                core.line('The p-value is %s for the test' % strWithPrecision(globalPval) )
                core.append(h0h1Text)
            else:
                core.line('The p-value is %s.' % strWithPrecision(globalPval) )
                core.line('')
            core.line('Low p-values are evidence against H0.')

            numSign, numTested, numIgnored = self._results.getFdrSignBins()
            if numTested+numIgnored > 1:                
                localPvalsLink = str(coreCls().link('each bin separately', localPvalsUrl))
                excludeText = ' (%i bin%s excluded from FDR-analysis due to lacking p-values).' \
                              % (numIgnored, 's' if numIgnored>1 else '.') if numIgnored>0 else ''
                core.line('')
                core.line('The test was also performed for ' + localPvalsLink + \
                          ', resulting in %i significant bins out of %i, at %i%% FDR*' % (numSign, numTested, self._results.FDR_THRESHOLD*100) +\
                          excludeText)

            core.line('')
            core.line(EffectSizeText)
            core.line('')
            core.line(FDR_text)
        
        nullModel = self._results._analysis.getNullModel()
        if nullModel is not None:
            core.divider(withSpacing=True)
            core.line('P-values were computed under the %s defined by the following preservation and randomization rules:' \
                      % str(coreCls().highlight('null model')))
            core.paragraph(nullModel, indent=True)

        testStatistic = self._results.getTestStatisticText()
        if testStatistic != None:
            #pick out relevant part:
            mo = re.search('^[tT]est.[sS]tatistic ?:? ?',testStatistic)
            if mo!= None:
                testStatistic = testStatistic[mo.end():]            
                #if len(testStatistic)>0 and testStatistic[0]=='(':
                    #testStatistic = testStatistic[1:]
                #if len(testStatistic)>0 and testStatistic[-1]==')':
                    #testStatistic = testStatistic[:-1]
            
            tsValue, expTsValue = self._getTestStatisticAndExpectedValues()
            core.divider(withSpacing=True)
            core.line('The %s used is:' % str(coreCls().highlight('test statistic')))
            core.paragraph(testStatistic, indent=True)
            
            if tsValue is not None:
                if expTsValue is not None:
                    core.line('The value of the test statistic is %s, which is %s the expected value: %s.' \
                                % (strWithDecimals(tsValue, 2), \
                                   (str(coreCls().emphasize('higher')) + ' than' if tsValue > expTsValue else \
                                    (str(coreCls().emphasize('lower')) + ' than' if tsValue < expTsValue else \
                                     str(coreCls().emphasize('equal')) + ' to')), \
                                   strWithDecimals(expTsValue, 2)))
                else:
                    core.line('The value of the test statistic is %s.' % (strWithDecimals(tsValue, 2)))
            
        #temporary solution, as lacking objects needed to construct note-link directly..
        noteText = ''
        if self._results._runDescription is not None:
            #mo = re.search('<note.*note>', self._results._runDescription)
            mo = re.search('<a href[^>]*/notes/[^>]*>[^<]*</a>', self._results._runDescription)
            if mo is not None:
                noteLink = mo.string[mo.start():mo.end()]
                noteText = ' See ' + noteLink + ' for a more complete description of the test.'
        
        if noteText == '':
            logMessage('Note-link not found in runDescription, and thus omitted from results')
            
        core.divider(withSpacing=True)
        
        runDescLink = str(coreCls().link('run description', '#', \
                                         args='''onclick="return toggle('run_description')"'''))
        core.line('The p-values may be subject to further parameter choices, which are listed in the %s.' %\
                  (runDescLink) + noteText)
        core.divider(withSpacing=True)
        resultsLink = str(coreCls().link('See full details', '#', \
                                         args='''onclick="return toggle('results_box')"'''))
        core.line(resultsLink + ' of the results in table form.')
        core.styleInfoEnd()
        
        return str(core)
        
    def _addAllPresenters(self):
        raise AbstractClassError
                
    def _addPresenter(self, presenterClass, sendHeader=False, **kwArgs):
        #print 'Generating figure: ',presenterClass.__name__,'<br>'
        try:
            pres = presenterClass(self._results, self._baseDir, *([self._getHeader()] if sendHeader else []), **kwArgs ) 
            self._presenters.append( pres)
            return pres
        except Exception,e:
            logException(e, WARNING, 'Error generating figure with ' + str(presenterClass.__name__))
            print 'Error generating figure with ', presenterClass.__name__, '(',Exception,' - ',e,')'
            return None
            
    def _generateHeader(self, coreCls):
        coreCls = HtmlCore
        core = coreCls()
        
        headerLine = self._getHeader()
        
        core.styleInfoBegin(styleClass="infomessagesmall answerbox question")
        core.header('Global results table for:')
        core.line(str(coreCls().highlight(headerLine)))
        core.styleInfoEnd()
        
        #core.bigHeader(headerLine)
        #core.line('')
        return str(core)

    def _generateRunDescription(self):
        return self._results._runDescription if self._results._runDescription is not None else ''

    def _getHeader(self):
        #analysisDef = self._results._analysisDef 
        #if analysisDef is not None:
        #    return str(analysisDef)
        #else:
        if self._results._analysisText is not None:
            try:
                return AnalysisDefHandler.splitAnalysisText(self._results._analysisText)[1].strip()
            except AssertionError:
                pass
        
        trackName1, trackName2 = self._results.getTrackNames()        
        return self._results.getStatClassName() + \
                (' between ' if not trackName2 in [None,[]] else ' on ') + ':'.join(trackName1) + \
                ((' and ' + ':'.join(trackName2)) if not trackName2 in [None,[]] else '')
    
    def _generateErrorText(self, coreCls):
        core = coreCls()
        for exception in self._results.getAllErrors():
            core.header(getClassName(exception))
            if isinstance(exception, InvalidRunSpecException):
                core.paragraph('No results are available for this job, as the specification of the run was invalid: ' + \
                               str(exception))
            else:
                core.paragraph('No results are available for this job, as an error occured: ' + \
                               str(exception))
        return str(core)

    def _writetableHeader(self, core):
        if self._presCollectionType in ['standard']:
            core.tableHeader(*zip(*[['Results','rowspan=2']] +\
                               ([['Global analysis', 'rowspan=2']] if self._results.getGlobalResult() not in [None,{}] else []) +\
                               [['Local analysis', 'colspan='+ str(len(self._presenters)-1)]]))
            core.tableHeader([pres.getDescription() for pres in self._presenters \
                              if not isinstance(pres, GlobalValuePresenter)], firstRow=False)
        elif self._presCollectionType in ['dictofdicts']:
            core.tableHeader(*zip(*[['Results','rowspan=2']] +\
                               ([['Global analysis', 'colspan=2']] if self._results.getGlobalResult() not in [None,{}] else []) +\
                               [['Local analysis', 'colspan='+ str(len(self._presenters)-1)]]))
            core.tableHeader([pres.getDescription() for pres in self._presenters], firstRow=False)
        elif self._presCollectionType in ['matrix']:
            core.tableHeader(*zip(*[['Results','rowspan=2']] +\
                               ([['Global analysis', 'colspan=5']] if self._results.getGlobalResult() not in [None,{}] else [])))
            core.tableHeader([pres.getDescription() for pres in self._presenters], firstRow=False)
        elif self._presCollectionType in ['distribution','scatter','binscaled']:
            core.tableHeader(['Results'] + [pres.getDescription() for pres in self._presenters])

        #elif self._presCollectionType == 'distribution':
        #    core.tableHeader(['Results'] + [pres.getDescription() for pres in self._presenters \
        #                      if not isinstance(pres, GlobalValuePresenter)], firstRow=False)
        #elif self._presCollectionType == 'scatter':
        #elif self._presCollectionType == 'binscaled':
        else:
            raise ShouldNotOccurError
        #core.tableHeader(*zip(*[['Results','rowspan=2']] +\
        #                       ([['Global analysis', 'rowspan=2']] if self._results.getGlobalResult() not in [None,{}] else []) +\
        #                       [['Local analysis', 'colspan='+ str(len(self._presenters)-1)]]))
        
    def _generateTable(self, coreCls, hideTable=False):
        core = coreCls()
        core.styleInfoBegin(styleId='results_box', styleClass='infomessagesmall answerbox resultsbox')
        
        if len(self._presenters) == 0 or len(self._results.getResDictKeys()) == 0:
            return str( core.line('This analysis gave no results (typically due to too limited data).'))
        
        #core.tableHeader(['', 'Global results', 'Local results'],\
        #    [ 'rowspan=2', 'rowspan=2', 'colspan='+ str(len(self._presenters)-1) ])
        
        self._writetableHeader(core)
        
#        if self._presCollectionType in ['matrix']:
#            core.tableLine([str( pres.getReference() ) for pres in self._presenters])
#        else:

        resDictKeys = self._results.getResDictKeys()
        isAllResDictKeysPresenter = [hasattr(pres, 'getSingleReference') for pres in self._presenters]

        
        for rowNum,resDictKey in enumerate(resDictKeys):
            #temp = HtmlCore().link(*self._results.getLabelHelpPair(resDictKey))
            row = [ str( coreCls().textWithHelp(*self._results.getLabelHelpPair(resDictKey)) ) ]
            rowSpanList = [1]
            for i,pres in enumerate(self._presenters):
                if isAllResDictKeysPresenter[i]:
                    if rowNum == 0:
                        row.append( str(pres.getSingleReference()) )
                        rowSpanList.append(len(resDictKeys))
                else:
                    row.append( str(pres.getReference(resDictKey)) )
                    rowSpanList.append(1)
            core.tableLine(row, rowSpanList)
        core.tableFooter()
        
        core.styleInfoEnd()
        
        if hideTable:
            core.script(' $(".resultsbox").hide();')
        
        return str(core) 

class StandardResultsViewer(ResultsViewerBase):
    def _addAllPresenters(self):
#        self._results.inferAdjustedPvalues()

        self._presCollectionType = 'standard'                
        self._addPresenter(GlobalValuePresenter)
        self._addPresenter(TablePresenter, True)
        #self._addPresenter(RawTextTablePresenter, True)
        bedGraphPresenter = self._addPresenter(BedGraphPresenter)
        self._addPresenter(HistogramPresenter, True)
        #self._addPresenter(DensityPresenter, True)                
        if bedGraphPresenter is not None:                    
            self._addPresenter(GwPlotPresenter, True, historyFilePresenter=bedGraphPresenter)
        #self._addPresenter(FDRSummaryPresenter)
        #self._addPresenter(WigPresenter)

class MatrixResultsViewer(ResultsViewerBase):
    def _addAllPresenters(self):
        self._presCollectionType = 'matrix'
        self._addPresenter(MatrixGlobalCountsPresenter, True)
        self._addPresenter(MatrixGlobalValueFromNumpyPresenter, True)
        self._addPresenter(MatrixGlobalPvalPresenter, True)
        self._addPresenter(MatrixGlobalSignificancePresenter, True)
        self._addPresenter(HeatmapFromNumpyPresenter, True)

class DictOfDictsResultsViewer(ResultsViewerBase):
    def _addAllPresenters(self):
        self._presCollectionType = 'dictofdicts'
        self._addPresenter(MatrixGlobalValueFromDictOfDictsPresenter, True)
        self._addPresenter(HeatmapFromDictOfDictsPresenter, True)
        self._addPresenter(TableFromDictOfDictsPresenter, True)

class DistributionResultsViewer(ResultsViewerBase):
    def _addAllPresenters(self):
        self._presCollectionType = 'distribution'
        #brk(host='localhost', port=9000, idekey='galaxy')
        #self._addPresenter(GlobalValuePresenter(self._results, self._baseDir))
        self._addPresenter(HistogramGlobalListPresenter, True)
        #self._addPresenter(DensityGlobalListPresenter, True)                

class ScatterResultsViewer(ResultsViewerBase):
    def _addAllPresenters(self):
        self._presCollectionType = 'scatter'
        self._addPresenter(ScatterPresenter, True)
        self._addPresenter(MeanLinePresenter, True)
        self._addPresenter(BinHistPresenter, True)

class BinscaledResultsViewer(ResultsViewerBase):
    def _addAllPresenters(self):
        self._presCollectionType = 'binscaled'
        self._addPresenter(GlobalMeanSdVectorPresenter, True)

                
class MultiBatchResultsViewer(ResultsViewerBase):
    def __init__(self, resultsList, baseDir):
        self._resultsList = resultsList
        self._parentBaseDir = baseDir
        self._str = None
 
    def __str__(self):
        if self._str is not None:
            return self._str
                
        self._presenters = []
        
        for i,res in enumerate(self._resultsList):
            self._baseDir = os.sep.join([self._parentBaseDir,'multibatch'+str(i)])
            self._results = res
            self._addPresenter(ForgivingGlobalValuePresenter)
        #return self._generateHeader() + self._generateErrorText() + self._generateTable()
        return self._generateTable()

    def _generateTable(self):
        coreCls = HtmlCore
        core = coreCls()

        #core.tableHeader(['', 'Global results', 'Local results'],\
        #    [ 'rowspan=2', 'rowspan=2', 'colspan='+ str(len(self._presenters)-1) ])
        #core.tableHeader([pres.getDescription() for pres in self._presenters \
                          #if not isinstance(pres, GlobalValuePresenter)], firstRow=False)
        core.tableHeader(['']+[str(i) for i in range(len(self._resultsList))])
            #[ 'rowspan=2', 'rowspan=2', 'colspan='+ str(len(self._presenters)-1) ])
        
        #allResDictKeys = reduce(lambda x,y:x.union(y), [set(x.getResDictKeys()) for x in self._resultsList] )
        allResDictKeys = []
        for res in self._resultsList:
            for k in res.getResDictKeys():
                if not k in allResDictKeys:
                    allResDictKeys.append(k)
        #Print tracknames
        for trackIndex in [0,1]:
            core.tableLine([ 'Track %i (last term):'%trackIndex] +\
                [str( pres.getTrackName(trackIndex)[-1]) if len(pres.getTrackName(trackIndex))>0 else '' for pres in self._presenters])
                    
        for resDictKey in allResDictKeys:
            #temp = HtmlCore().link(*self._results.getLabelHelpPair(resDictKey))
            core.tableLine([ str( coreCls().textWithHelp(*self._results.getLabelHelpPair(resDictKey)) ) ] +\
                [str( pres.getReference(resDictKey) ) for pres in self._presenters])
        core.tableFooter()
        
        return str(core) 
