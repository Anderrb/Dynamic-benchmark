#class PreProcessTrackJob(object):
    #def __init__(self, genome, trackName):
    #    self._genome = genome
    #    self._trackName = trackName
    #    self._metaData = PreProcessMetaData(TrackInfo(genome, trackName))
    #    self._dirty = False
    #    self._status = ''
    #            
    #def process(self, allowOverlaps):
    #    try:
    #        for geSource in self._getGeSources():
    #            #geSourceJob = PreProcessGeSourceJob(geSource, allowOverlaps)                
    #            #if geSourceJob._shouldPreProcess():
    #                #geSourceJob.process()
    #            
    #                if geSourceJob.hasModifiedData():
    #                    self._metaInfo.update(geSourceJob)
    #                    self._dirty = True
        #
        #except NotSupportedError, e:
        #    self._printExceptionMsg(e, Error=False)
        #    raise
        #except Exception, e:
        #    self._printExceptionMsg(e, Error=True)
        #    raise

    #def hasModifiedData(self):
    #    return self._dirty

    #def ensureChrCreated(self, allowOverlaps):
    #    TrackPreProcessor.ensureChrCreatedNew(genome, trackName, self._metaData.getSomeGeSource(), chrList=GenomeInfo.getChrList(genome), allowOverlaps=allowOverlaps)
    
    #def updateTrackInfo(self):
    #    self._metaData.storeAsTrackInfo()
    #
    #def _printExceptionMsg(self, e, Error=False):
    #    print (os.linesep + '--- BEGIN ERROR ---' + os.linesep *2 if Error else 'Warning! ') + 'Could not pre-process track. Status: ' + self._status
    #    print e.__class__.__name__ + ':', e
    #    if Error:
    #        traceback.print_exc(file=sys.stdout)
    #        print os.linesep + '--- END ERROR ---' + os.linesep

#class PreProcessOrigTrackJob(PreProcessTrackJob):    
    #def _getGeSources(self):
    #    baseDir = createOrigPath(self._genome, self._trackName,'')
    #
    #    self._status = 'Trying os.listdir on: ' + baseDir
    #    for relFn in sorted(os.listdir( baseDir )):
    #        fn = baseDir + relFn
    #
    #        self._status = 'Checking file: ' + fn
    #        if os.path.isdir(fn):
    #            continue
    #        
    #        fnPart = os.path.split(fn)[-1]
    #        if fnPart[0] in ['.','_','#'] or fnPart[-1] in ['~','#']: #to avoid hidden files..
    #            continue
    #
    #        self._status = 'Trying to create geSource from fn: ' + fn
    #        yield GenomeElementSource(fn, genome, trackName)
#
#class PreProcessStreamedTrackJob(PreProcessTrackJob):
#    def __init__(self, genome, trackName, geSource):
#        self._geSource = geSource
#        PreProcessTrackJob.__init__(self, genome, trackName)
#            
#    def _getGeSources(self):
#        return [self._geSource]
