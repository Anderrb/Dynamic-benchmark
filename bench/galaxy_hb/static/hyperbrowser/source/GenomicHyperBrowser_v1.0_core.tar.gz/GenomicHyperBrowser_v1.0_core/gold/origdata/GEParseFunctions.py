# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.origdata.GenomeElement import GenomeElement
    
def getStart(ge):
    return ge.start

def getEnd(ge):
    return ge.end

def getVal(ge):
    return ge.val

def getStrand(ge):
    return ge.strand

def getSource(ge):
    return ge.source

def getNull(ge):
    return Null

def getPointEnd(ge):
    return ge.start + 1

class GetPartitionStart:
    def __init__(self):
        self._prevEnd = 0
        
    def parse(self, ge):
        #print self, ge, ge.end
        tempPrevEnd = self._prevEnd
        self._prevEnd = ge.end
        return tempPrevEnd
