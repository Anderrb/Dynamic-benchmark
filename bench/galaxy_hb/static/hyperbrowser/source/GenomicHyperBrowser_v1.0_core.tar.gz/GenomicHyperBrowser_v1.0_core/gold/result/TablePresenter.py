# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from quick.util.CommonFunctions import ensurePathExists, getLoadToGalaxyHistoryURL, getRelativeUrlFromWebPath
from gold.application.Config import MAX_LOCAL_RESULTS_IN_TABLE
from gold.result.HtmlCore import HtmlCore
from gold.result.TextCore import TextCore
from gold.result.Presenter import Presenter
from gold.util.CommonFunctions import strWithPrecision
import os

class TablePresenter(Presenter):
    def __init__(self, results, baseDir, header):
        Presenter.__init__(self, results, baseDir)
        #HTML
        self._htmlFn = os.sep.join([baseDir, 'table.html'])
        self._writeContent(self._htmlFn, header, HtmlCore)
        #Raw text
        self._rawFn = os.sep.join([baseDir, 'table.txt'])
        self._writeContent(self._rawFn, header, TextCore)
        
    def getDescription(self):
        return 'Table: values per bin'
    
    def getSingleReference(self):
        return str(HtmlCore().link('Html', getRelativeUrlFromWebPath(self._htmlFn))) + \
                '&nbsp;/&nbsp;' + \
                str(HtmlCore().link('Raw&nbsp;text', getRelativeUrlFromWebPath(self._rawFn))) 

    def _writeContent(self, fn, header, coreCls):
        core = coreCls()
        
        core.begin()
        core.styleInfoBegin(styleClass="infomessagesmall",
                            style='padding: 5px; margin-bottom: 10px; ' +\
                                  'background-image: none; background-color: #FFFC8C; ')
        core.header('Local results table for:')
        core.line(str(coreCls().highlight(header)))
        core.styleInfoEnd()

        #core.bigHeader(header)
        #core.header('Local result table')
        
        if len( self._results.getAllRegionKeys() ) > MAX_LOCAL_RESULTS_IN_TABLE:
            core.line('Local results were not printed because of the large number of bins: ' \
                  + str(numUserBins) + ' > ' + str(MAX_LOCAL_RESULTS_IN_TABLE))
        else:
            core.tableHeader([ str( coreCls().textWithHelp(baseText, helpText) ) for baseText, helpText in 
                              ([('Region','')] + self._results.getLabelHelpPairs()) ])
            
            for regionKey in self._results.getAllRegionKeys():
                core.tableLine([str(regionKey)] +\
                    [ strWithPrecision( self._results[regionKey].get(resDictKey) ) \
                     for resDictKey in self._results.getResDictKeys() ])
            core.tableFooter()

        core.end()
        
        ensurePathExists(fn)        
        open(fn,'w').write( str(core) )
