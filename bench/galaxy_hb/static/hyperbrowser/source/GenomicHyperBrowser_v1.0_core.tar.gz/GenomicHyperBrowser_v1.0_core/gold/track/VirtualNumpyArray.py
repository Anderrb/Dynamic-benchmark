# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#abstract
#Supports standard methods, but the only supported operand is sub.
class VirtualNumpyArray(object):
    #def updateNumpyArray(self):
        #if not hasattr(self._cachedNumpyArray):
        #    self._cachedNumpyArray = self._asNumpyArray()
        
    def __getattr__(self, name):
        if name == '_cachedNumpyArray':
            return self._cachedNumpyArray

        if not hasattr(self, '_cachedNumpyArray'):
            self._cachedNumpyArray = self._asNumpyArray()
    #    self.updateNumpyArray()
        return getattr(self._cachedNumpyArray, name)

    def __sub__(self, other):
        if not hasattr(self, '_cachedNumpyArray'):
            self._cachedNumpyArray = self._asNumpyArray()
        #self.updateNumpyArray()
        return self._cachedNumpyArray.__sub__(other)
    
    def __add__(self, other):
        if not hasattr(self, '_cachedNumpyArray'):
            self._cachedNumpyArray = self._asNumpyArray()
        #self.updateNumpyArray()
        return self._cachedNumpyArray.__add__(other)