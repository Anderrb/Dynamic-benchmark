# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.statistic.MagicStatFactory import MagicStatFactory
from gold.statistic.Statistic import Statistic
from gold.statistic.RawDataStat import RawDataStat
from gold.statistic.NextUniqueValStat import NextUniqueValStat
from gold.util.CustomExceptions import NoMoreUniqueValsError, NoneResultError, ShouldNotOccurError
from gold.util.CompBinManager import CompBinManager
from copy import copy
from gold.application.LogSetup import logMessage

class GeneralOneTrackIterateValsStat(MagicStatFactory):
    pass

class GeneralOneTrackIterateValsStatUnsplittable(Statistic):
    VERSION = '1.1'
    ALLOW_COMP_BIN_SPLITTING = False #I do not know how to be able to use results memoized on disk..
    IS_MEMOIZABLE = False

    _allVals = {}

    def __init__(self, region, track, track2=None, rawStatistic=None, storeChildren=True, valKey='val', **kwArgs):
        assert rawStatistic is not None
        assert type(rawStatistic) == str
        from gold.statistic.AllStatistics import STAT_CLASS_DICT
        self._rawStatistic = STAT_CLASS_DICT[rawStatistic] 
        CompBinManager.ALLOW_COMP_BIN_SPLITTING = self.ALLOW_COMP_BIN_SPLITTING

        if not tuple(track.trackName) in self._allVals:
            self._allVals[tuple(track.trackName)] = set([])

        self._curVal = None
        self._valKey = valKey
        # To store children for eventual memoization in global run
        if storeChildren:
            self._storedChildren = []
        
        Statistic.__init__(self, region, track, track2, rawStatistic=rawStatistic, storeChildren=storeChildren, **kwArgs)

    def _coreComputeStep(self, results):
        if not self.hasChildren():
            self.createChildren()
        self.setNotMemoizable()
        
        while not self.hasResult():
            Statistic.computeStep(self)
            
        results.update(self.getResult())
        del self._result
    
    def _runIsGlobal(self):
        return hasattr(self._region, '__iter__') and len(self._getAllVals()) > 0

    def _getAllVals(self):
        return self._allVals[tuple(self._track.trackName)]

    def computeStep(self):
        results = {}
        while not self._runIsGlobal():
            del self._children
            try:
                self._coreComputeStep(results)
                
                if self._curVal is None:
                    self._result = results
                    return
                
                self._nextUniqueValChild.prepareForNewIteration() # Removing RawDataStat in order to provoke new category to be read
                self._rawStatChild.updateInMemoDict({self._valKey: self._curVal})

                if hasattr(self, '_storedChildren'):
                    self._getAllVals().add(self._curVal)
                    self._storedChildren += [self._rawStatChild]
                                
                self._curVal = None
            except NoMoreUniqueValsError:
                break
            
            except:
                raise

        if self._runIsGlobal():
            if hasattr(self, '_storedChildren'):
                self._track.formatConverters[0].silence()
    
                for val in self._getAllVals():
                    self._curVal = val
                    del self._children
                    self._coreComputeStep(results)
            else:
                raise ShouldNotOccurError
                
        self._result = results
        
    def _compute(self):
        if self._curVal is None:
            try:
                self._curVal = self._nextUniqueValChild.getResult()
            except NoneResultError:
                self._curVal = None
                return {}
        
        try:
            return {self._curVal: self._rawStatChild.getResult()}
        except NoneResultError:
            return {self._curVal: None}
    
    def _afterComputeCleanup(self):
        if self._runIsGlobal():
            self._getAllVals().clear()
        self._track.formatConverters[0].reset()
    
    def _getRawStatChild(self, kwArgs):
        return self._rawStatistic(self._region, self._track, \
                                  self._track2 if hasattr(self, '_track2') else None, **kwArgs)
    
    def _createChildren(self):
        kwArgs = copy(self._kwArgs)
        if not self._runIsGlobal():
            self._nextUniqueValChild = self._addChild( NextUniqueValStat(self._region, self._track) )
        else:
            if self._curVal is not None:
                kwArgs.update({self._valKey: self._curVal})

        self._rawStatChild = self._addChild( self._getRawStatChild(kwArgs) )
