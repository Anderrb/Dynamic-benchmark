# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import os
from gold.origdata.GenomeElementSource import GenomeElementSource
from quick.util.GenomeInfo import GenomeInfo

class FastaGenomeElementSource(GenomeElementSource):
    _VERSION = '1.0' #1.1 for mark type
    _numHeaderLines = 1

    def __new__(cls, fn, *args, **kwArgs):
        ob = object.__new__(cls)
        headerLine = open(fn).readline()
        assert headerLine[0] == '>'
        ob._chr = headerLine.split()[0][1:]
        return ob

    def __getnewargs__(self):
        return (self._fn,)

    def __init__(self, *args, **kwArgs):
        GenomeElementSource.__init__(self, *args, **kwArgs)
        self._genomeElement.chr = self._checkValidChr(self._chr)
        del self._chr
        
    def next(self):
        while True:
            bp = self._file.read(1)
            if bp == '':
                raise StopIteration    
            if bp != os.linesep:
                break
        self._genomeElement.val = bp
        return self._genomeElement
    
    def getValDataType(self):
        return 'S1'

    def getPrefixList(self):
        return ['val']