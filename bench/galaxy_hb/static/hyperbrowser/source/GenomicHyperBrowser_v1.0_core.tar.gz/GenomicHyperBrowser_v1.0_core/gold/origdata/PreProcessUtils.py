import os
from quick.util.GenomeInfo import GenomeInfo
from gold.util.CommonFunctions import createDirPath
from gold.track.TrackFormat import TrackFormat
from gold.origdata.GenomeElement import GenomeElement
from gold.origdata.OutputDirectory import OutputDirectory
from gold.description.TrackInfo import TrackInfoDataCollector

class PreProcessUtils(object):
    # Create empty files for chromosomes in chrList that are not created yet for the trackname of geSource
    @staticmethod
    def ensureAllChrsCreated(genome, trackName, allowOverlaps=False):
        for chr in GenomeInfo.getChrList(genome):
            dirPath = createDirPath(trackName, genome, chr, allowOverlaps)
            #print dirPath
            if not os.path.exists(dirPath):
                print 'WARNING: Filling in empty chromosome: %s for allowOverlaps: %s <br>' % (chr, allowOverlaps)
                chrLen = GenomeInfo.getChrLen(genome, chr)
                collector = TrackInfoDataCollector(genome, trackName)
                
                format = TrackFormat.createInstanceFromPrefixList(collector.getPrefixList(allowOverlaps), \
                                                                  collector.getValDataType(), \
                                                                  collector.getValDim())
                emptyGE = EmptyGenomeElement(genome, chr, collector.getPrefixList(allowOverlaps))
                
                dir = OutputDirectory(dirPath, collector.getPrefixList(allowOverlaps), chrLen if format.reprIsDense() else 1,
                                      chrLen, collector.getValDataType(), collector.getValDim())
                if format.reprIsDense():
                    for i in xrange(chrLen):
                        dir.writeElement(emptyGE)
                else:
                    dir.writeElement(emptyGE)
                dir.close()
    
class EmptyGenomeElement(GenomeElement):
    def __init__(self, genome, chr, prefixList):
        emptyEl = {'start':-1, 'end':0, 'val':0, 'strand':True, 'source':''}
        kwArgs = {}
        for prefix in prefixList:
            kwArgs[prefix] = emptyEl[prefix]
        GenomeElement.__init__(self, genome, chr, **kwArgs)
