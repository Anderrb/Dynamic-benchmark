# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#Note: Not yet tested. Should have unit and intTest.
import third_party.stats as stats
import math
from gold.statistic.MagicStatFactory import MagicStatFactory
from gold.statistic.Statistic import Statistic
from gold.statistic.CountPointStat import CountPointStat
from gold.util.CustomExceptions import SplittableStatNotAvailableError, ShouldNotOccurError
from gold.application.Config import DEFAULT_GENOME
from quick.application.UserBinSource import GlobalBinSource, MinimalBinSource, UserBinSource
from gold.util.CommonFunctions import isIter
from collections import OrderedDict

class DiffRelFreqPValStat(MagicStatFactory):
    resultLabel = 'P-value'
    MIN_POP_FOR_GAUSSIAN_APPROXIMATION = 5
    #cfgGlobalSource = GlobalBinSource(DEFAULT_GENOME)
    
    #@classmethod
    #def minimize(cls, genome):
        #cls.cfgGlobalSource = MinimalBinSource(genome)

class DiffRelFreqPValStatUnsplittable(Statistic):
    IS_MEMOIZABLE = False
    
    def __init__(self, region, track, track2, tail='more', globalSource='', minimal=False, **kwArgs):
        if isIter(region):
            raise SplittableStatNotAvailableError()
        
        if minimal == True:
            self._globalSource = MinimalBinSource(region.genome)
        elif globalSource == 'test':
            self._globalSource = UserBinSource('TestGenome:chr21:10000000-15000000','1000000')
        else:
            self._globalSource = GlobalBinSource(region.genome)
        
        assert tail in ['more', 'less', 'different']
        self._tail = tail
        
        super(self.__class__, self).__init__(region, track, track2, tail=tail, globalSource=globalSource, minimal=minimal, **kwArgs)
    
    def _createChildren(self):
        globCount1 = CountPointStat(self._globalSource , self._track)
        globCount2 = CountPointStat(self._globalSource , self._track2)
        binCount1 = CountPointStat(self._region, self._track)
        binCount2 = CountPointStat(self._region, self._track2)

        self._addChild(globCount1)
        self._addChild(globCount2)
        self._addChild(binCount1)
        self._addChild(binCount2)

    def _compute(self):    
        n1 = self._children[0].getResult()
        n2 = self._children[1].getResult()
        c1 = self._children[2].getResult()
        c2 = self._children[3].getResult()
        #print '*',c1,c2,n1,n2
        
        p = 1.0 * c1 / n1
        q = 1.0 * c2 / n2
        r = 1.0 * (n1*p+n2*q) / (n1+n2)
        
        if c1>=DiffRelFreqPValStat.MIN_POP_FOR_GAUSSIAN_APPROXIMATION \
            and c2>=DiffRelFreqPValStat.MIN_POP_FOR_GAUSSIAN_APPROXIMATION:
            se = math.sqrt( r*(1-r)/n1 + r*(1-r)/n2)
            zScore = (p-q) / se
            if self._tail == 'more':
                pval = 1.0-stats.zprob(zScore)
            elif self._tail == 'less':
                pval = stats.zprob(zScore)
            elif self._tail == 'different':
                #fixme: which of these two solutions are correct?
                #pval = 2.0*(1.0-zprob(abs(zScore)))
                pval = min(1.0, 2.0*min(1.0-stats.zprob(zScore), stats.zprob(zScore)))
        else:
            zScore = pval = se = None
            
        return OrderedDict([ ('P-value', pval), ('Test statistic: Z-score', zScore), ('EstDiff', p-q), \
                            ('SEDiff', se), ('CountTrack1', c1), ('CountTrack2', c2) ])
            
