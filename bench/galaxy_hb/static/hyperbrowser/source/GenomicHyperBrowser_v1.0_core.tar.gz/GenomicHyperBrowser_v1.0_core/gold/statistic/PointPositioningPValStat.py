# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.statistic.MagicStatFactory import MagicStatFactory
from gold.statistic.Statistic import Statistic
from gold.statistic.PointPositionsInSegsStat import PointPositionsInSegsStat
#from gold.application.RSetup import r
#from random import random
from gold.util.CustomExceptions import ShouldNotOccurError, NotSupportedError
from collections import OrderedDict

class PointPositioningPValStat(MagicStatFactory):
    pass

class PointPositioningPValStatUnsplittable(Statistic):
    def __init__(self, region, track, track2, tail='', **kwArgs):
        self._altHyp = tail
        if not self._altHyp in ['ha1','ha3']:
            raise NotSupportedError(self._altHyp)
        Statistic.__init__(self, region, track, track2, tail=tail, **kwArgs)
        
    def _compute(self):
        
        #misforstaat problemstilling, basert paa to rawdatastats.. Fjern snart..:
        #tvSegs = self._children[0].getResult()
        #tvPoints = self._children[1].getResult()
        #dists = []
        #tvPointIter = tv2.__iter__()
        #scoreList = []
        #point = -1
        #for seg in tvSegs:
        #    for pos in xrange( seg.start(), seg.end() ):
        #        while point < pos:
        #            point = tvPointIter.next().start()
        #            scoreList.append([ self._calcScore(seg.start(), seg.end(), pos), random.random(), pos == point])
        #        #if pos < seg.end():
        #        #    scoreList.append([ self._calcScore(seg.start(), seg.end(), pos), random.random(), 1])
        #
        #sortedScores = sorted(scoreList)
        #wPlus = sum( (i+1) for i in xrange(scoreList) if scoreList[i][2] == True)
        #wMinus = sum( (i+1) for i in xrange(scoreList) if scoreList[i][2] == False)
        #w = min(wPlus, wMinus)
        
        scoreList = []
        for relPos in self._children[0].getResult():
            score = PointPositioningPValStatUnsplittable._calcScore(relPos, self._altHyp)
            if score!=0:
                #scoreList.append( (abs(score), random(), score>0) ) #random number to avoid sign bias when sorting on absolute value
                scoreList.append( (abs(score), score>0) )
        
        #GKs nye losning
        wPlusMinus = {True:0, False:0}
        sortedScores = sorted(scoreList)
        curValPos = 0
        while curValPos < len(sortedScores):
            higherValPos = curValPos + 1
            while higherValPos < len(sortedScores) and \
                sortedScores[higherValPos][0] - sortedScores[curValPos][0] < 1.0e-7: #almost equal, to ignore representation errors
                    higherValPos += 1
            for pos in xrange(curValPos, higherValPos):
                wPlusMinus[sortedScores[pos][1]] += (curValPos+(higherValPos-1))/2.0 +1 #higherValPos-1 since end-exclusive, +1 since ranks start from 1
            curValPos = higherValPos
            
        w = min(wPlusMinus[True], wPlusMinus[False])   
        #Sveinungs forrige losning:
        #sortedScores = [[i+1,score] for i,score in enumerate(sorted(scoreList)) ]
        #PointPositioningPValStatUnsplittable._meanRankForTiedScores(sortedScores)

        #wPlus = sum( (i+1) for i in xrange(len(sortedScores)) if sortedScores[i][2] == True)
        #wMinus = sum( (i+1) for i in xrange(len(sortedScores)) if sortedScores[i][2] == False)
        #wPlus = sum( sortedScores[i][0] for i in xrange(len(sortedScores)) if sortedScores[i][1][1] == True)
        #wMinus = sum( sortedScores[i][0] for i in xrange(len(sortedScores)) if sortedScores[i][1][1] == False)
        #w = min(wPlus, wMinus)
        
        n = len(sortedScores)
        if n<2:
            pval = None
        elif n<30:
            from gold.application.RSetup import r
            #print 'w,n: ',w,n
            pval = r.psignrank(w,n)
        else:
            from gold.application.RSetup import r
            mean = n*(n+1)/4.0
            var = n*(n+1)*(2*n+1)/24.0
            pval = r.pnorm(w, mean, var**0.5)
        return OrderedDict([ ('P-value', pval), ('Test statistic: ' + ('W12' if self._altHyp in ['ha1', 'ha2'] else \
                             ('W34' if self._altHyp in ['ha3', 'ha4'] else 'W5')), w), ('N', n) ])
    
    @staticmethod
    def _calcScore(relPos, altHyp):
        if altHyp == 'ha1':
            return 1 - 4*abs(relPos-0.5)
        elif altHyp == 'ha3':
            return -1 + 2.0 * relPos
        else:
            raise ShouldNotOccurError
    
    #@staticmethod
    #def _meanRankForTiedScores(sortedScores):
    #    #Can probably be calculated in a more elegant way..
    #    if len(sortedScores) == 0:
    #        return
    #    
    #    prevScore = None
    #    rankSum = 0
    #    rankCount = 0
    #        
    #    for i,score in sortedScores:
    #        if prevScore is not None and score[0] - prevScore < 1.0e-7:
    #            rankSum += i
    #            rankCount += 1
    #        else:
    #            PointPositioningPValStatUnsplittable._setMeanRankForCurrentTiedScores(sortedScores, i, rankCount, rankSum)
    #            rankSum = i
    #            rankCount = 1
    #        prevScore = score[0]
    #    PointPositioningPValStatUnsplittable._setMeanRankForCurrentTiedScores(sortedScores, i+1, rankCount, rankSum)
    
    #@staticmethod
    #def _setMeanRankForCurrentTiedScores(sortedScores, i, rankCount, rankSum):
    #    if rankCount >= 2:
    #        rankMean = 1.0 * rankSum/rankCount
    #        for j in xrange(i-rankCount, i):
    #            sortedScores[j-1][0] = rankMean
    
    def _createChildren(self):
        self._addChild( PointPositionsInSegsStat(self._region, self._track, self._track2) )
