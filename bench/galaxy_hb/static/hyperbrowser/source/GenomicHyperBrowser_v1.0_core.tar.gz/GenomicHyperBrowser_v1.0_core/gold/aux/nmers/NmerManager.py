# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#!/usr/bin/env python
from gold.application.Config import NMER_CHAIN_DATA_PATH
from gold.origdata.GenomeElement import GenomeElement
from gold.track.Track import PlainTrack
from gold.track.TrackFormat import TrackFormat
from gold.description.TrackInfo import TrackInfo
from quick.util.GenomeInfo import GenomeInfo
from gold.origdata.TrackPreProcessor import TrackPreProcessor
from quick.util.Wrappers import FuncValTvWrapper
from gold.aux.nmers.NmerTools import NmerTools
from gold.aux.nmers.NmerAsIntSlidingWindow import NmerAsIntSlidingWindow
from gold.aux.nmers.SameValueIndexChains import SameValueIndexChainsFactory
from gold.util.Wrappers import PositionIterGESource, LowerOrderChainWrapper
from gold.origdata.TrackPreProcessor import TrackPreProcessor
from gold.util.CustomExceptions import EmptyGESourceError

import sys
import os

class NmerManager(object):
    GE_SOURCE = PositionIterGESource

    def __init__(self, genome):
        self._genome = genome
        self._prefixList = None
    
    def createNmerChains(self, n):
        for chr in GenomeInfo.getChrList(self._genome):
            print 'Creating chains of nmers of length ', n, ' for chromosome ', chr
            chrLen = GenomeInfo.getChrLen(self._genome,chr)
            chrReg = GenomeElement( self._genome, chr, 0, chrLen )
            seqTV = PlainTrack(['sequence']).getTrackView(chrReg)
            
            #nmersAsInts = NmerAsIntSlidingWindow(n, FuncValTvWrapper(seqTV))
            nmersAsInts = NmerAsIntSlidingWindow(n, seqTV.valsAsNumpyArray())
            SameValueIndexChainsFactory.generate( nmersAsInts, chrLen, 4**n, self._createPath(n), chr )
        
            
    def _createNmerTrack(self, nmerList, lowerOrder=None):
        nmerLengths = list(set([len(nmer) for nmer in nmerList]))
        assert len(nmerLengths)==1
        
        chainOrder = lowerOrder if lowerOrder is not None else nmerLengths[0]
        
        chrsWithElements = {}
        for nmer in nmerList:
            chrsWithElements[nmer] = set()

        for chr in GenomeInfo.getChrList(self._genome):                
            chains = SameValueIndexChainsFactory.load(self._createPath(chainOrder), chr)
            #print 'Processing chr: ', chr
            print '|',
                #if lowerOrder is not None:
            for nmer in nmerList:
                if len(nmerList)>1:
                    print '.',
                if lowerOrder is not None:
                    nmerPrefix = nmer[0:chainOrder]                    
                    rawIndexGenerator = chains.getIndexGenerator(NmerTools.nmerAsInt(nmerPrefix))             
                    indexGenerator = LowerOrderChainWrapper(rawIndexGenerator, nmerPrefix, nmer, self._genome, chr)
                else:
                    indexGenerator = chains.getIndexGenerator(NmerTools.nmerAsInt(nmer)) 
    
                #print 'Length of lower order chain: %i and %i' % (sum(1 for x in indexGenerator), sum(1 for x in indexGenerator))
                #print 'Length of wrapped chain: %i and %i' % (sum(1 for x in wrappedIndexGenerator), sum(1 for x in wrappedIndexGenerator))            
                try:
                    trackName = self.processOneNmerChr( nmer, chr, indexGenerator )                
                    chrsWithElements[nmer].add(chr)
                except EmptyGESourceError:
                    #print '(empty). '
                    pass            
        
        #allGenerated = True
        for nmer in nmerList:
            #if len(chrsWithElements[nmer])==0:
            #    print 'No occurrences of nmer "%s" in genome "%s". Therefore no track was created' % (nmer, genome)
            #    allGenerated = False
            #else:
            self.finishTrack(nmer)
                
        return

    def createNmerTrack(self, nmer):
        self._createNmerTrack([nmer])
        #for chr in GenomeInfo.getChrList(self._genome):
        #    chains = SameValueIndexChainsFactory.load(self._createPath(len(nmer)), chr)
        #    trackName = self.processOneNmerChr( nmer, chr, chains.getIndexGenerator(NmerTools.nmerAsInt(nmer)) )                
        #
        #self.finishTrack(nmer)

    def createNmerTracks(self, n):
        print 'Creating tracks for nmers of length ', n        
        self._createNmerTrack(list(NmerTools.allNmers(n)))

        #for chr in GenomeInfo.getChrList(self._genome):
        #    print 'Creating tracks for nmers of length ', n, ' for chromosome ', chr
        #    chains = SameValueIndexChainsFactory.load(self._createPath(n), chr)
        #    for nmer in NmerTools.allNmers(n):
        #        print '.',
        #        trackName = self.processOneNmerChr( nmer, chr, chains.getIndexGenerator(NmerTools.nmerAsInt(nmer)) )
        #        
        #    print ''
        
        #for nmer in NmerTools.allNmers(n):
        #    self.finishTrack(nmer)

    def processOneNmerChr(self, nmer, chr, posIter):
        geSource = self.GE_SOURCE(posIter, self._genome, self._createTrackName(nmer), chr)
        self._prefixList = geSource.getPrefixList()
        self._valDataType = geSource.getValDataType()
        self._valDim = geSource.getValDim()
        TrackPreProcessor.process(geSource)
    
    def finishTrack(self, nmer):
        #TrackInfo.finalizeTrack(self._genome, self._createTrackName(nmer),['start'], None, None )
        chrList = GenomeInfo.getChrList(self._genome)
        tn = self._createTrackName(nmer)
        TrackPreProcessor.ensureChrCreated(self._genome, tn, self._prefixList, self._valDataType, self._valDim, chrList, False)
        TrackInfo.finalizeTrack(self._genome, tn, self._prefixList, None, None )
            
    def nmerChainExists(self, n):
        return os.path.exists( self._createPath(n) )
    
    def getHighestExistingChainOrderLessThanN(self, n):
        for k in range(n,0,-1):
            if self.nmerChainExists(k):
                return k
        return None
    
    def createNmerTrackFromLowerOrderChain(self, fullNmer, chainOrder):
        print 'Using nmer prefix (%s) as seed. ' % fullNmer[0:chainOrder]
        self._createNmerTrack([fullNmer], chainOrder)
    
    def _createTrackName(self, nmer):
        return GenomeInfo.getNmerTrackName(self._genome) + [str(len(nmer)) + '-mers', nmer]
    
    def _createPath(self, n):
        return os.sep.join([NMER_CHAIN_DATA_PATH, self._genome, str(n)])

#NmerManager('sacCer1').createNmerTrack('ac')

if __name__ == "__main__":
    if not len(sys.argv) == 4:
        print 'Syntax: .py chains|tracks genome n|nMin-nMax'
    else:
        mode, genome, nSpec= sys.argv[1:]        
        if '-' in nSpec:
            nSpec = nSpec.split('-')
            nMin, nMax = int(nSpec[0]), int(nSpec[1])+1
            allNs = range(nMin, nMax)
        else:
            allNs = [int(nSpec)]
        
        for n in allNs:
            if mode == 'chains':
                NmerManager(genome).createNmerChains(n)
            elif mode == 'tracks':
                NmerManager(genome).createNmerTracks(n)
            else:
                print 'Invalid option..'
                break
    
