# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import gold
from gold.statistic.MagicStatFactory import MagicStatFactory
from gold.statistic.Statistic import Statistic, StatisticConcatResSplittable, OnlyGloballySplittable
from gold.statistic.RawDataStat import RawDataStat
from gold.track.TrackFormat import TrackFormatReq
from gold.util.CustomExceptions import NotSupportedError

class NearestSegmentDistsStat(MagicStatFactory):
    pass

class NearestSegmentDistsStatSplittable(StatisticConcatResSplittable, OnlyGloballySplittable):
    pass

class NearestSegmentDistsStatUnsplittable(Statistic):
    'For each segment in track1, finds the distance to the closest segment of track2, overlap counting as zero distance..'

    def __init__(self, region, track, track2, distDirection='both', **kwArgs):
        assert distDirection in ['upstream','downstream','both']
        
        self._distDirection = distDirection
        Statistic.__init__(self, region, track, track2, distDirection=distDirection, **kwArgs)

    def _compute(self):
        if self._region.strand is False:
            raise NotSupportedError() #support by ignoring if both-directions, or switching between left/right-computation..

        dists = []
        for p, ldist,rdist in self._yieldLeftAndRightDists(): #p is here the track1-point that we have a left/right-distance for
            
            #p.strand
            #self._distDirection
            
            if rdist == 0 or ldist == 0:
                dists.append(0)
            elif self._distDirection == 'both':
                dists.append( min([x for x in [ldist,rdist] if x!=None]) )
            elif p.strand() in [True,None]:
                if self._distDirection in ['downstream']:
                    dists.append(rdist)
                else:
                    dists.append(ldist)
            else:
                if self._distDirection in ['downstream']:
                    dists.append(ldist)
                else:
                    dists.append(rdist)        
        return dists
    
    def _yieldLeftAndRightDists(self):
        tv1 = self._children[0].getResult()
        tv2 = self._children[1].getResult()
        tv2Iter = tv2.__iter__()

        try:
            p2 = tv2Iter.next()
            prevP2_end = None
        except:
            #no points in track2
            self._result = [None for el in tv1]
            return
                
        for p1 in tv1:
            try:
                if p2==None:
                    p2 = tv2Iter.next()
                
                while p2.start() < p1.start():
                    prevP2_end = p2.end()
                    p2 = None
                    p2 = tv2Iter.next()
                
                leftDist = max(0,p1.start()-(prevP2_end-1)) if prevP2_end!= None else None
                rightDist  = max(0,p2.start()-(p1.end()-1))

                yield p1, leftDist,rightDist
                
            except StopIteration:
                if prevP2_end == None:
                    yield p1, None, None
                else:
                    yield p1, max(0,p1.start()-(prevP2_end-1)), None
        

            
    def _createChildren(self):
        self._addChild( RawDataStat(self._region, self._track, TrackFormatReq(dense=False)) )
        self._addChild( RawDataStat(self._region, self._track2, TrackFormatReq(dense=False, interval=True)) )
