# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.origdata.GESourceWrapper import GESourceWrapper
from copy import copy
import os
from gold.util.CustomExceptions import ShouldNotOccurError
from gold.track.TrackFormat import TrackFormat

class GEOverlapClusterer(object):
    def __new__(cls, sortedGeSource):
        hasStart, hasEnd = [attrs in sortedGeSource.getPrefixList() for attrs in ['start', 'end']]
        
        if not hasStart and not hasEnd:
            return GEOverlapClusterer_Function(sortedGeSource)
        elif hasStart and hasEnd:
            return GEOverlapClusterer_Segment(sortedGeSource)
        elif hasStart and not hasEnd:
            return GEOverlapClusterer_Point(sortedGeSource)
        elif not hasStart and hasEnd:
            return GEOverlapClusterer_Partition(sortedGeSource)
        else:
            raise ShouldNotOccurError()

class GEOverlapClustererBase(GESourceWrapper):    
    def __init__(self, sortedGeSource):
        GESourceWrapper.__init__(self, sortedGeSource)
        self._geIter = None
        self._croppedElements = []
        
    def __iter__(self):
        self = copy(self)
        self._reducedElCount = 0
        #self._countReducedSumIntervalCount = 0
        if len(self._croppedElements) == 0:
            self._geIter = self._geSource.__iter__()
            try:
                self._prevEl = None
                self._prevEl = self._geIter.next()
            except StopIteration:
                pass
            return self
        else:
            return self._croppedElements.__iter__()
    
    def next(self):
        try:
            while True:
                el = self._geIter.next()
                if self._overlapsPrev(el) and self._getSubPath(el) == self._getSubPath(self._prevEl):
                    self._extendPrev(el)
                    self._reducedElCount += 1
                else:
                    self._croppedElements.append(self._prevEl)
                    self._prevEl = el
                    return self._croppedElements[-1]
        
        except StopIteration:
            if self._prevEl != None:
                self._croppedElements.append(self._prevEl)
                self._prevEl = None
                return self._croppedElements[-1]
                
            #print 'Finished overlap clustering.'
            #print 'Element count before clustering: ' + str(len(self._croppedElements) + self._reducedElCount)
            #print 'Element count after clustering: ' + str(len(self._croppedElements))
            raise StopIteration

    def _getSubPath(self, el):
        if el.subtype != None:
            return os.sep.join(el.subtype) + os.sep + el.chr
        else:
            return el.chr
    
class GEOverlapClusterer_Segment(GEOverlapClustererBase):
    def _overlapsPrev(self, el):
        return el.start < self._prevEl.end

    def _extendPrev(self, el):        
        self._prevEl.end = max(self._prevEl.end, el.end)

class GEOverlapClusterer_Point(GEOverlapClustererBase):
    def _overlapsPrev(self, el):
        return el.start == self._prevEl.start

    def _extendPrev(self, el):
        pass

class GEOverlapClusterer_Partition(GEOverlapClustererBase):
    def _overlapsPrev(self, el):
        return el.end == self._prevEl.end

    def _extendPrev(self, el):
        pass

class GEOverlapClusterer_Function(GEOverlapClustererBase):
    def __iter__(self):
        return self._geSource.__iter__()
