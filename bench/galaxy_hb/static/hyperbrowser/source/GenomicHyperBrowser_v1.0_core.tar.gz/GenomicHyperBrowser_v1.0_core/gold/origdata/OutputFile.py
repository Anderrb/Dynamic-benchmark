# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from numpy import memmap
import os
from stat import S_IRWXU, S_IRWXG, S_IRWXO

from gold.origdata.GEParseFunctions import *

class OutputFile:
    def _setup(self, prefix, thisPrefix, parseFunc, dataType, dim):
        if prefix == thisPrefix:
            self._parseFunc = parseFunc
            self._dataType = dataType
            self._dim = dim
    
    def __init__(self, path, prefix, size, valDataType='float32', valDim=1, maxLineLen=0):
        self._setup(prefix, 'start', getStart, 'int32', 1)
        self._setup(prefix, 'end', getEnd, 'int32', 1)
        self._setup(prefix, 'strand', getStrand, 'bool8', 1)
        self._setup(prefix, 'val', getVal, valDataType, valDim)
        self._setup(prefix, 'source', getSource, 'S' + str(maxLineLen), 1)
        self._setup(prefix, 'leftIndex', getNull, 'int32', 1)
        self._setup(prefix, 'rightIndex', getNull, 'int32', 1)
        
        #if prefix == 'val' and valDataType != None:
        #if prefix == 'val':
        #    self._dataType = valDataType
        #    assert(valDataType != None)
            
        self._fn = path + os.sep + prefix + ( ('.' + str(self._dim)) if self._dim != 1 else '' ) + '.' + self._dataType
        #self._tempfn = path + os.sep + 'Temp_' + prefix + '.' + self._dataType
        self._tempfn  = self._fn
        
        if os.path.exists(self._fn):
            raise IOError('File ' + self._fn + ' allready exists.')
        if os.path.exists(self._tempfn):    
            os.remove(self._tempfn)
        
        shape = size if self._dim == 1 else (size, self._dim)
        try:
            self._file = memmap( self._tempfn, dtype=self._dataType, mode='w+', shape=shape )
            #print 'Creating memmap-file: ',self._tempfn 
        except Exception:
            print 'Error when creating file: ', self._tempfn
            raise
        os.chmod(self._tempfn, S_IRWXU|S_IRWXG|S_IRWXO)
        self._index = 0
    
    def __len__(self):
        return len(self._file)
    
    def close(self):
        self._file.flush()
        self._file = None
        #os.rename(self._tempfn, self._fn)

    def writeElement(self, genomeElement):
        self._file[self._index] = self._parseFunc(genomeElement)
        self._index += 1

    def write(self, value):
        self._file[self._index] = value
        self._index += 1
        
    def writeRawSlice(self, slice, startPos):
        assert str(slice.dtype) == self._dataType
        self._file[startPos:startPos+len(slice)] = slice
