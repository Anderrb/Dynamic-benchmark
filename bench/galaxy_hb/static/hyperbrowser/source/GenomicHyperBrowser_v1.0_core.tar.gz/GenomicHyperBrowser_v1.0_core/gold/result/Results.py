# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.description.ResultInfo import ResultInfo
#from gold.application.RSetup import r
import numpy
import re
from gold.util.CustomExceptions import NotImplementedError
from quick.application.SignatureDevianceLogging import takes,returns
from collections import OrderedDict

class Results(dict):
#friend: ResultsViewer
    FDR_KEY = 'fdr'
    FDR_THRESHOLD = 0.1
    PVALUE_THRESHOLD = 0.05

    def __init__(self, trackName1, trackName2, statClassName):
        self._errors = []
        self._globalResult = None
        self._resDictKeys = None
        self._trackName1 = trackName1
        self._trackName2 = trackName2
        self._statClassName = statClassName
        self._analysis = None        
        self._analysisText = None #not needed anymore..
        self._runDescription = None
        self._resultInfo = ResultInfo(trackName1, trackName2, statClassName)
        dict.__init__(self)
    
    def setAnalysis(self, analysis): 
        self._analysis = analysis
        
    #probably obsolete
    def setAnalysisText(self, analysisText): 
        self._analysisText = analysisText
        
    def setRunDescription(self, descr):
        self._runDescription = descr
        
    def includeAdditionalResults(self, other, ensureAnalysisConsistency=True):
        if ensureAnalysisConsistency:
            raise NotImplementedError
        
        assert len( set(self.getResDictKeys()).intersection(other.getResDictKeys()) ) == 0
        
        for key in self:
            self[key].update(other.get(key))
        
        if self._globalResult is None:
            resKeys = self.getResDictKeys()
            self._globalResult = OrderedDict(zip(resKeys, [None]*len(resKeys)))
        
        if other._globalResult is not None:
            self._globalResult.update(other._globalResult)
        
        self._errors += other._errors
        self._resDictKeys = None #reset..
        
    def setGlobalResult(self, result):
        self._globalResult = result

    def complementGlobalResult(self, result):        
        if result is None:
            return
        assert type(result) in [dict, OrderedDict]

        if self._globalResult is None:
            self._globalResult = {}
        assert len( set(self._globalResult.keys()).intersection(set(result.keys())) ) == 0
        self._globalResult.update(result)
    
    def addError(self, exception):
        self._errors.append(exception)
    
    def getAllValuesForResDictKey(self, resDictKey):
        return [ self[reg].get(resDictKey) for reg in self.getAllRegionKeys() ]
    
    def getResDictKeys(self):
        if self._resDictKeys is None:
            #assert( self._globalResult is not None or len(self.keys()) > 0 )
            isOrdered = False
            
            if self._globalResult not in [None,{}]:
                isOrdered = (type(self._globalResult) == OrderedDict)
                keys = self._globalResult.keys()
                
            elif len(self.keys()) > 0:
                for val in self.values():
                    if val is not {}:
                        isOrdered = (type(self.values()[0]) == OrderedDict)
                        keys = self.values()[0].keys()
                        break
                else:
                    keys = []
            else:
                keys = []
                
            ASSEMBLY_GAP_KEY = 'Assembly_gap_coverage'
            
            pairs = [(self._resultInfo.getColumnLabel(key),key) for key in keys if not key==ASSEMBLY_GAP_KEY]
            if not isOrdered:
                pairs = sorted(pairs)
                
            if ASSEMBLY_GAP_KEY in keys:
                pairs.append( (self._resultInfo.getColumnLabel(ASSEMBLY_GAP_KEY),ASSEMBLY_GAP_KEY) )
                
            self._resDictKeys = [key for label,key in pairs]
        return self._resDictKeys
        
    def getAllRegionKeys(self):
        return sorted(self.keys())
    
    def getGlobalResult(self):
        return self._globalResult

    def getLabelHelpPair(self, resDictKey):
        return self._resultInfo.getColumnLabel(resDictKey), self._resultInfo.getHelpText(resDictKey)
    
    def getLabelHelpPairs(self):
        return [self.getLabelHelpPair(key) for key in self.getResDictKeys()]

    def getStatClassName(self):
        return self._statClassName
    
    def getTrackNames(self):
        return self._trackName1, self._trackName2

    def getAllErrors(self):
        return self._errors

    def getPresCollectionType(self):
        if self.getStatClassName() == 'DataComparisonStat': #a bit ad hoc criterion. Also should check plotType...
            presCollectionType = 'scatter'
        elif 'BinScaled' in self.getStatClassName(): #a bit ad hoc criterion. Also should check plotType...
            presCollectionType = 'binscaled'
        elif (self.getGlobalResult() not in [None,{}] and isinstance(self.getGlobalResult().values()[0], dict)):
            if self.getGlobalResult().values()[0].get('Matrix') is not None:
                presCollectionType = 'matrix'
            else:
                presCollectionType = 'dictofdicts'
        elif self.getGlobalResult() not in [None,{}] and len(self.getGlobalResult())==1 and hasattr(self.getGlobalResult().values()[0], '__iter__'):
            presCollectionType = 'distribution'
        else:
            presCollectionType = 'standard'
        return presCollectionType

    def getSignBins(self, pvals, threshold):
        numSign = sum(1 for x in pvals if x <= threshold)
        numTested = sum(1 for x in pvals if not numpy.isnan(x))
        numIgnored = len(pvals) - numTested
        return numSign, numTested, numIgnored
       
    def getSignBinsText(self, pvals, threshold):
        numSign, numTested, numIgnored = self.getSignBins(pvals, threshold)
        text = '%i significant bins out of %i, at %i' % (numSign, numTested, threshold*100) + '% FDR'
        if numIgnored > 0:
            text += ' (%i bin%s excluded)' % (numIgnored, ('' if numIgnored==1 else 's') )
        return text

    #The following methods help interprete data in results, and thus contains some definitions of semantics
    def isSignificanceTesting(self):
        return self.getPvalKey() is not None
    
    def getPvalKey(self):
        keys = self.getResDictKeys()
        if keys is not None:
            for key in keys:
                if re.search('p.*val',key.lower()) is not None:
                    return key
        return None

    def getTestStatisticKey(self):
        keys = self.getResDictKeys()
        if keys is not None:
            for key in keys:
                if re.search('test.?statistic',key.lower()) is not None or 'TSMC' in key:
                    return key
        return None

    def getExpectedValueOfTsKey(self):
        keys = self.getResDictKeys()
        if keys is not None:
            for key in keys:
                if re.search('e\(test.?statistic',key.lower()) is not None:
                    return key
        return None
    
    def inferAdjustedPvalues(self):
        from gold.application.RSetup import r
        pValKey = self.getPvalKey()
                
        if pValKey is None or self.FDR_KEY in self.getResDictKeys():
            return
        
        regKeys = self.getAllRegionKeys()
        regPVals = [ self[reg].get(pValKey) if (self[reg].get(pValKey) is not None) else numpy.nan for reg in regKeys]
        
        from gold.application.RSetup import r
        regFdrVals = r('p.adjust')(r.unlist(regPVals), self.FDR_KEY)
        if len(regPVals) == 1:
            regFdrVals = [regFdrVals]
        assert len(regFdrVals) == len(regKeys), 'fdr: ' + len(regFdrVals) + ', regs: ' + len(regKeys) 
        for i, reg in enumerate(regKeys):
            if regPVals[i] is not None:
                self[reg][self.FDR_KEY] = regFdrVals[i]
        
        if self._globalResult is None:
            keys = self.getResDictKeys()
            self._globalResult = OrderedDict(zip((keys), [None]*len(keys)))
        
        #self._globalResult[self.FDR_KEY] = self.getSignBinsText(regFdrVals, self.FDR_THRESHOLD)
        #if self._globalResult[pValKey] is None:
            #self._globalResult[pValKey] = self.getSignBinsText(regPVals, self.PVALUE_THRESHOLD)
        
        tempGlobalResult = self._globalResult
        self._globalResult = OrderedDict()
        
        self._globalResult.update([(pValKey, tempGlobalResult[pValKey])])    
        self._globalResult.update([(self.FDR_KEY, None)])
        self._globalResult.update([(key, tempGlobalResult[key]) for key in tempGlobalResult.keys() if key != pValKey])
        
        self._resDictKeys = None #resetting..
 
    def getLocalFdrValues(self):
        assert self.FDR_KEY in self.getResDictKeys()
        return [ self[reg][self.FDR_KEY] for reg in self.getAllRegionKeys()]

    @returns((int,int,int)) #numSign, numTested, numIgnored
    def getFdrSignBins(self, threshold=None):
        if threshold is None:
            threshold = self.FDR_THRESHOLD
            
        return self.getSignBins( self.getLocalFdrValues(), threshold)

    #@returns(str) 
    #def getFdrSignBinsText(self, threshold=None):
    #    if threshold is None:
    #        threshold = self.FDR_THRESHOLD
    #        
    #    return self.getSignBinsText( self.getLocalFdrValues())
        
    def hasOnlyLocalPvals(self):
        pvalKey = self.getPvalKey()
        globalRes = self.getGlobalResult()
        return (pvalKey is not None) and (globalRes is None or globalRes.get(pvalKey) is None or type(globalRes.get(pvalKey)) is str) #remove last part..

    def getTestStatisticText(self):
        key = self.getTestStatisticKey()
        if key is not None:
            key
            testStatText = self._resultInfo.getHelpText(key)
            if testStatText == '':
                testStatText = self._resultInfo.getColumnLabel(key)
            return testStatText
        else:
            return None
        
    #def getAdjustedPVals(self, resDictKey, adjustMethod):
    #    pValKey = 'p-value'
    #    if not resDictKey.lower() == pValKey:
    #        return None
    #    #if not pValKey in self.getResDictKeys():
    #        #return None        
    #    fdrVals = r('p.adjust')(r.unlist(self.getAllValuesForResDictKey(resDictKey)), adjustMethod)
    #    return fdrVals
        
    #def getNumSignificantAdjustedPVals(self, resDictKey, threshold, adjustMethod):
    #    fdrVals = self.getAdjustedPVals(resDictKey, adjustMethod)
    #    if fdrVals is None:
    #        return None
    #    return sum(1 for x in fdrVals if x <= threshold)

    
    #def items(self):
    #    return sorted(dict.items(self))
    
    #def addWarning(self):
    #    pass
    
