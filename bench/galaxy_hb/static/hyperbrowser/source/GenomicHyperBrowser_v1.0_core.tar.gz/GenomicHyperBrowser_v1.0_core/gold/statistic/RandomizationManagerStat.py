# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from numpy import nan, isnan,array, median
from gold.statistic.MagicStatFactory import MagicStatFactory
from gold.statistic.Statistic import Statistic, OnlyGloballySplittable
from gold.statistic.RawDataStat import RawDataStat
from gold.track.TrackFormat import NeutralTrackFormatReq
from gold.application.Config import VERBOSE
from gold.util.CommonFunctions import isIter
from gold.track.PermutedSegsAndIntersegsTrack import PermutedSegsAndIntersegsTrack
from gold.track.PermutedSegsAndSampledIntersegsTrack import PermutedSegsAndSampledIntersegsTrack
from gold.track.SegsSampledByIntensityTrack import SegsSampledByIntensityTrack
from gold.track.RandomGenomeLocationTrack import RandomGenomeLocationTrack
from gold.util.CompBinManager import CompBinManager
from gold.util.CustomExceptions import SplittableStatNotAvailableError
from gold.application.LogSetup import logMessage, logException
import logging
from gold.statistic.CountElementStat import CountElementStat
from collections import OrderedDict

class RandomizationManagerStat(MagicStatFactory):
    pass        
    @classmethod
    def getDescription(cls):
        return 'P-value obtained by Monte Carlo testing.'
    
class RandomizationManagerStatSplittable(Statistic, OnlyGloballySplittable):
    IS_MEMOIZABLE = False
    
    def _createChildren(self):                
        raise SplittableStatNotAvailableError

    def _compute(self):
        raise SplittableStatNotAvailableError

class RandomizationManagerStatUnsplittable(Statistic):
    IS_MEMOIZABLE = False
    
    def __init__(self, region, track, track2, rawStatistic, randTrackClass=None, assumptions=None, tails=None, numResamplings=2000, **kwArgs):
        if tails==None:
            if 'tail' in kwArgs:
                tailTranslator = {'more':'right-tail', 'less':'left-tail', 'different':'two-tail'}
                tails = tailTranslator[kwArgs['tail']]
                if VERBOSE:
                    logMessage('Argument tail provided instead of tails to RandomizationManagerStatUnsplittable', level=logging.DEBUG)
            else:
                tails = 'right-tail' # or 'two-tail'?
                logMessage('No tails argument provided to RandomizationManagerStatUnsplittable', level=logging.DEBUG)
        
        if track2 is None:
            self._track2 = None #to allow track2 to be passed on as None to rawStatistics without error. For use by single-track MC-tests..
            
        Statistic.__init__(self, region, track, track2, rawStatistic=rawStatistic, randTrackClass=randTrackClass, assumptions=assumptions, tails=tails, numResamplings=numResamplings, **kwArgs)
        if type(rawStatistic) is str:
            from gold.statistic.AllStatistics import STAT_CLASS_DICT
            rawStatistic = STAT_CLASS_DICT[rawStatistic]

        assert (randTrackClass is None) ^ (assumptions is None) # xor
        if assumptions is not None:
            assert assumptions.count('_') == 1, assumptions
            randTrackClass1, randTrackClass2 = assumptions.split('_')
        else:
            randTrackClass1 = None
            randTrackClass2 = randTrackClass
        
        self._randTrackClass1, self._randTrackClass2 = \
            [ ( globals()[clsDef] if clsDef not in ['None',''] else None ) \
                if type(clsDef) is str else clsDef for clsDef in [randTrackClass1, randTrackClass2] ]
        
        assert not (randTrackClass1 is None and randTrackClass2 is None)
        for cls in [self._randTrackClass1, self._randTrackClass2]:
            assert cls in [None, PermutedSegsAndSampledIntersegsTrack, \
                           PermutedSegsAndIntersegsTrack, RandomGenomeLocationTrack, SegsSampledByIntensityTrack]
            
        #print self._randTrackClass1, self._randTrackClass2
        self._rawStatistic = rawStatistic
        
        #self._randTrackList = []
        self._tails = tails
        self._numResamplings = int(numResamplings)
        CompBinManager.ALLOW_COMP_BIN_SPLITTING = False
        
    def _createRandomizedStat(self, i):
        "Creates a randChild where second track is randomized"
        tr1 = self._track if self._randTrackClass1 is None else \
              self._randTrackClass1(self._track, self._region, i, **self._kwArgs)
        
        tr2 = self._track2 if self._randTrackClass2 is None else \
              self._randTrackClass2(self._track2, self._region, i, **self._kwArgs)

        return self._rawStatistic(self._region, tr1, tr2, **self._kwArgs)

    def _createChildren(self):                
        self._realChild = self._addChild( self._rawStatistic(self._region, self._track, self._track2, **self._kwArgs) )        
        #logMessage(str(self._track._trackFormatReq)+ ' AND '+str(self._track2._trackFormatReq))
        #if self._track._trackFormatReq is not None and not self._track._trackFormatReq.isDense():
        if self._track._trackFormatReq is not None and not self._track._trackFormatReq.isDense() and not self._track._trackFormatReq.allowsOverlaps():
            self._pointCount1 = self._addChild( CountElementStat(self._region, self._track) )
        #else:
            #self._pointCount1 = None
        
        #if self._track2._trackFormatReq is not None and not self._track2._trackFormatReq.isDense():
        if self._track2._trackFormatReq is not None and not self._track2._trackFormatReq.isDense() and not self._track2._trackFormatReq.allowsOverlaps():
            self._pointCount2 = self._addChild( CountElementStat(self._region, self._track2) )
        #else:
            #self._pointCount2 = None
        #logMessage('AFTER: '+str(self._track._trackFormatReq)+ ' AND '+str(self._track2._trackFormatReq))

    def _compute(self):
        #if VERBOSE:
        #    print [randChild.getResult() for randChild in self._children]
        #try:
        if self._realChild.getResult() is None or isnan(self._realChild.getResult()):
            return None
        
        randResults = []
        #randResults = [self._createRandomizedStat(i).getResult() for i in xrange(self._numResamplings)]
        for i in xrange(self._numResamplings):
            #print 'computing randChild..'
            #print ',',
            randChild = self._createRandomizedStat(i)
            randResults.append( randChild.getResult() ) #only to ensure result is created, will be accessed afterwards..
        
        #logMessage(','.join([str(x) for x in randResults]))        
        numpyRandResults = array(randResults)

        observation = self._realChild.getResult()
        
        #meanOfNullDistr = 1.0 * sum( randResults ) / \
                             #self._numResamplings
        meanOfNullDistr = numpyRandResults.mean()
        medianOfNullDistr = median(numpyRandResults)
        sdOfNullDistr = numpyRandResults.std()
        #sdCountFromNullOfObs = (observation - meanOfNullDistr) / sdOfNullDistr
        diffObsMean = (observation - meanOfNullDistr)
        pvalEqual = 1.0 * sum(1 for res in randResults \
                         if res == observation ) / self._numResamplings
        pvalStrictRight = 1.0 * sum(1 for res in randResults \
                         if res > observation ) / self._numResamplings
        pvalStrictLeft = 1.0 * sum(1 for res in randResults \
                         if res < observation ) / self._numResamplings
        
        if self._tails == 'right-tail':
            pval = pvalStrictRight + pvalEqual
        elif self._tails == 'left-tail':
            pval = pvalStrictLeft + pvalEqual
        elif self._tails == 'two-tail':
            #pval = 2 * min(pvalStrictLeft, pvalStrictRight) + pvalEqual
            pval = min(1, 2 * min(pvalStrictLeft+ pvalEqual, pvalStrictRight+ pvalEqual))
        else:
            raise RuntimeError()
        
        if pval == 0:
            pval = 1.0 / self._numResamplings
        
        resDict = OrderedDict([('P-value', pval), ('TSMC_'+self.getRawStatisticMainClassName(), observation), ('MeanOfNullDistr', meanOfNullDistr), \
                              ('MedianOfNullDistr', medianOfNullDistr), ('SdNullDistr', sdOfNullDistr), ('DiffFromMean', diffObsMean)])
        
        #if self._pointCount1.getResult() is not None:
        #if self._track._trackFormatReq is not None and not self._track._trackFormatReq.isDense() and not self._track._trackFormatReq.allowsOverlaps():
        if hasattr(self, '_pointCount1'):
            numElTr1 = self._pointCount1.getResult()
            if numElTr1<1:
                resDict['P-value'] = None
            resDict.update({'NumPointsTr1':numElTr1})
        #if self._pointCount2.getResult() is not None:
        #if self._track2._trackFormatReq is not None and not self._track2._trackFormatReq.isDense() and not self._track2._trackFormatReq.allowsOverlaps():
        if hasattr(self, '_pointCount2'):    
            numElTr2 = self._pointCount2.getResult()
            if numElTr2<1:
                resDict['P-value'] = None
            resDict.update({'NumPointsTr2':numElTr2})
        
        return resDict
        #except Exception,e:
            #logException(e)
            
    def getRawStatisticMainClassName(self):
        return self._rawStatistic.__name__.replace('Splittable', '').replace('Unsplittable', '')
