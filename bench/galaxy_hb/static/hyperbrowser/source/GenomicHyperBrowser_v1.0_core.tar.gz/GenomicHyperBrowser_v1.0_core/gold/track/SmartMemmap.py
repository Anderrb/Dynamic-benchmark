# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import os
from numpy import memmap
import numpy
from gold.application.Config import MEMMAP_BIN_SIZE

class SmartMemmap(object):
    def __init__(self, fn, dtype, elementDim, mode='r'):
        self._fn = fn
        self._dtype = dtype
        self._mode = mode
        self._dTypeSize = numpy.dtype(dtype).itemsize
        self._origShape = ( (os.path.getsize(self._fn) / (self._dTypeSize * elementDim)), elementDim )
        self._cachedMemmapBinNum = None
        self._cachedMemmap = None

    def _crossesBoundary(self, i, j):
        return self._calcBinNum(i) != self._calcBinNum(j)
    
    def _createMemmap(self, i, j):
        if j > self._origShape[0]:
            j = self._origShape[0]

        if j == 0:
            shape = None
        elif self._origShape[1] == 1:
            shape = j-i
        else:
            shape = ((j-i), self._origShape[1])
        
        return memmap(self._fn, self._dtype, self._mode, offset = i*self._dTypeSize, shape = shape)
    
    def _calcBinNum(self, i):
        return i / MEMMAP_BIN_SIZE
    
    def _getLocalBinCoords(self, i, j):
        return i % MEMMAP_BIN_SIZE, j % MEMMAP_BIN_SIZE

    def _getBinMemmap(self, binNum):        
        if self._cachedMemmapBinNum != binNum:
            self._cachedMemmap = self._createMemmap(binNum * MEMMAP_BIN_SIZE, (binNum+1) * MEMMAP_BIN_SIZE)
            self._cachedMemmapBinNum = binNum
            
        return self._cachedMemmap
    
    def __getslice__(self, i, j):
        if self._crossesBoundary(i, j):
            return self._createMemmap(i, j)[:]
        
        binNum = self._calcBinNum(i)
        localI, localJ = self._getLocalBinCoords(i, j)
        return self._getBinMemmap(binNum)[localI:localJ]
    
    def __getitem__(self, i):
        binNum = self._calcBinNum(i)
        localI = self._getLocalBinCoords(i, 0)[0]
        item = self._getBinMemmap(binNum)[localI]
        return item

    def getShape(self):
        return self._origShape if self._origShape[1] != 1 else self._origShape[0:1]
    
    def getDType(self):
        return self._dtype
    
    shape = property( getShape )
    dtype = property( getDType )
