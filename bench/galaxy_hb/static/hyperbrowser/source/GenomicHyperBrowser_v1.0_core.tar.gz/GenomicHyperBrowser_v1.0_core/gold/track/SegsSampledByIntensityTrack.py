# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import numpy
from gold.track.RandomizedTrack import RandomizedTrack
from gold.util.CustomExceptions import IncompatibleTracksError, NotImplementedError
from gold.track.Track import PlainTrack

class SegsSampledByIntensityTrack(RandomizedTrack):    
    def __init__(self, origTrack, origRegion, randIndex, trackNameIntensity="", **kwArgs):
        #print 'INTENSITY TRACK IS USED!'
        self._minimal = ('minimal' in kwArgs and kwArgs['minimal'] is True)
        
        RandomizedTrack.__init__(self, origTrack, origRegion, randIndex, trackNameIntensity=trackNameIntensity, **kwArgs)
        self._trackNameIntensity = trackNameIntensity.split('|')

    def _checkTrackFormat(self, origTV):
        if origTV.trackFormat.isDense():
            raise IncompatibleTracksError()
        
    def _createRandomizedNumpyArrays(self, binLen, starts, ends, vals, strands, origTrackFormat):
        if self._minimal:
            return numpy.array([]), None, None, None
        
        intensityTV = PlainTrack(self._trackNameIntensity).getTrackView(self._origRegion) #Dependence on origRegion is not nice, but not a big problem..
        
        if intensityTV.trackFormat.isDense():
            assert intensityTV.trackFormat.isMarked('ordinal')
            return self._createRandomizedNumpyArraysFromIntensityFunction(binLen, starts, ends, vals, strands, intensityTV)
        else:
            raise NotImplementedError            
            
    def _createRandomizedNumpyArraysFromIntensityFunction(self, binLen, starts, ends, vals, strands, intensityTV):
        "Assumes function values are proportional to prior probabilities"        
        #if not ends == starts+1:
        #    print 'STARTS'
        #    print starts
        #    print ends
        assert (ends == starts+1).all()
        
        if len(starts)==0:
            assert len(ends)==0
            return starts, ends, vals, strands
        
        #Permute vals and strands. Later also segment lengths..        
        if vals is not None or strands is not None:
            permutedIndexes = numpy.random.permutation(max(len(starts), len(ends)))
            if vals is not None:
                vals = vals[permutedIndexes]    
            if strands is not None:
                strands = strands[permutedIndexes]
                
        #Make the cumulative distribution of prior along the bin, which is what we will sample from.
        cumulative = numpy.add.accumulate( intensityTV.valsAsNumpyArray() )
        cumulative = cumulative / cumulative[-1] #normalize        
        
        #Sample positions based on cumulative distribution. Iteratively sample new positions and remove overlap.
        sampledPositions = numpy.array([],dtype='i')
        numTries = 0
        while len(sampledPositions) < len(starts):
            numTries+=1
            if numTries > 200:
                raise RuntimeError('More than 200 tries at drawing random numbers from intensity. Trying to draw '+\
                                   str(len(starts)) + ' non-overlapping points among ' + str(len(cumulative)) + \
                                   ' positions, still lacking ' + str(len(starts)-len(sampledPositions)) + ' points.')
            
            numRemainingSamples = len(starts) - len(sampledPositions)
            sampledProbs = numpy.random.rand( numRemainingSamples) #fixme: includes 1?
        
            newSampledPositions = cumulative.searchsorted( sampledProbs) #fixme: +/-1 here..
            sampledPositions = numpy.append( sampledPositions, newSampledPositions)
            sampledPositions = numpy.unique1d(sampledPositions) 
            
        #Handle segments, by simply permuting original segment lengths and add these back to new sart positions
        #fixme: Must include overlap handling for segment case and be put into the iterative sampling..
        #fixme: Must also remove segments crossing bin border..
        #segLens = ends - starts
        #numpy.random.shuffle(segLens)
        #newEnds = sampledPositions + segLens
        #return sampledPositions, newEnds, None, None
    
        return sampledPositions, None, vals, strands
        
