# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import copy
import os
import os.path
import third_party.safeshelve as safeshelve
from datetime import datetime
from gold.util.CommonFunctions import createOrigPath
from gold.result.HtmlCore import HtmlCore
from gold.application.Config import TRACKINFO_SHELVE_FN
from gold.track.TrackFormat import TrackFormat

SHELVE_FN = TRACKINFO_SHELVE_FN

class TrackInfo(object):
    def __new__(cls, genome, trackName):
        #Temporary hack
        if genome in ['hg18','NCBI36']:
            genome = 'NCBI36'
        
        trackInfoShelve = safeshelve.open(SHELVE_FN, 'r')
        stored = trackInfoShelve.get( TrackInfo._constructKey(genome, trackName) )
        trackInfoShelve.close()
        if stored is not None:
            return stored
        else:
            return object.__new__(cls)
    
    def __init__(self, genome, trackName):
        #Temporary hack
        if genome in ['hg18','NCBI36']:
            genome = 'NCBI36'

        existingAttrs = copy.copy(self.__dict__)
        assert existingAttrs.get('trackName') in [None, trackName], '%s not in [None, %s]' % (existingAttrs.get('trackName'), trackName) #An exception could here occurr if there is a preprocessed directory that contains colon in its name, as this may lead to splitting some place and not splitting other places..
        assert existingAttrs.get('genome') in [None, genome], '%s not in [None, %s]' % (existingAttrs.get('genome'), genome)
        self.trackName = trackName
        self.genome = genome
        
        #self.id = self._constructId()
        self.id = None
        
        self.description = ''
        self.methods = ''
        self.credits = ''
        self.restrictions = ''
        self.version = ''
        self.hbContact = ''
        self.reference = ''
        self.quality = ''
        
        self.private = False
        
        #self.trackSource = ''
 
        self.lastUpdatedBy = ''
        self.timeOfLastUpdate = None
        
        #self.header = ''
        self.fileType = ''
        self.trackFormatName = ''
        self.markType = ''
        self.origElCount = None
        self.clusteredElCount = None
        self.timeOfPreProcessing = None
        self.preProcVersion = ''

        self.__dict__.update(existingAttrs)
        
    #def _constructId(self):
    #    self.constructId(self.genome, self.trackName)
    def isValid(self, fullAccess=True):
        return (fullAccess or not self.private) and \
                self.timeOfPreProcessing is not None
    
    def store(self):
        trackInfoShelve = safeshelve.open(SHELVE_FN)
        trackInfoShelve[ TrackInfo._constructKey(self.genome, self.trackName) ] = self
        trackInfoShelve.close()
        
    def removeEntryFromShelve(self):
        trackInfoShelve = safeshelve.open(SHELVE_FN)
        del trackInfoShelve[ TrackInfo._constructKey(self.genome, self.trackName) ]
        trackInfoShelve.close()
        
    # fixme: for older preprocessor solutions. Only for back compability. To be removed later.
    def setPreProcessInfo(self, fileType, trackFormat, preProcVersion, id, origElCount=None, clusteredElCount=None):
        #self.header = header
        self.fileType = fileType
        self.trackFormatName = trackFormat.getFormatName()
        self.markType = trackFormat.getMarkName()
        self.timeOfPreProcessing = datetime.now()
        self.preProcVersion = preProcVersion
        self.id = id

        #fixme: Temporarily fixed incosistencies between old and first try of new preprocessors in which parameters are sent. To be removed.
        if origElCount in [True,False]:
            if origElCount:
                self.origElCount = clusteredElCount
            else:
                self.clusteredElCount = clusteredElCount
            return

        if origElCount not in [None, 0]:
            self.origElCount = origElCount
        if clusteredElCount not in [None, 0]:
            self.clusteredElCount = clusteredElCount
        
    def __str__(self):
        core = HtmlCore()
        core.descriptionLine('HyperBrowser contact', self.hbContact)
        core.descriptionLine('Version', self.version)
        core.descriptionLine('Quality', self.quality)
        if self.origElCount is not None:
            core.descriptionLine('Original element count', str(self.origElCount))
        if self.clusteredElCount is not None:
            core.descriptionLine('Element count after clustering', str(self.clusteredElCount))
        return self.mainInfo() + str(core)

    def mainInfo(self, printEmpty=True):
        core = HtmlCore()
        if printEmpty or self.description not in  ['', None]:
            core.descriptionLine('Description', self.description) 
        if printEmpty or self.reference not in  ['', None]:
            core.descriptionLine( 'Reference', str( HtmlCore().link(self.reference, self.reference, True) )\
                              if self.reference.startswith('http://') else self.reference )
        core.descriptionLine('Track format', self.trackFormatName)
        if self.markType not in [None,'']:            
            core.descriptionLine('Mark type', self.markType)
        return str(core)
    
    def getUIRepr(self):
        return (('Description', 'description', self.description, 'textbox'),
                ('Version', 'version', self.version, 'textbox'),
                ('Reference', 'reference', self.reference, 'textbox'),
                ('HyperBrowser contact', 'hbContact', self.hbContact, 'textbox'),
                ('Quality', 'quality', self.quality, 'textbox'),
                ('Private (our group only)', 'private', self.private, 'checkbox'),
                ('File type', None, self.fileType, 'text'),
                ('Track format', None, self.trackFormatName, 'text'),
                ('Mark type', None, self.markType, 'text'),
                ('Original element count', None, self.origElCount, 'text'),
                ('Element count after clustering', None, self.clusteredElCount, 'text'),
                ('Time of preprocessing', None, self.timeOfPreProcessing, 'text'),
                ('Time of last update', None, self.timeOfLastUpdate, 'text'),
                ('Last update by', None, self.lastUpdatedBy, 'text'))
    
    def setAttrs(self, attrDict, userName):
        self.__dict__.update(attrDict)
        self.lastUpdatedBy = userName
        self.timeOfLastUpdate = datetime.now()

    @staticmethod
    def constructId(genome, trackName, preProcVersion):
        origPath = createOrigPath(genome, trackName, '')
        fileHash = hash(tuple([ (fn, os.stat(os.sep.join([origPath, fn])).st_mtime ) for fn in sorted(os.listdir(origPath))\
                          if os.path.isfile(origPath+os.sep+fn) and fn[0]!='.']))
        return hash( (fileHash, preProcVersion) )

    @staticmethod
    def constructIdByTimeStamp():
        return hash(datetime.now())
    
    @staticmethod
    def _constructKey(genome, trackName):
        key = ':'.join([genome] + trackName)
        assert type(key) == str, 'Non-str key: ' + key + ' of type: ' + str(type(key)) + '. Specific types: ' + str([type(x) for x in [genome] + trackName])
        return key
    
    # fixme: For old preprocessor solution? Or?
    @staticmethod
    def finalizeTrack(genome, trackName, prefixList, valDataType, valDim):
        format = TrackFormat.createInstanceFromPrefixList( prefixList, valDataType, valDim )
        id = TrackInfo.constructIdByTimeStamp()
            
        trackInfo = TrackInfo(genome, trackName)
        trackInfo.setPreProcessInfo(None, format, None, id)
        trackInfo.store()

class TrackInfoDataCollector(object):
    def __init__(self, genome, trackName):
        self._tempTrackInfo = TrackInfo(genome, ['Temp'] + trackName)
        
        existingAttrs = copy.copy(self._tempTrackInfo.__dict__)
        
        self._tempTrackInfo.preProcDirty = False
        self._tempTrackInfo.maxSourceLineLen = None
        self._tempTrackInfo.prefixList = None
        self._tempTrackInfo.valDataType = None
        self._tempTrackInfo.valDim = None
        
        self._tempTrackInfo.__dict__.update(existingAttrs)
        
    def updateFileSizeInfoForPreProc(self, allowOverlaps, numElements, maxSourceLineLen):
        if allowOverlaps:
            self._tempTrackInfo.origElCount = numElements
            self._tempTrackInfo.maxSourceLineLen = 0
        else:
            self._tempTrackInfo.clusteredElCount = numElements
            self._tempTrackInfo.maxSourceLineLen = maxSourceLineLen
            
        self._tempTrackInfo.store()
        
    def updateMetaDataForFinalization(self, fileType, prefixList, valDataType, valDim, preProcVersion):
        assert self._tempTrackInfo.fileType in [None, '', fileType], 'Files in the same folder have different fileType [%s != %s]' % (self._tempTrackInfo.fileType, fileType)
        assert self._tempTrackInfo.prefixList in [None, prefixList], 'Files in the same folder have different prefixLists [%s != %s] (different formats?)' % (self._tempTrackInfo.prefixList, prefixList)
        assert self._tempTrackInfo.valDataType in [None, valDataType], 'Files in the same folder have different valDataType [%s != %s] (different formats?)' % (self._tempTrackInfo.valDataType, valDataType)
        assert self._tempTrackInfo.valDim in [None, valDim], 'Files in the same folder have different valDim [%s != %s] (different formats?)' % (self._tempTrackInfo.valDim, valDim)
        assert self._tempTrackInfo.preProcVersion in [None, '', preProcVersion], 'Files in the same folder use geSources with different version [%s != %s] (strange..)' % (self._tempTrackInfo.preProcVersion, preProcVersion)
        
        self._tempTrackInfo.fileType = fileType
        self._tempTrackInfo.prefixList = prefixList
        self._tempTrackInfo.valDataType = valDataType
        self._tempTrackInfo.valDim = valDim
        self._tempTrackInfo.preProcVersion = preProcVersion
        
        self._tempTrackInfo.store()

    def updatePreProcDirtyStatus(self, dirty):
        if dirty:
            self._tempTrackInfopreProcDirty = True
            self._tempTrackInfo.store()
                    
    def getNumElements(self, allowOverlaps):
        if allowOverlaps:
            return self._tempTrackInfo.origElCount
        else:
            return self._tempTrackInfo.clusteredElCount
        
    def getMaxSourceLineLen(self):
        return self._tempTrackInfo.maxSourceLineLen
    
    def getPrefixList(self, allowOverlaps):
        return [x for x in self._tempTrackInfo.prefixList if not (x == 'source' and allowOverlaps)]
    
    def getValDataType(self):
        return self._tempTrackInfo.valDataType
    
    def getValDim(self):
        return self._tempTrackInfo.valDim
        
    def finalizeIfDirty(self):
        if self._tempTrackInfo.preProcDirty:
            ti = TrackInfo(self._tempTrackInfo.genome, self._tempTrackInfo.trackName[1:])
            
            #ti.header = header
            ti.fileType = self._tempTrackInfo.fileType
            trackFormat = TrackFormat.createInstanceFromPrefixList( self._tempTrackInfo.prefixList, \
                                                                    self._tempTrackInfo.valDataType, \
                                                                    self._tempTrackInfo.valDim )
            ti.trackFormatName = trackFormat.getFormatName()
            ti.markType = trackFormat.getMarkName()
            ti.preProcVersion = self._tempTrackInfo.preProcVersion

            ti.origElCount = self._tempTrackInfo.origElCount
            ti.clusteredElCount = self._tempTrackInfo.clusteredElCount

            ti.id = TrackInfo.constructIdByTimeStamp()
            ti.timeOfPreProcessing = datetime.now()
            
            ti.store()
            
        self._tempTrackInfo.removeEntryFromShelve()
