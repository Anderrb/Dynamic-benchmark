from gold.origdata.GESourceWrapper import ListGESourceWrapper
from gold.origdata.GEOverlapClusterer import GEOverlapClusterer
from gold.origdata.GenomeElementSource import SourceLineGESource
from copy import copy

class GESourceManager(object):
    def __init__(self, geSource):
        self._geSource = geSource
        self._sortedGEBuckets = {}
        self._sortedAndClusteredGEBuckets = {}
        self._splitAndProcess()
        self._maxSourceLineLens = {}
        
    def _splitAndProcess(self):
        geBuckets = {}
        for el in self._geSource:
            if el.chr not in geBuckets:
                geBuckets[el.chr] = []
            geBuckets[el.chr].append(copy(el))
        
        for chr in geBuckets:
            packedElements = [ (el.chr, el.start, el.end, copy(el)) for el in geBuckets[chr]]
            self._sortedGEBuckets[chr] = [x[-1] for x in sorted(packedElements)]
            geBuckets[chr] = None

        for chr in self._sortedGEBuckets:
            self._sortedAndClusteredGEBuckets[chr] = \
                list( GEOverlapClusterer(ListGESourceWrapper(self._geSource, self._sortedGEBuckets[chr])) )
                    
    def getAllChrs(self):
        return sorted(self._sortedGEBuckets.keys())
    
    def _getBuckets(self, allowOverlaps):
        return self._sortedGEBuckets if allowOverlaps else self._sortedAndClusteredGEBuckets
    
    def getSortedGESource(self, chr, allowOverlaps):
        assert chr in self.getAllChrs()
        return ListGESourceWrapper(self._geSource, self._getBuckets(allowOverlaps)[chr])
        
    def getNumElements(self, chr, allowOverlaps):
        return len(self._getBuckets(allowOverlaps)[chr])
    
    def getMaxSourceLineLen(self, chr):
        if not chr in self._maxSourceLineLens:
            if isinstance(self._geSource, SourceLineGESource):
                self._maxSourceLineLens[chr] = max(len(el.source) for el in self._sortedGEBuckets[chr])
            else:
                self._maxSourceLineLens[chr] = 0
        return self._maxSourceLineLens[chr]
