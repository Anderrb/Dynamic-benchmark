# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.track.GenomeRegion import GenomeRegion

class GenomeElement(GenomeRegion):
    @staticmethod
    def createGeFromTrackEl(trackEl):
        genome = trackEl._trackView.genomeAnchor.genome
        chr = trackEl._trackView.genomeAnchor.chr
        return GenomeElement(genome, chr, trackEl.start(), trackEl.end(), trackEl.val(), trackEl.strand())
        
    def __init__(self, genome=None, chr=None, start=None, end=None, val=None, strand=None, subtype=None, source=None,**kwArgs):
        self.genome = genome
        self.subtype = subtype
        self.chr = chr
        self.start = start
        self.end = end
        self.val = val
        self.strand = strand
        self.source = source
        #id
        #descr

        for kw in kwArgs:
            self.__dict__[kw] = kwArgs[kw]

#    def __eq__(self, other):
        #print ([self.genome, self.subtype, self.chr, self.start, self.end, self.val, self.strand, self.source], \
               #[other.genome, other.subtype, other.chr, other.start, other.end, other.val, other.strand, other.source])
#        return [self.genome, self.subtype, self.chr, self.start, self.end, self.val, self.strand, self.source] == \
#               [other.genome, other.subtype, other.chr, other.start, other.end, other.val, other.strand, other.source]
    
    def __str__(self):
        #self.start+1 because we want to show 1-indexed end-inclusive output
        return (str(self.chr) + ':' if not self.chr is None else '')\
            + (str(self.start+1) if not self.start is None else '')\
            + ('-' + str(self.end) if not self.end is None else '')\
            + ((' (Pos)' if self.strand else ' (Neg)') if not self.strand is None else '')\
            + ((' [' + str(self.val) + ']') if self.val != None else '')
    
    def __cmp__(self, other):    
        if other is None:
            return -1
        else:
            return cmp([self.genome, self.subtype, self._fixChr(self.chr), self.start, self.end, self.val, self.strand, self.source] , \
                [other.genome, other.subtype, self._fixChr(other.chr), other.start, other.end, other.val, other.strand, other.source])
        
    def validAsRegion(self):
        return not None in [self.genome, self.chr, self.start, self.end]
    

#class GenomeElementSomeSubType():
#    source
#    featureType
#    score
#    frame
#
#    GffAttributes()
#    
#    seq
#
#    containingSeq
#    containingInterval
#    
#    valid
