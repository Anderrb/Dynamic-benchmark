# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

class GESourceWrapper(object):
    def __init__(self, geSource):
        self._geSource = geSource
    
    def getTrackName(self):
        return self._geSource.getTrackName()
    
    def getGenome(self):
        return self._geSource.getGenome()
        
    def getFileName(self):
        return self._geSource.getFileName()
        
    def getFileSuffix(self):
        return self._geSource.getFileSuffix()
        
    def getPrefixList(self):
        return self._geSource.getPrefixList()

    def getValDataType(self):
        return self._geSource.getValDataType()

    def getValDim(self):
        return self._geSource.getValDim()
        
    def getVersion(self):
        return self._geSource.getVersion()
    
    genome = property(getGenome)
    
class ListGESourceWrapper(GESourceWrapper):
    def __init__(self, geSource, geList):
        GESourceWrapper.__init__(self, geSource)
        self._geList = geList

    def __iter__(self):
        for el in self._geList: 
            yield el
        
    
    