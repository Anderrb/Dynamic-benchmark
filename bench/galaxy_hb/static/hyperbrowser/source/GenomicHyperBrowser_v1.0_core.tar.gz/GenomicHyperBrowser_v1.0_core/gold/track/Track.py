# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.track.TrackViewLoader import TrackViewLoader 
from gold.track.TrackSource import TrackSource
from gold.track.TrackFormat import TrackFormatReq, NeutralTrackFormatReq
from gold.util.CommonFunctions import getClassName, prettyPrintTrackName
from gold.util.CustomExceptions import IncompatibleTracksError
from gold.formatconversion.AllFormatConverters import getFormatConverters, getFormatConverterByName
from gold.description.TrackInfo import TrackInfo

class Track(object):
    IS_MEMOIZABLE = True
    def __new__(cls, trackName):
        if trackName == [] or trackName is None:
            return None
        else:
            # DeprecationWarning: object.__new__() takes no parameters
            return object.__new__(cls)
    
    def __init__(self, trackName):
        'trackName must be a list of names ["sequence"] ?'
        self.trackName = trackName
        self._trackSource = TrackSource()
        self._trackViewLoader = TrackViewLoader()
        self._trackFormatReq = NeutralTrackFormatReq()
        self.formatConverters = None
        self._trackId = None
        
    def getTrackView(self, region, includeSource=False):
        """
        region: loads defined region from disk. also input til trackViewLoader
        ganske usikker paa formatConverters opplegget. alt etter origTrackView definisjonen.
        ??        
        """
        if self._trackFormatReq.forceAllowsOverlaps():
            allowsOverlaps = True
        else:
            allowsOverlaps = self._trackFormatReq.allowsOverlaps()
        borderHandling = self._trackFormatReq.borderHandling()
        assert(allowsOverlaps is not None) 
        assert(borderHandling is not None) 
        
        trackData = self._trackSource.getTrackData(self.trackName, region.genome, region.chr, includeSource, allowsOverlaps)
        origTrackView = self._trackViewLoader.loadTrackView(trackData, region, borderHandling, allowsOverlaps)

        if self.formatConverters is None:
            self.formatConverters = getFormatConverters(origTrackView.trackFormat, self._trackFormatReq)
        
        if self.formatConverters == []:
            raise IncompatibleTracksError(prettyPrintTrackName(self.trackName) + ' with format: '\
                                          + str(origTrackView.trackFormat) +
                                          ('(' + origTrackView.trackFormat._mark + ')' if origTrackView.trackFormat._mark else '') + \
                                          ' does not satisfy ' + str(self._trackFormatReq))
        
        if not self.formatConverters[0].canHandle(origTrackView.trackFormat, self._trackFormatReq):
            raise IncompatibleTracksError(getClassName(self.formatConverters[0]) +\
                                          ' does not support conversion from ' + str(origTrackView.trackFormat) + \
                                          ' to ' + str(self._trackFormatReq))
        return self.formatConverters[0].convert(origTrackView)

    def addFormatReq(self, requestedTrackFormat):
        prevFormatReq = self._trackFormatReq
        self._trackFormatReq = TrackFormatReq.merge(self._trackFormatReq, requestedTrackFormat)
        if self._trackFormatReq is None:
            raise IncompatibleTracksError(str(prevFormatReq ) + \
                                          ' is incompatible with additional ' + str(requestedTrackFormat))
    
    def setFormatConverter(self, converterClassName):
        assert( self.formatConverters is None )
        if converterClassName is not None:        
            self.formatConverters = [getFormatConverterByName(converterClassName)]
    
    def getUniqueKey(self, genome):
        assert self.formatConverters is not None and len(self.formatConverters) == 1, 'FC: '+str(self.formatConverters)
        assert( not None in [self._trackFormatReq.allowsOverlaps(), \
                             self._trackFormatReq.borderHandling()] )
        
        if not self._trackId:
            self._trackId = TrackInfo(genome, self.trackName).id
            
        return hash((tuple(self.trackName), self._trackId, getClassName(self.formatConverters[0]), \
                     self.formatConverters[0].VERSION, self._trackFormatReq.allowsOverlaps(), \
                     self._trackFormatReq.borderHandling()))

class PlainTrack(Track):
    def __init__(self, trackName):
        Track.__init__(self, trackName)
        self.addFormatReq(TrackFormatReq(allowOverlaps=False, borderHandling='crop'))
        
    def getUniqueKey(self, genome):
        assert( not None in [self._trackFormatReq.allowsOverlaps(), \
                             self._trackFormatReq.borderHandling()] )
        
        if not self._trackId:
            self._trackId = TrackInfo(genome, self.trackName).id
            
        return hash((tuple(self.trackName), self._trackId, self._trackFormatReq.allowsOverlaps(), \
                     self._trackFormatReq.borderHandling()))
