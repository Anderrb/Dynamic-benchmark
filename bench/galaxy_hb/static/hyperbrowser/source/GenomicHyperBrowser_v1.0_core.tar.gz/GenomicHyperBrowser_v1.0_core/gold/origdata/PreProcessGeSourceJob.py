#from gold.origdata.SplitGESourceByChrs import SplitGESourceByChrs
from gold.description.TrackInfo import TrackInfo, TrackInfoDataCollector
from gold.origdata.OutputDirectory import OutputDirectory
from gold.util.CommonFunctions import createDirPath
from quick.util.GenomeInfo import GenomeInfo
from gold.util.CustomExceptions import EmptyGESourceError
from gold.application.Config import PROCESSED_DATA_PATH
import os
import shutil

class PreProcessGeSourceJob(object):
    MODE = 'Real'

    #def __new__(cls, geSource, allowOverlaps):
    #    format = TrackFormat.createInstanceFromGeSource(geSource)
    #    if format.reprIsDense():
    #        return PreProcessFunctionGeSourceJob.__new__(cls, geSource, allowOverlaps)
    #    else:
    #        return PreProcessGeneralGeSourceJob.__new__(cls, geSource, allowOverlaps)
        
    def __init__(self, trackName, allowOverlaps, chr, geSource):
        self._trackName = trackName
        self._allowOverlaps = allowOverlaps
        self._chr = chr
        self._geSource = geSource
        self._genome = geSource.getGenome()
        #self.id
        #self._format = TrackFormat.createInstanceFromGeSource(geSource)
        self._preProcFilesExistsCached = None
        #self._numGEPreProcessed = None
        self._dirty = False
        
    def process(self):      
        self._removeOutdatedPreProcessedFiles()
        fn = self._geSource.getFileName()
                 
        if self.MODE == 'Simulated':
            print os.linesep + 'Would now have processed fn: %s with allowOverlaps: %s in a real run' % (fn, self._allowOverlaps)
        elif self.MODE == 'UpdateMeta':
            print os.linesep + 'Only updating meta info based on file: %s with allowOverlaps: %s' % (fn, self._allowOverlaps)
            self._dirty = True #fake processing, to ensure trackInfo will be updated outside this scope..
        elif self.MODE == 'Real':            
            print os.linesep + 'Processing fn: %s with allowOverlaps: %s' % (fn, self._allowOverlaps)
            
            #try:
            #    self._process(enforceSorting=False)
            #except NotValidGESequence, e:
            #    print 'Invalid element found: %s' %e
            #    self._process(enforceSorting=True)
            self._createPreProcFiles()
            self._dirty = True
    
    def _removeOutdatedPreProcessedFiles(self):
        if self._preProcFilesExists():
            dirPath = createDirPath(self._trackName, self._genome, '', self._allowOverlaps)
            
            assert( dirPath.startswith(PROCESSED_DATA_PATH) )
            if self.MODE == 'Real':
                print 'Removing outdated preprocessed data: ', dirPath
                shutil.rmtree(dirPath)
            else:
                print 'Would now have removed outdated preprocessed data if real run: ', dirPath
    
    def _preProcFilesExists(self):
        if self._preProcFilesExistsCached is None:
            #ge = self._geSource.__iter__().next()
            #dirPath = createDirPath(self._trackName, ge.genome, ge.chr, self._allowOverlaps)
            dirPath = createDirPath(self._trackName, self._genome, self._chr, self._allowOverlaps)
            self._preProcFilesExistsCached = os.path.exists(dirPath)

        return self._preProcFilesExistsCached

    #@staticmethod    
    #def _createPreProcFiles(geSource, numElements, maxLineLength, allowOverlaps):
    def _createPreProcFiles(self):
        dirPath = createDirPath(self._trackName, self._genome, self._chr, self._allowOverlaps)
        
        collector = TrackInfoDataCollector(self._genome, self._trackName)
        collector.updateMetaDataForFinalization(self._geSource.getFileSuffix(), self._geSource.getPrefixList(), \
                                                self._geSource.getValDataType(), self._geSource.getValDim(), \
                                                self._geSource.getVersion())
        
        dir = OutputDirectory(dirPath, collector.getPrefixList(self._allowOverlaps), \
                              collector.getNumElements(self._allowOverlaps),\
                              GenomeInfo.getChrLen(self._genome, self._chr), \
                              collector.getValDataType(), collector.getValDim(), \
                              collector.getMaxSourceLineLen())        
        
        atLeastOneGE = False
        for ge in self._geSource:
            dir.writeElement(ge)
            atLeastOneGE = True
        
        if not atLeastOneGE:
            raise EmptyGESourceError
        
        dir.close()
        #return i+1 #The number of genome elements processed

    #def _getSortedGeSource(self, geSource, enforceSorting):
    #    if enforceSorting:
    #        if self._allowOverlaps:
    #            return GenomeElementSorter(geSource)
    #        else:
    #            return GEOverlapClusterer(GenomeElementSorter(geSource))
    #    else:
    #        return SortedAndNoOverlapsAsserter(geSource)

    #def _process(self, enforceSorting):
    #def _process(self):
        #splitter = SplitGESourceByChrs(self._geSource)
        #for chr in splitter.getAllChrs():
        #chrGESource = splitter.getGESource(chr)        
        #sortedChrGeSource = self._getSortedGeSource(chrGESource, enforceSorting)
        #if enforceSorting:
        #    print 'Sorting and overlap removal is being performed on data source.'
        #    sortedChrGESource.__iter__() #to load and sort data first for more accurate progress indication.. 
        #    print 'Continuing preprocessing of data source..'

        #self._numGEPreProcessed = self._createPreProcFiles(sortedChrGESource, dirMetaInfoDict, newDirsStartList, allowOverlaps)

    def shouldPreProcess(self):
        storedInfo = TrackInfo(self._genome, self._trackName)
        validExists = self._preProcFilesExists() and \
            storedInfo.isValid() and \
            TrackInfo.constructId(self._genome, self._trackName, self._geSource.getVersion()) == storedInfo.id and \
            self._geSource.getVersion() == storedInfo.preProcVersion
        return not validExists

    def hasModifiedData(self):
        return self._dirty

    #def getNumProcessedElements(self):
    #    if self._numGEPreProcessed is None:
    #        return 0
    #    return self._numGEPreProcessed

    
#class PreProcessFunctionGeSourceJob(PreProcessGeSourceJob):
#    def shouldPreProcess(self):
#        if self._allowOverlaps:
#            return False
#        return PreProcessGeSourceJob.shouldPreProcess()
