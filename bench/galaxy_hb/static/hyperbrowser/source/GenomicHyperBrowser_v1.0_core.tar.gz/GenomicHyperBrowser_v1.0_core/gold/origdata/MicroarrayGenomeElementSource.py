# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.origdata.GenomeElementSource import GenomeElementSource, SourceLineGESource
from gold.util.CommonFunctions import getStrandFromString, splitOnWhitespaceWhileKeepingQuotes
from gold.util.CustomExceptions import InvalidFormatError
import numpy
import re

class MicroarrayGenomeElementSource(GenomeElementSource, SourceLineGESource):
    def __new__(cls, fn, *args, **kwArgs):
        f = open(fn)
        trackDef = f.readline().replace('\'','"')
        if not trackDef.startswith('track type="array"'):
            raise InvalidFormatError('Track definition line must start with: track type="array". Line: ' + trackDef)
        
        header = cls._parseHeader(trackDef)
        if not all(key in header for key in ['expScale', 'expStep', 'expNames']):
            raise InvalidFormatError('Track definition line must define values for expScale, expStep and expNames: ' + trackDef)
        expNames = header['expNames']
        if not all(expNames[i] == '"' for i in [0,-1]):
            raise InvalidFormatError('expNames does not start and end in quote marks: ' + trackDef)
        
        ob = BaseMicroarrayGenomeElementSource.__new__(BaseMicroarrayGenomeElementSource, *args, **kwArgs)
        ob._globExpCount = len( [x for x in expNames[1:-2].split(',') if x != ''] )
        if ob._globExpCount < 3:
            raise InvalidFormatError('Microarray data must have at least 3 experiments. Length of expNames: ' + str(ob._globExpCount))
        return ob
    
    @staticmethod
    def _parseHeader(headerLine):
        return dict( [ pair.split('=') for pair in splitOnWhitespaceWhileKeepingQuotes( headerLine )[2:] ] )
  
class BaseMicroarrayGenomeElementSource(MicroarrayGenomeElementSource):
    _VERSION = '1.3'
    _numHeaderLines = 1
    
    def __new__(cls, *args, **kwArgs):
        return object.__new__(cls)
    
    def _next(self, line):
        cols = line.split()
        if len(cols) != 15:
            raise InvalidFormatError('File must contain exactly 15 columns, contains ' + str(len(cols)))

        self._genomeElement.chr = self._checkValidChr(cols[0])
        self._genomeElement.start = self._checkValidStart(self._genomeElement.chr, int(cols[1]))
        self._genomeElement.end = self._checkValidEnd(self._genomeElement.chr, int(cols[2]))
        self._genomeElement.strand = getStrandFromString(cols[5])
        
        self._genomeElement.val = [numpy.nan] * self._globExpCount
        expCount = int(cols[12])
        expIds = [int(x) for x in cols[13].split(',') if x != '']
        expScores = [numpy.float(x) for x in cols[14].split(',') if x != '']
        
        if len(expIds) != expCount:
            raise InvalidFormatError('expId length (' + str(len(expIds)) + ') is not equal to expCount (' + str(expCount) + ')') 
        if len(expScores) != expCount:
            raise InvalidFormatError('expScores length (' + str(len(expIds)) + ') is not equal to expCount (' + str(expScores) + ')') 

        for i in range(expCount):
            if expIds[i] >= self._globExpCount:
                raise InvalidFormatError('expId ' + str(expIds[i]) + ' too large. expNames in header line defines ' + str(self._globExpCount) + ' experiments. '+\
                                         'Thsi could be because of counting from 1 instead of from 0.')
            self._genomeElement.val[ expIds[i] ] = expScores[i]
        
        return self._genomeElement
    
    def getValDataType(self):
        return 'float32'

    def getValDim(self):
        return self._globExpCount