# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.track.TrackView import TrackView
from gold.formatconversion.FormatConverter import FormatConverter
from gold.formatconversion.SegmentToPointFormatConverter import SegmentToStartPointFormatConverter, \
    SegmentToMidPointFormatConverter, SegmentToEndPointFormatConverter
from gold.util.CustomExceptions import NoMoreUniqueValsError
import numpy
#from gold.application.LogSetup import logMessage

class IterateUniqueValsFormatConverter(FormatConverter):
    def __init__(self, sourceFormat=None, reqFormat=None):
        FormatConverter.__init__(self, sourceFormat, reqFormat)
        self._allVals = numpy.array([])
        self._valRegs = set([])
        self._prevRegs = set([])
        self._silent = False

    def reset(self):
        self._allVals = numpy.array([])
        self._valRegs = set([])
        self._prevRegs = set([])
        self._silent = False

    def silence(self):
        self._silent = True
        
    def convert(self, tv):
        if self._silent:
            newTv = TrackView(tv.genomeAnchor, \
                              numpy.array([]) if not tv._startList is None else None, \
                              numpy.array([]) if not tv._endList is None else None, \
                              numpy.array([]), numpy.array([]) if not tv._strandList is None else None, \
                              None, tv.borderHandling, tv.mayHaveOverlaps)
            newTv = newTv[:]
            return newTv
            
        reg = str(tv.genomeAnchor)
#        logMessage(reg + '(' + str(tv._valList) + '): ' + str(self._allVals) + ', ' + str(self._valRegs) +', '+ str(self._prevRegs) + '->')
        if reg not in self._valRegs:
            self._allVals = numpy.concatenate((self._allVals, numpy.sort(numpy.setdiff1d(tv._valList, self._allVals))))
            self._valRegs.add(reg)
            
        if reg in self._prevRegs:
            self._prevRegs = set([])
            self._allVals = self._allVals[1:]
            if len(self._allVals) == 0:
                self._valRegs = set([])
#                logMessage('NoMoreUniqueValsError')
                raise NoMoreUniqueValsError
            
        self._prevRegs.add(reg)
        
        if len(self._allVals) == 0:
            indexes = numpy.zeros(dtype='bool', shape=len(tv._valList))
        else:
            indexes = (tv._valList==self._allVals[0])
        
#        logMessage('-> ' + str(self._allVals) + ', ' + str(self._valRegs) + ', ' + str(self._prevRegs))

        startList = tv._startList[indexes] if not tv._startList is None else None
        endList = tv._endList[indexes] if not tv._endList is None else None
        strandList = tv._strandList[indexes] if not tv._strandList is None else None
        valList = tv._valList[indexes]
        
        newTv = TrackView(tv.genomeAnchor, startList, endList, valList, strandList, None, tv.borderHandling, tv.mayHaveOverlaps)
        newTv = newTv[:]
        return newTv
    
    @classmethod
    def _canHandle(cls, sourceFormat, reqFormat):
        #reqFormat.allowsOverlaps() and 
        isIterateUniqueVals = reqFormat.iterateUniqueVals() and not (sourceFormat.isDense() and sourceFormat.isInterval())
        return isIterateUniqueVals
        
    @classmethod
    def _getTrackFormatExceptionList(cls):
        return ['iterateUniqueVals']
            
    @classmethod
    def getOutputDescription(self, sourceFormatName):
        return "For all categories (converted from '" + sourceFormatName + "')"

class JoinedFormatConverter(FormatConverter):
    _formatConverterClsList=[]
    
    def __init__(self, sourceFormat=None, reqFormat=None):
        FormatConverter.__init__(self, sourceFormat, reqFormat)
        self._formatConverters = []
        for formatConverterCls in self._formatConverterClsList:
            formatConverter = object.__new__(formatConverterCls, sourceFormat, reqFormat)
            formatConverter.__init__(sourceFormat, reqFormat)
            self._formatConverters.append(formatConverter)

    def reset(self):
        for formatConverter in self._formatConverters:
            formatConverter.reset()

    def silence(self):
        for formatConverter in self._formatConverters:
            formatConverter.silence()
        
    def convert(self, tv):
        for formatConverter in self._formatConverters:
            tv = formatConverter.convert(tv)
        return tv
    
    @classmethod
    def _canHandle(self, sourceFormat, reqFormat):
        return all([formatConverterCls._canHandle(sourceFormat, reqFormat) \
                    for formatConverterCls in self._formatConverterClsList])
    
    @classmethod
    def _getTrackFormatExceptionList(cls):
        return reduce(lambda l1,l2:l1+l2, [formatConverterCls._getTrackFormatExceptionList() \
                                           for formatConverterCls in cls._formatConverterClsList])

    @classmethod
    def getOutputDescription(self, sourceFormatName):
        return "Combined format converter (converted from '" + sourceFormatName + "')"

class IterateUniqueValsAndSegmentToStartPointFormatConverter(JoinedFormatConverter):
    _formatConverterClsList=[IterateUniqueValsFormatConverter, SegmentToStartPointFormatConverter]

    def getOutputDescription(self, sourceFormatName):
        return "For all categories, with the upstream end point of every segment (converted from '" + sourceFormatName + "')"
    
class IterateUniqueValsAndSegmentToMidPointFormatConverter(JoinedFormatConverter):
    _formatConverterClsList=[IterateUniqueValsFormatConverter, SegmentToMidPointFormatConverter]

    def getOutputDescription(self, sourceFormatName):
        return "For all categories, with the middle point of every segment (converted from '" + sourceFormatName + "')"

class IterateUniqueValsAndSegmentToEndPointFormatConverter(JoinedFormatConverter):
    _formatConverterClsList=[IterateUniqueValsFormatConverter, SegmentToEndPointFormatConverter]

    def getOutputDescription(self, sourceFormatName):
        return "For all categories, with the downstream end point of every segment (converted from '" + sourceFormatName + "')"

