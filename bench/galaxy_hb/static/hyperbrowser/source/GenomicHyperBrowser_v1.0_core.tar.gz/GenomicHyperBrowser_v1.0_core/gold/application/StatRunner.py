
# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#Untested, but deliberately gold as indirectly well tested and central code
from gold.statistic.MagicStatFactory import MagicStatFactory
from gold.util.CustomExceptions import SplittableStatNotAvailableError
from gold.result.Results import Results
from gold.application.Config import PRINT_PROGRESS, MAX_LOCAL_RESULTS_IN_TABLE, USE_PROFILING, MAX_NUM_USER_BINS
from gold.statistic.ResultsMemoizer import ResultsMemoizer
from gold.util.Profiler import Profiler
from quick.application.UserBinSource import UserBinSource
from gold.origdata.GenomeElementSource import GenomeElementSource
from gold.origdata.GECategoryFilter import GECategoryFilter
from gold.util.CustomExceptions import CentromerError, NoneResultError
from quick.util.GenomeInfo import GenomeInfo
from gold.statistic.AssemblyGapCoverageStat import AssemblyGapCoverageStat
#from quick.statistic.CountPointBothTracksStat import CountPointBothTracksStat
from gold.statistic.Statistic import Statistic
from gold.track.Track import PlainTrack, Track
#from gold.application.LogSetup import logMessage
import time
from quick.application.SignatureDevianceLogging import takes,returns

class StatJob(object):
    GENERAL_RESDICTKEY = 'Result'
    
    #@takes(StatJob, UserBinSource, Track, Track, Statistic)
    def __init__(self, userBinSource, track, track2, statClass, *args, **kwArgs):
        self._userBinSource = userBinSource
        self._track = track
        self._track2 = track2
        self._statClass = statClass
        self._args = args
        self._kwArgs = kwArgs
        
        self._numUserBins = None

    def _initProgress(self, printProgress):
        self._progress = Progress(self.getNumUserBins(), printProgress, description=\
                            '<p><b>Analyzing ' + str(self._track.trackName) + \
                            (' vs ' + str(self._track2.trackName) if self._track2 is not None else '') + ' using statistic: ' + \
                            self._statClass.__name__ + '</b><br><br> Performing local analysis: <br>')
        self._progress.addCount(0)

    def run(self, printProgress=PRINT_PROGRESS):
        MagicStatFactory.resetMemoDict()
            
        results = self._emptyResults()
        if not self._numUserBinsIsValid():
            return results
        
        # To hold stats for user bins in memory until global run is finished (due to memory memoization)
        stats = []
        self._initProgress(printProgress)        
        stats = self._doLocalAnalysis(results, stats)
        self._doGlobalAnalysis(results, stats)        
        self._endProgress()
    
        return results

    def _doLocalAnalysis(self, results, stats):
        for region in self._userBinSource:
            str(region) # fixme: Mysteriously, this fixes a bug where only Chromosome arm 1 was used for analysis, instead of all
            res, stat = self._getSingleResult(region)
            results[region] = res            
            if not self._avoidUbStatMemoization():
                stats.append(stat)
            #Currently, just to ensure that rawdata is not memoized for all userbins..:
            stat.afterComputeCleanup()
            
            self._progress.addCount()
        return stats
            
    def _doGlobalAnalysis(self, results, stats):
        try:
            self._progress.printMessage('<br>Performing global analysis...<br>')
            res,stat = self._getSingleResult(self._userBinSource)
            results.setGlobalResult( res )
        except SplittableStatNotAvailableError:
            results.setGlobalResult( None )
        
    def _getSingleResult(self, region):
        stat = self._statClass(region, self._track, self._track2, *self._args, **self._kwArgs)
        try:
            res = stat.getResult()
            #logMessage('TO EGIL: ' + stat.__class__.__name__ + '\n')
            #if type(res)==dict:
            #    mess = ''
            #    for key in res:
            #        mess += "\n"+stat.__class__.__name__ + '_' + key.replace('-','_').replace(' ','_') + " = ('', '')"
            #    logMessage(mess)
        except (CentromerError, NoneResultError),e:
            res = None
            
        if not isinstance(res, dict):
            res = {} if res is None else {self.GENERAL_RESDICTKEY : res}

        ResultsMemoizer.flushStoredResults()
        return res, stat
    
    def getNumUserBins(self):
        if self._numUserBins is None:
            self._numUserBins = sum(1 for el in self._userBinSource)
        return self._numUserBins

    def _numUserBinsIsValid(self):
        numUserBins = self.getNumUserBins()
        if numUserBins < 1:
            print 'Zero analysis bins specified!'
            return False
        elif numUserBins > MAX_NUM_USER_BINS and not self._avoidUbStatMemoization():
            print 'Maximum number of user bins exceeded - Maximum: ',MAX_NUM_USER_BINS, ', Requested: ',numUserBins
            return False
        else:
            return True
    
    def _emptyResults(self):
        return Results(self._track.trackName, self._track2.trackName \
                        if self._track2 is not None else [], self._statClass.__name__)

    def _endProgress(self):
        self._progress.printMessage('<br>Formatting results...<br>')
        self._progress.printActiveTime()

    def _avoidUbStatMemoization(self):
        #temporary solution.. along with its use later on..:
        return 'DataComparison' in self._statClass.__name__

class AssemblyGapJob(StatJob):
    def __init__(self, userBinSource, genome):
        track = PlainTrack(GenomeInfo.getPropertyTrackName(genome, 'gaps'))
        StatJob.__init__(self, userBinSource, track, None, AssemblyGapCoverageStat)

    def run(self, printProgress=PRINT_PROGRESS):
        res = StatJob.run(self, printProgress)
        ResultsMemoizer.flushStoredResults()
        return res
    
#class CountBothTracksJob(StatJob):
#    def __init__(self, userBinSource, trackName1, trackName2):
#        track1, track2 = Track(trackName1), Track(trackName2)
#        StatJob.__init__(self, userBinSource, track1, track2, CountPointBothTracksStat)


class AnalysisDefJob(StatJob):
    #@takes(AnalysisDefJob, str, list, list, UserBinSource)
    #@returns Results
    def __init__(self, analysisDef, trackName1, trackName2, userBinSource, *args, **kwArgs):
        from gold.description.Analysis import Analysis
    
        #to be removed later.. Just for convenience with development now.. 
        self._analysisDef = analysisDef
        self._trackName1 = trackName1
        self._trackName2 = trackName2
        
        self._analysis = Analysis(analysisDef, userBinSource.genome, trackName1, trackName2)
        
        track, track2 = self._analysis.getTracks()
        StatJob.__init__(self, userBinSource, track, track2, self._analysis.getStat(), *args, **kwArgs)
    
    def run(self, printProgress=PRINT_PROGRESS):
        #Should be there for batch runs.. Should never happen from GUI..
        if self._statClass == None:
            self._handleMissingStat()
            return None

        if USE_PROFILING:
            profiler = Profiler()
            resDict = {}
            profiler.run('resDict[0] = StatJob.run(self, printProgress)', globals(), locals())
            res = resDict[0]
        else:
            res = StatJob.run(self, printProgress)
        res.setAnalysis(self._analysis)
        res.setAnalysisText(str(self._analysis))
        
        ResultsMemoizer.flushStoredResults()
        if USE_PROFILING:
            profiler.printStats()
        
        return res

    def _handleMissingStat(self):
        from gold.application.LogSetup import logMessage, logging
        from gold.description.RunDescription import RunDescription
        import gold.description.Analysis as AnalysisModule
        #AnalysisModule.VERBOSE = True
        msg = 'Started run with invalid statistic... Def: ' + self._analysisDef
                    #+ ', Run description: ' + \
                    #RunDescription.getRevEngBatchLine( self._trackName1, self._trackName2, self._analysisDef, \
                                                      #'Not Available', 'Not Available', self._userBinSource.genome)
        logMessage(msg, level=logging.ERROR)
        raise Exception(msg)
        #res = Results(self._trackName1, self._trackName2, self._analysisDef.split('->')[1])
        #res.addAnalysisDef(self._analysisDef)
        #res.addError(Exception('Invalid statistics selected (Could be beause of an error in statistic. See log.)'))
        #self._analysis.resetValidStat()
        #return res
                
class Progress():
    def __init__(self, totalCount, printProgress, description=None):
        self._totalCount = totalCount
        self._currCount = 0
        self._description = description
        self._startTime = time.time()
        self._printProgress = printProgress
        
    def addCount(self, newCounts = 1):
        if not self._printProgress:
            return
        
        if self._description != None:
                print self._description
                self._description = None
        
        for percentage in range( 100*self._currCount/self._totalCount +1, 100*(self._currCount+newCounts)/self._totalCount +1):    
            print '.',
            if percentage % 10 == 0:
                print percentage,'%<br>'
        
        self._currCount += newCounts

    def printActiveTime(self):
        if not self._printProgress:
            return
        print '<br>Run took %.1f seconds.</p>' % (time.time() - self._startTime)
        
    def printMessage(self, msg):
        if not self._printProgress:
            return
        print msg
