#class PreProcessMetaData(object):
#    def __init__(self, trackInfo):
#        self._firstGeSource = None
#        self._id = None
#        self._origElCount = 0
#        self._clusteredElCount = 0
#        self._trackInfo = trackInfo
#        
#    def update(self, geSourceJob):
#        if self._firstGeSource is None:
#            self._firstGeSource = geSourceJob.geSource
#        else:
#            assert getClassName(geSourceJob.geSource) == getClassName(self._firstGeSource)
#
#        if self._id is None:
#            self._id = geSourceJob.id
#        else:
#            assert geSourceJob.id == self._id
#
#        if geSourceJob.allowOverlaps:
#            self._origElCount += geSourceJob.getNumProcessedElements()
#        else:
#            self._clusteredElCount += geSourceJob.getNumProcessedElements()
#
#    def storeAsTrackInfo(self):
#        geSource = self._firstGeSource
#        format = TrackFormat.createInstanceFromGeSource(geSource)
#        trackInfo.setPreProcessInfo(geSource.getFileSuffix(), format, geSource._VERSION, self._id, self._origElCount, self._clusteredElCount)
#        trackInfo.store()
#
#    def getSomeGeSource(self):
#        assert self._firstGeSource is not None
#        return self._firstGeSource
    
