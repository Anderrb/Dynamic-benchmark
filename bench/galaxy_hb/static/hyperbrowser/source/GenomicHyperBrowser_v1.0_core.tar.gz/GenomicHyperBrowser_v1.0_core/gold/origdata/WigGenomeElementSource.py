# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.origdata.GenomeElementSource import GenomeElementSource, SourceLineGESource
from gold.origdata.GenomeElement import GenomeElement
from gold.util.CustomExceptions import NotImplementedError, InvalidFormatError
from quick.util.GenomeInfo import GenomeInfo
import re
import numpy

class WigGenomeElementSource(GenomeElementSource):
    @staticmethod
    def _parseHeader(headerLine):
        return dict( [ pair.split('=') for pair in re.split('\s+', headerLine.strip())[1:] ] )
        
    def __new__(cls, fn, *args, **kwArgs):
        f = open(fn)
        trackDef = f.readline()
        assert trackDef.startswith('track type=wiggle_0') or trackDef.startswith('track type=bedGraph')

        headerLine = f.readline()
        if headerLine.startswith('fixedStep'):
            header = cls._parseHeader(headerLine)
            return WigFixedGenomeElementSource.__new__(WigFixedGenomeElementSource, header)
        elif headerLine.startswith('variableStep'):
            header = cls._parseHeader(headerLine)
            if header.has_key('span'):
                return WigVariableSegmentsGenomeElementSource.__new__(WigVariableSegmentsGenomeElementSource, header)               
            else: 
                return WigVariablePartitionGenomeElementSource.__new__(WigVariablePartitionGenomeElementSource, header)
        elif len( headerLine.split('\t') ) == 4:
            if '.point.' in fn.lower(): #fn.endswith('.point.wig'):
                return WigPointBedGenomeElementSource.__new__(WigPointBedGenomeElementSource)
            elif '.meansd.' in fn.lower():
                return WigBedMeanSdGenomeElementSource.__new__(WigBedMeanSdGenomeElementSource)
            elif '.mapping.' in fn.lower():
                return WigBedMappingGenomeElementSource.__new__(WigBedMappingGenomeElementSource)
            elif '.targetcontrol.' in fn.lower():
                return WigBedTargetControlGenomeElementSource.__new__(WigBedTargetControlGenomeElementSource)
            else:
                return WigBedGenomeElementSource.__new__(WigBedGenomeElementSource)
        else:
            raise AssertionError() #unsupported format..
        
class WigBedGenomeElementSource(WigGenomeElementSource, SourceLineGESource):
    _VERSION = '1.4'
    _numHeaderLines = 1
    def __new__(cls, *args, **kwArgs):
        return object.__new__(cls)
    
    def _next(self, line):
        cols = line.split('\t')
        
        self._genomeElement.chr = cols[0]        
        self._genomeElement.start = int(cols[1])
        self._parseEnd(int(cols[2]))
        self._parseVal(cols[3])
        
        return self._genomeElement
    
    def _parseEnd(self, end):
        self._genomeElement.end = end

    def _parseVal(self, valStr):
        self._genomeElement.val = numpy.float(self._handleNan(valStr))

class WigBedMeanSdGenomeElementSource(WigBedGenomeElementSource):
    _VERSION = '1.4'
    def _parseVal(self, valStr):
        self._genomeElement.val = [numpy.float(self._handleNan(el)) for el in valStr.split('/')] \
            if valStr != 'None' else [numpy.nan]*2
        assert( len(self._genomeElement.val) == 2 )
        
    def getValDim(self):
        return 2
    
class WigBedMappingGenomeElementSource(WigBedGenomeElementSource):
    _VERSION = '1.1'
    def _parseVal(self, valStr):
        self._genomeElement.val = [numpy.int(el.strip()) for el in valStr.split(',')]
        if len(self._genomeElement.val) != 2:
            raise InvalidFormatError('Unable to parse value column.')
        
    def getValDim(self):
        return 2
            
    def getValDataType(self):
        return 'int32'

class WigBedTargetControlGenomeElementSource(WigBedGenomeElementSource):
    _VERSION = '1.4'
    def _parseVal(self, valStr):
        if self._handleNan(valStr) == 'nan':
            self._genomeElement.val = numpy.nan
        elif valStr == '0':
            self._genomeElement.val = False
        elif valStr == '1':
            self._genomeElement.val = True
        else:
            raise InvalidFormatError('Could not parse value: ' + valStr + ' as target/control.') 
        
    def getValDataType(self):
        return 'bool8'
    
class WigPointBedGenomeElementSource(WigBedGenomeElementSource):
    _VERSION = '1.4'
    def _parseEnd(self, end):
        assert( end == self._genomeElement.start + 1 )


class WigFixedGenomeElementSource(WigGenomeElementSource):
    _numHeaderLines = 2
    def __new__(cls, header, *args, **kwArgs):
        if int(header['step']) == 1:
            ob = WigFixedFunctionGenomeElementSource.__new__(WigFixedFunctionGenomeElementSource)
        else:
            ob = WigFixedPartitionGenomeElementSource.__new__(WigFixedPartitionGenomeElementSource)
        
        ob._firstHeader = header
        ob._parseWigHeader(header)
        return ob
            
    def _parseWigHeader(self, header):
        chr, start, step = [header.get(a) for a in ['chrom','start','step']]

        if None in [chr, start, step] or int(start)<1 or int(step)<1:
            raise InvalidFormatError('Wig-type fixedStep not correctly specified.')

        if int(start) > int(step):
            raise NotImplementedError("Offset in wig-file is larger than the step size. "+\
                                      "This is not yet supported..")
        if header.get('span') and int(header.get('span')) != int(step):
            raise NotImplementedError('FixedStep with span size different from step size '+\
                                      'is not yet supported..')
        
        self._chr = chr
        self._start = int(start)
        self._step = int(step)

class WigFixedFunctionGenomeElementSource(WigFixedGenomeElementSource):
    _VERSION = '1.0'
    def __new__(cls, *args, **kwArgs):
        return object.__new__(cls)
    
    def __init__(self, *args, **kwArgs):
        GenomeElementSource.__init__(self, *args, **kwArgs)
        self._genomeElement.chr = self._chr
    
    def _iter(self):
        return self

    def _next(self, line):
        cols = line.split(' ')
        if len(cols)>1 and self._handleNan(cols[1]) == 'nan':
            self._genomeElement.val=numpy.nan
        else:
            self._genomeElement.val=numpy.float(self._handleNan(cols[0]))
        
        return self._genomeElement
    
class WigFixedPartitionGenomeElementSource(WigFixedGenomeElementSource):
    _VERSION = '1.4'
    def __new__(cls, *args, **kwArgs):
        return object.__new__(cls)

    def _iter(self, newHeaderLine=None):
        self._appendNoMore = False

        if newHeaderLine is None:
            self._parseWigHeader( self._firstHeader )
            self._chrList = [self._chr]
            self._elementList = []
        else:
            self._parseWigHeader( self._parseHeader(newHeaderLine) )
            self._chrList.append(self._chr)

        assert(self._chr not in self._chrList[0:-1])

        for end in [0] + ([self._start-1] if self._start-1 != 0 else []):
            self._elementList.append( (self._chr, end, numpy.nan) )    
        return self
    
    def _next(self, line):
        if line.startswith('fixedStep'):
            assert(self._appendNoMore == False)
            self._appendChrEnding()          
            self._iter(newHeaderLine=line)
            return self.next()
        elif line == '':        
            if not self._appendNoMore:
                self._appendChrEnding()
                self._appendNoMore = True
        else:
            assert(self._appendNoMore == False)
            self._elementList.append( (self._chr, \
                                       self._elementList[-1][1] + self._step, \
                                       numpy.float(self._handleNan(line.strip()))) )
            
        self._genomeElement.chr = self._elementList[0][0]
        self._genomeElement.end = self._elementList[0][1]
        self._genomeElement.val = self._elementList[0][2]
        self._elementList.pop(0)
        
        return self._genomeElement
    
    def _appendChrEnding(self):
        self._elementList.append( (self._chr, \
                                  GenomeInfo.getChrLen(self._genome, self._chr), \
                                  numpy.nan) )

    def _anyPendingElements(self):
        return len(self._elementList) != 0

class WigVariablePartitionGenomeElementSource(WigGenomeElementSource):
    _VERSION = '1.4'
    _numHeaderLines = 2

    def __new__(cls, header, *args, **kwArgs):
        ob = object.__new__(cls)
        ob._firstHeader = header
        ob._parseWigHeader(header)
        return ob
    
    def __getnewargs__(self):
        return (self._firstHeader,)

    #def __new__(cls, *args, **kwArgs):
    #    return object.__new__(cls)
    #
    #def __init__(self, headerLine, *args, **kwArgs):
    #    header = self._parseHeader(headerLine)
    #    self._firstHeader = header
    #    self._parseWigHeader(header)
    #    GenomeElementSource.__init__(*args, **kwArgs)
        
        
    def _parseWigHeader(self, header):
        chr, span = [header.get(a) for a in ['chrom','span']]

        if chr is None:
            raise InvalidFormatError('Wig-type variableStep not correctly specified.')

        if not span is None:
            raise InvalidFormatError('VariableStep with span must use span on all header lines..')

        self._chr = chr
        self._checkNextLine = True
        
    def _iter(self, newHeaderLine=None):
        if newHeaderLine is None:
            self._parseWigHeader( self._firstHeader )
            self._chrList = [self._chr]
            self._elementList = []
            self._appendNoMore = False
        else:
            self._parseWigHeader( self._parseHeader(newHeaderLine) )
            self._chrList.append(self._chr)
            
        self._lastVal = numpy.nan
        
        assert(self._chr not in self._chrList[0:-1])

        return self
    
    def _next(self, line):
        if line.startswith('variableStep'):
            assert(self._appendNoMore == False)
            self._appendChrEnding()   
            self._iter(newHeaderLine=line)
            return self.next()
        elif line == '':
            if not self._appendNoMore:
                self._appendChrEnding()
                self._appendNoMore = True
        else:
            cols = line.split('\t')
            assert self._appendNoMore == False
            if self._checkNextLine:
                assert int(cols[0]) == 1, \
                    'Error in Wig-file: VariableStep format must start with 1 in ' +\
                    'the first line after chromosone specification.'
                self._checkNextLine = False
            self._elementList.append( (self._chr, \
                                       int(cols[0])-1, \
                                       self._lastVal ) )
            self._lastVal = numpy.float( self._handleNan(cols[1]) )
            
        self._genomeElement.chr = self._elementList[0][0]
        self._genomeElement.end = self._elementList[0][1]
        self._genomeElement.val = self._elementList[0][2]
        self._elementList.pop(0)
        
        return self._genomeElement
    
    def _appendChrEnding(self):
        self._elementList.append( (self._chr, \
                                  GenomeInfo.getChrLen(self._genome, self._chr), \
                                  self._lastVal) )

    def _anyPendingElements(self):
        return len(self._elementList) != 0

class WigVariableSegmentsGenomeElementSource(WigGenomeElementSource):
    _VERSION = '1.4'
    _numHeaderLines = 2
    def __new__(cls, header, *args, **kwArgs):
        ob = object.__new__(cls)
        ob._firstHeader = header
        ob._parseWigHeader(header)
        return ob

    def __getnewargs__(self):
        return (self._firstHeader,)
    
    def _parseWigHeader(self, header):
        chr, span = [header.get(a) for a in ['chrom','span']]

        if chr is None:
            raise InvalidFormatError('Wig-type variableStep not correctly specified.')

        if span is None:
            raise InvalidFormatError('VariableStep with span must use span on all header lines..')
        
        self._chr = chr
        self._span = int(span)
  
    def _iter(self, newHeaderLine=None):
        if newHeaderLine is None:
            self._parseWigHeader( self._firstHeader )
            self._chrList = [self._chr]
        else:
            self._parseWigHeader( self._parseHeader(newHeaderLine) )
            self._chrList.append(self._chr)
            
        assert(self._chr not in self._chrList[0:-1])

        return self
    
    def _next(self, line):
        if line.startswith('variableStep'):
            self._iter(newHeaderLine=line)
            return self.next()
        else:
            cols = line.split('\t')
            self._genomeElement.chr = self._chr
            self._genomeElement.start = int(cols[0])-1
            self._genomeElement.end = self._genomeElement.start + self._span
            self._genomeElement.val = numpy.float( self._handleNan(cols[1]) )
            return self._genomeElement
        