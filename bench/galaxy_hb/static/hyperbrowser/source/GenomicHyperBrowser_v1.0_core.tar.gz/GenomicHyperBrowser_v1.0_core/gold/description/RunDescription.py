# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.description.Analysis import Analysis
from gold.application.LogSetup import logException,logging, logMessage
from gold.application.Config import VERBOSE, STATIC_REL_PATH, URL_PREFIX
from gold.result.HtmlCore import HtmlCore
from gold.description.TrackInfo import TrackInfo
from gold.util.CommonFunctions import prettyPrintTrackName, getClassName
from gold.description.Analysis import Analysis
#from gold.description.StatDescriptionList import getDescription
from quick.application.ExternalTrackManager import ExternalTrackManager
from quick.util.CommonFunctions import createHyperBrowserURL
import os
import functools
import re
#from urllib import quote
from gold.application.LogSetup import logMessage, logging

class RunDescription(object):
    @staticmethod
    def getRunDescription(trackName1, trackName2, analysisDef, ubSource, revEngBatchLine):
        genome = ubSource.genome
        core = HtmlCore()

        analysis = Analysis(analysisDef, genome, trackName1, trackName2)
        
        first = True
        for tn,label in zip([trackName1,trackName2], ['TRACK 1','TRACK 2']):
            if tn in [None, []]:
                continue
            
            if not first:
                core.divider()

            core.header(label)
            trackInfo = TrackInfo(genome, tn)
            trackText = ''
            if ExternalTrackManager.isHistoryTrack(tn):
                assert len(tn)>=4
                core.descriptionLine('Name', tn[3] + ' (from history)' + os.linesep)
            else:
                core.descriptionLine('Name', ':'.join(tn) + os.linesep)
            core.append(trackInfo.mainInfo(printEmpty=False))

            first = False
        
        core.divider()
        core.header('ANALYSIS')
        core.paragraph( ''.join(str(analysis).split(':')[1:]) )

        core.divider()
        core.header('TRACK TYPE')
        for label, choice in analysis.getFormatConverterChoicesAsText().items():
            core.descriptionLine(label, choice)

        first = True
        for label,choice in analysis.getInterfaceChoicesAsText().items():
            if first:
                core.divider()
                core.header('OPTIONS')    
            core.descriptionLine(label, choice)
            first = False
            
        h0 = analysis.getH0()
        if h0 is not None:
            core.divider()
            core.header('NULL HYPOTHESIS')
            core.paragraph(h0)
            
        h1 = analysis.getH1()
        if h1 is not None:
            core.divider()
            core.header('ALTERNATIVE HYPOTHESIS')
            core.paragraph(h1)
            
        core.divider()
        core.header('ANALYSIS REGIONS')
        if hasattr(ubSource, 'description'):
            core.paragraph(ubSource.description)
            
        core.divider()
        core.header('SOLUTION')
        #statClassName = analysis.getStat().__name__
        #core.paragraph(getDescription(statClassName))

        statClass = analysis.getStat()        
        #One alternative is to put getDescription in MagicStatFactory-hierarchy as class-method, and get real class behind partial-object.
        #if isinstance(statClass, functools.partial):
            #statClass = statClass.func
        #core.paragraph( statClass.getDescription() )

        #Chosen alternative is to Instantiate an object, which will automatically give object of real class..
        #and then use the following two lines, which will get class in Statistic-hierarchy instead of MagicStatFactory-hierarchy ..
        try:
            reg = ubSource.__iter__().next()
        except:
            core.paragraph('Solution not relevant, as there are no specified analysis regions..')
        else:
            track1, track2 = analysis.getTracks()
            if statClass is None:
                core.paragraph('Solution not available, due to currently invalid analysis')
                logMessage('Solution not available, with params: ' + str([trackName1, trackName2, analysisDef]), level=logging.WARN )
            else:
                statObj = statClass(reg,track1, track2)
                statDescr = statObj.getDescription()
                replPat = '<a href=' + os.sep.join([STATIC_REL_PATH,'notes','stats','']) + r'\1>note</a>'
                statDescr = re.sub('<note>(.*)</note>', replPat, statDescr)

                core.paragraph( statDescr )
        
        core.divider()
        core.header('URL FOR TRACK AUTOSELECTION')
        #urlOptions = '&'.join(['track1=' + quote(':'.join(trackName1)), 'track2=' + quote(':'.join(trackName2))])
        #core.paragraph(URL_PREFIX + '/hyper?' + urlOptions)
        core.paragraph( createHyperBrowserURL(genome, trackName1, trackName2) )
        
        if revEngBatchLine not in [None, '']:
            core.divider()
            core.header('CORRESPONDING BATCH-RUN LINE')
            #if any(ExternalTrackManager.isRedirectOrExternalTrack(tn) for tn in [trackName1, trackName2]):
                #core.paragraph('Batch-run line not available with tracks from history')
            #else:
            core.paragraph(revEngBatchLine)
        
#        description = \
#'''
#Run descriptions will be introduced in the next version of HB. <br>
#Below is an example run description, which is a static text unconnected to your choices. The purpose is to get feedback from you on what this should look like:<br>
#Track1 (refseg:genes): Unmarked points (converted from unmarked segments, taking midpoints)<br>
#Track2 (DNA melting:meltmap): Function<br>
#Bins: Chr1, divided into bins of 10 megabases<br>
#Question: Are track1-points occurring with different frequency inside track2-segment than outside?<br>
#Analysis:<br>
#The main result is a p-value resulting from a statistical test connected to the question.<br>
#The null-hypothesis assumes that the track1-points are randomly distributed according to a poisson-distribution, with the same number of points as in the original data. Track2-segment are assumed fixed as they are in the original data. This can be answered by a binomial test. The alternative hypothesis is then that the count of points inside segments has resulted from a different distribution of points, where the points are then either distributed more or less inside segments versus outside. See the note on this question in the user guide for further info.<br>
#'''
        return str(core)
    
    @staticmethod
    def getRevEngBatchLine(trackName1, trackName2, analysisDef, regSpec, binSpec, genome):
        #analysisDef is assumed to be unquoted
        
        #if this is to work, must check explicitly against special keywords  in regSpec (or check that regSpec is a valid region that is to have region..)...
        #if not genome in regSpec:
        #    regSpec = genome+':'+regSpec
        try:
            if VERBOSE:
                logMessage('getting RevEngBatchLine:')
            analysis = Analysis(analysisDef, genome, trackName1, trackName2)
            stat = analysis.getStat()
            if stat is None:
                return 'No corr batch line, as no valid statistic was found..'
            statClassName = stat.__name__
            #fixme: Add space, but this is not checked in batchrunner...
            params = ','.join(['='.join(choicePair) for choicePair in analysis.getChoices().items()])
            statText = statClassName + '(' + params + ')'
            return ' '.join([regSpec, binSpec, \
                             (':'.join(trackName1)).replace(' ','_'),\
                             (':'.join(trackName2)).replace(' ','_') if trackName2 is not None else 'None',\
                             statText])
        except Exception,e:
            logException(e,logging.WARNING,'Could not generate corresponding batch line: ')
            if VERBOSE:
                logMessage('analysisDef, genome, trackName1, trackName2: \n' +
                           str([analysisDef, genome, trackName1, trackName2]) )
            return 'Warning: Could not generate corresponding batch line.' 
