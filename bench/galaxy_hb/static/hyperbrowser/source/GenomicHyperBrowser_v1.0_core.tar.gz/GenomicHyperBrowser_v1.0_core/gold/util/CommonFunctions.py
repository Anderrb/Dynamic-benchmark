# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import os
from gold.application.Config import PROCESSED_DATA_PATH, DEFAULT_GENOME, COMP_BIN_SIZE, \
    ORIG_DATA_PATH, OUTPUT_PRECISION, MEMOIZED_DATA_PATH
from gold.track.GenomeRegion import GenomeRegion
from gold.util.CustomExceptions import InvalidFormatError
from quick.util.GenomeInfo import GenomeInfo
import re
from third_party.decorator import decorator
import traceback
import numpy
from quick.application.SignatureDevianceLogging import takes,returns

def createDirPath(trackName, genome, chr, allowOverlaps=False, basePath=PROCESSED_DATA_PATH):
    """
    >>> createDirPath(['trackname'],'genome','chr1')
    '/100000/noOverlaps/genome/trackname/chr1'
    """
    if len(trackName)>0 and trackName[0] == 'redirect':
        genome = trackName[1]
        chr = trackName[2]
        #trackName[3] is description
        trackName = trackName[4:]
    return os.sep.join( [basePath, str(COMP_BIN_SIZE), ('withOverlaps' if allowOverlaps else 'noOverlaps'), genome] +\
        list(trackName) + ([chr] if chr is not None else []) )

#def createMemoPath(trackName, genome, chr, statName):
#    return os.sep.join( [MEMOIZED_DATA_PATH, statName, str(COMP_BIN_SIZE), genome]+list(trackName)+[chr] )
def createMemoPath(region, statId, configHash, track1Hash, track2Hash):
    chr = region.chr
    genome = region.genome
    return os.sep.join( [MEMOIZED_DATA_PATH, str(len(region)), statId, genome, str(track1Hash)] + \
                        ([str(track2Hash)] if track2Hash is not None else []) + \
                        [str(configHash), chr] ).replace('-','_') #replace('-','_') because hashes can be minus, and minus sign makes problems with file handling

def isRedirectTrackName(tn):
    return (tn is not None and len(tn)>0 and tn[0]=='redirect')

def constructRedirectTrackName(trackName, genome, chr, description):
    return [ 'redirect', genome, chr, description ] + trackName

@takes(str,(list,tuple),str)#maybe last could be NoneType?!
def createOrigPath(genome, trackName, fn):
    #print 'genome:',genome
    #print 'trackName:',trackName
    return os.sep.join([ORIG_DATA_PATH, genome] + trackName + ([fn] if fn is not None else []))

def getOrigFn(genome, trackName, suffix):
    from gold.application.LogSetup import logMessage, logging
    path = createOrigPath(genome, trackName,'')
    if not os.path.exists(path):
        logMessage('getOrigFn - Path does not exist: ' + path, logging.WARNING)
        return None
    
    fns = [x for x in os.listdir(path) if x.endswith(suffix) and not x[0] in ['.','_']]
    if len(fns) != 1:
        logMessage('getOrigFn - Cant decide among zero or several fns. Path: %s, and fn-list: %s' % (path, fns), logging.WARNING)
        return None
    
    return path + fns[0]

def parseDirPath(path):
    'Returns [genome, trackName, chr] from directory path'
    path = path[len(PROCESSED_DATA_PATH + os.sep):]# + str(COMP_BIN_SIZE)):]
    while path[0] == os.sep:
        path = path[1:]
    path.replace(os.sep*2, os.sep)
    el = path.split(os.sep)
    return el[2], tuple(el[3:-1]), el[-1]

def extractTrackNameFromOrigPath(path):
    excludeEl = None if os.path.isdir(path) else -1
    path = path[len(ORIG_DATA_PATH):]
    path = path.replace('//','/')
    if path[0]=='/':
        path = path[1:]
    if path[-1]=='/':
        path = path[:-1]
    return path.split(os.sep)[1:excludeEl]
    
def getStrandFromString(str):
    if str == '+':
        return True
    elif str == '-':
        return False
    elif str == '' or str == '.':
        return None
    else:
        raise InvalidFormatError("Strand must be either '+' or '-'")
    
def getStringFromStrand(strand):
    assert(strand != None)
    return '+' if strand else '-'

def parseRegSpec(regSpec, genome = None):
    regParts = regSpec.strip().split(':')
    if (regParts[0]=='*' or regParts[0].startswith('chr')):
        if genome == None:
            genome = DEFAULT_GENOME
    else:
        
        assert genome is None or genome == regParts[0], \
            "Region specification does not start with one of '*', 'chr' or correct genome name. Region specification: %s. Genome: %s" % (regSpec, genome)
        genome = regParts[0]        
        regParts = regParts[1:]
    
    if regParts[0] == '*':
        assert(len(regParts)==1), \
        "Region specification starts with '*' but continues with ':'. Region specification: %s " % regSpec
        region = GenomeRegion(genome)
    else:
        assert(regParts[0].startswith('chr')), \
            "Region specification does not start with chromosome specification. Region specification: %s " % regSpec         
        chr = regParts[0]
        try:
            chrLen = GenomeInfo.getChrLen(genome, chr)
        except Exception, e:
            raise InvalidFormatError("Chromosome '%s' does not exist for genome '%s'" % (chr, genome))
            
        if len(regParts)>1:
            posParts = regParts[1]
            assert('-' in posParts), \
                "Position specification does not include character '-'. Region specification: %s " % regSpec
            rawStart, rawEnd = posParts.split('-')
            
            start = int(rawStart.replace('k','001').replace('m','000001'))
            end = int(rawEnd.replace('k','000').replace('m','000000')) if rawEnd != '' else chrLen
            assert start >= 1, \
                "Start position is not positive. Region specification: %s " % regSpec
            assert end >= start, \
                "End position is not larger than start position. Region specification: %s " % regSpec
            assert end <= chrLen, \
                "End position is larger than chromosome size. Genome: %s. Chromosome size: %s. Region specification: %s" % (genome, chrLen, regSpec)
            #-1 for conversion from 1-indexing to 0-indexing end-exclusive
            start-=1
            
        else:
            start,end = 0, chrLen
        region = GenomeRegion(genome, chr, start, end)
    return region

def parseTrackNameSpec(trackNameSpec):
    return trackNameSpec.split(':')
    genes (RefSeq-release7-unique)
    
def prettyPrintTrackName(trackName, shortVersion=False):
    if len(trackName)<2:
        return ''
    elif trackName[0] in ['galaxy','redirect']:
        return "'" + re.sub('[0-9]+ - ', '', trackName[3]) + "'"
    elif trackName[0] in ['external']:
        return "'" + re.sub('[0-9]+ - ', '', trackName[4]) + "'"
    else:
        if trackName[-1]=='':
            return "'" + trackName[-2] + "'"
        return "'" + trackName[-1] + (' (' + trackName[-2] + ')' if not shortVersion else '') + "'"
        #return "'" + trackName[1] + (' (' + '-'.join(trackName[2:]) + ')' if len(trackName) > 2 else '') + "'"
        #return trackName[1] + (' (' + '-'.join(trackName[2:]) + ')' if len(trackName) > 2 else '')
    
def insertTrackNames(text, trackName1, trackName2 = None, shortVersion=False):
    PREFIX = '(the points of |points of |point of |the segments of |segments of |segment of |the function of |function of )?'
    POSTFIX = '([- ]?segments?|[- ]?points?|[- ]?function)?'
    newText = re.sub(PREFIX + '[tT](rack)? ?1' +  POSTFIX, prettyPrintTrackName(trackName1, shortVersion), text)
    if trackName2 != None:
        newText = re.sub(PREFIX + '[tT](rack)? ?2' + POSTFIX, prettyPrintTrackName(trackName2, shortVersion), newText)
    return newText

def smartSum(li):
    liWithoutNone = [el for el in li if el!=None]
    
    if len(liWithoutNone) == 0:
        return None
    else:
        return sum(liWithoutNone)

def isIter(obj):
    return hasattr(obj, '__iter__')

def getClassName(obj):
    return obj.__class__.__name__

def strWithPrecision(val):
    return ('%#.' + str(OUTPUT_PRECISION) + 'g') % val \
        if type(val) in [float, numpy.float32, numpy.float64, numpy.float128] else str(val)

def strWithDecimals(val, numDecimals):
    return ('%.' + str(numDecimals) + 'f') % val \
        if type(val) in [float, numpy.float32, numpy.float64, numpy.float128] else str(val)

def smartStrLower(obj):    
    return str.lower(str(obj))

def splitOnWhitespaceWhileKeepingQuotes(msg):
    return re.split('\s+(?=(?:[^"]*"[^"]*")*[^"]*$)', msg.strip())

def parseShortenedSizeSpec(spec):
    spec = spec.strip()
    if spec[-1].lower() == 'k':
        size = int(spec[0:-1]) * 1000
    elif spec[-1].lower() == 'm':
        size = int(spec[0:-1]) * 1000000
    else:
        size = int(spec)
    return size

def generateStandardizedBpSizeText(size):
    if size == 0:
        return '0 bp'
    elif size % 10**9 == 0:
        return str(size/10**9) + ' Gb'
    elif size % 10**6 == 0:
        return str(size/10**6) + ' Mb'
    elif size % 10**3 == 0:
        return str(size/10**3) + ' kb'
    else:
        return str(size) + ' bp'
    
def repackageException(fromException, toException):
    def _repackageException(func, *args, **kwArgs):
        try:        
            return func(*args, **kwArgs)
        except fromException,e:
            raise toException('Repackaged exception.., original was: ' + getClassName(e) + ' - '+str(e) + ' - ' + traceback.format_exc())
    return decorator(_repackageException)
#Typical use, for instance
    #from gold.util.CommonFunctions import repackageException
    #from gold.util.CustomExceptions import ShouldNotOccurError
    #@repackageException(Exception, ShouldNotOccurError)

def reverseDict(mapping):
    vals = mapping.values()
    assert len(set(vals)) == len(vals) #Ensure all values are unique
    return dict((v,k) for k, v in mapping.iteritems())
