# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import os
import sys
import functools
import re
import urllib
from quick.application.LocalOSConfig import STATIC_WEB_PATH, GALAXY_BASE_DIR, URL_PREFIX
from third_party.decorator import decorator

def ensurePathExists(fn):
    "Assumes that fn consists of a basepath (folder) and a filename, and ensures that the folder exists."
    path = os.path.split(fn)[0]
    if not os.path.exists(path):
        #oldMask = os.umask(0002)
        os.makedirs(path)
        #os.umask(oldMask)
        
def reloadModules():
    for module in [val for key,val in sys.modules.iteritems() \
                   if key.startswith('gold') or key.startswith('quick') or key.startswith('test')]:
        try:
            reload(module)
        except:
            print module
            
def wrapClass(origClass, keywords={}):
    for key in keywords.keys():
        if re.match('^[0-9]+$',keywords[key]) is not None:
            keywords[key] = int(keywords[key])
        elif re.match('^[0-9]?[.][0-9]?$',keywords[key]) is not None and keywords[key] != '.':
            keywords[key] = float(keywords[key])
           
    args = []
    wrapped = functools.partial(origClass, *args, **keywords)
    functools.update_wrapper(wrapped, origClass)
    return wrapped

def extractIdFromGalaxyFn(fn):
    pathParts = fn.split(os.sep)
    assert(len(pathParts) >= 2)
    
    id1 = pathParts[-2]
    id2 = re.sub('[^0-9]', '', pathParts[-1])
    
    assert(id1.isdigit())
    assert(id2.isdigit())
    return [id1, id2]

def getUniqueRunSpecificId(id=[]):
    return ['run_specific'] + id

def getUniqueWebPath(id=[]):
    return os.sep.join([STATIC_WEB_PATH] + getUniqueRunSpecificId(id))
 
def getLoadToGalaxyHistoryURL(fn):
#    return GALAXY_URL + '/tool_runner?tool_id=file_import&dbkey=hg18&runtool_btn=yes&input=' + fn
    return URL_PREFIX + '/tool_runner?tool_id=file_import&dbkey=hg18&runtool_btn=yes&input=' + fn

def getRelativeUrlFromWebPath(webPath):
    return URL_PREFIX + webPath[len(GALAXY_BASE_DIR):]

def isFlatList(list):
    for l in list:
        if type(l) == type([]):
            return False
    return True    
    
def flattenList(list):
    "recursively flattens a nested list (does not handle dicts and sets..)"
    if isFlatList(list):
        return list
    else:
        return flattenList( reduce(lambda x,y: x+y, list ) )
    
R_ALREADY_SILENCED = False
def silenceRWarnings():
    global R_ALREADY_SILENCED
    if not R_ALREADY_SILENCED:
        from gold.application.RSetup import r
        r('sink(file("/dev/null", open="wt"), type="message")')
        #print 'silencing R warnings..'
        R_ALREADY_SILENCED = True

def createHyperBrowserURL(genome, trackName1, trackName2=None, demoID=None, analcat=None, analysis=None, \
                          configDict=None, trackIntensity=None, method=None, region=None, \
                          binsize=None, chrs=None, chrArms=None, chrBands=None, genes=None): 
    urlParams = []
    urlParams.append( ('dbkey', genome) )
    urlParams.append( ('track1', ':'.join(trackName1)) )
    if trackName2:
        urlParams.append( ('track2', ':'.join(trackName2)) )
    if demoID:
        urlParams.append( ('demoID', demoID) )
    if analcat:
        urlParams.append( ('analcat', analcat) )
    if analysis:
        urlParams.append( ('analysis', analysis) )
    if configDict:
        for key, value in configDict.iteritems():
            urlParams.append( ('config_%s' % key, value) )
    if trackIntensity:
        urlParams.append( ('trackIntensity', trackIntensity) )
    if method:
        urlParams.append( ('method', method) )
    if region:
        urlParams.append( ('region', region) )
    if binsize:
        urlParams.append( ('binsize', binsize) )
    if chrs:
        urlParams.append( ('__chrs__', chrs) )
    if chrArms:
        urlParams.append( ('__chrArms__', chrArms) )
    if chrBands:
        urlParams.append( ('__chrBands__', chrBands) )
    if genes:
        urlParams.append( ('genes', genes) )
    
    return URL_PREFIX + '/hyper?' + '&'.join([key + '=' + urllib.quote(value) for key,value in urlParams])
    
@decorator
def obsoleteHbFunction(func, *args, **kwArgs):
    print 'Warning, this function is going to be phased out of the HB codebase..'
    return func(*args, **kwArgs)