# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from quick.postprocess.Plotter import Plotter
from quick.postprocess.XBinnerPP import XBinnerPP
from quick.postprocess.YBinnerPP import YBinnerPP
from numpy import *


class Plotter3D:
    
    
    def __init__(self, data, outputFileName, xBinSize=100000, yBinSize=0.5):
        self._data = data
        self._outputFileName = outputFileName
        self._xBinSize = xBinSize
        self._yBinSize = yBinSize


    def buildPlot(self):
        coll = XBinnerPP(self._data, self._xBinSize) 
        collY = YBinnerPP(coll, self._yBinSize) 
        minY = min([z for x,y in collY for z in y])
        maxY = max([z for x,y in collY for z in y])
        minX = min([x for x,y in collY])
        maxX = max([x for x,y in collY])
        noy = (maxY-minY)/self._xBinSize + 1
        nox = (maxX-minX)/self._yBinSize + 1
        res = [(x,z) for x,y in collY for z in y ]
        res2 = [x for x,y in collY]
        r = [[0 for i in range(noy)] for j in range(len(res2))]
        for x,y in res:
            r[int(x/self._yBinSize + nox-1)][int(y/self._xBinSize + noy-1)] += 1
        
        results = array(r)
        print results
        return results




