# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#should be moved to tested, with tests developed
#binLen of -1 gives whole chromosomes as bins
from quick.util.GenomeInfo import GenomeInfo 
from gold.track.GenomeRegion import GenomeRegion

class AutoBinner:
    def __init__(self, region, binLen):
        self.genome = region.genome
        
        if region.chr == None:
            assert( (not region.start) and (not region.end) )
            self.chromosomes = GenomeInfo.getChrList(self.genome)
            
        else:
            self.chromosomes = [region.chr]
        if not region.start:
            self.start = 0
        else:
            self.start = region.start
        
        self.end = region.end
        self.binLen = binLen

    def __iter__(self):
        return self.nextBin()
    
    def nextBin(self):
        start = self.start
        for chr in self.chromosomes:
            chrLen = GenomeInfo.getChrLen(self.genome, chr)
            if self.end == None:
                chrEnd = chrLen
            else:
                chrEnd = min(self.end, chrLen)
            #chrLen = 3100000
            
            while (start < chrEnd):
                if self.binLen != None:
                    end = min(start+self.binLen, chrEnd)
                else:
                    end = chrEnd
                #print 'YIELDING: ',start, end, chrEnd
                yield GenomeRegion(self.genome, chr, start, end)
                if self.binLen != None:
                    start += self.binLen
                else:
                    start = chrLen

            #in case of more chromosomes, reset start:
            start = 0

    def __len__(self):
        return sum(1 for bin in self)        