from quick.application.LocalOSConfig import GALAXY_WEB_SERVER_PORT, GALAXY_WEB_SERVER_THREADPOOL_WORKERS, \
     GALAXY_ADDITIONAL_WEB_SERVER_COUNT

def CreateWebServerCfgText():
    txt = ''
    for i in range(int(GALAXY_ADDITIONAL_WEB_SERVER_COUNT)):
        txt += '''
[server:web%d]
use = egg:Paste#http
port = %d
host = 0.0.0.0
use_threadpool = True
threadpool_workers = %d
''' % (i + 1, int(GALAXY_WEB_SERVER_PORT) + i + 1, int(GALAXY_WEB_SERVER_THREADPOOL_WORKERS))
    return txt
