from gold.application.Config import STATIC_WEB_PATH, STATIC_REL_PATH
from quick.util.CommonFunctions import ensurePathExists, getUniqueRunSpecificId
from gold.result.HtmlCore import HtmlCore
import os
from quick.application.SignatureDevianceLogging import takes,returns

class StaticFile(object):
    @takes('StaticFile',list)
    def __init__(self, id):
        self._id = id
        
    def getDiskPath(self, ensurePath=False):
        fn = os.sep.join( [STATIC_WEB_PATH] + self._id)
        if ensurePath:
            ensurePathExists(fn)
        return fn
    
    def getFile(self,mode='w'):
        fn = self.getDiskPath(True)
        return open(fn,mode)
    
    def writeTextToFile(self, text, mode='w'):
        f = self.getFile(mode)
        f.write(text)
        f.close()
    
    def getURL(self):
        return os.sep.join( [STATIC_REL_PATH] + self._id)
    
    def getLink(self, linkText):
        return str(HtmlCore().link(linkText, self.getURL()))
        #return '<a href=%s>%s</a>' % (self.getURL(), linkText)
    
    def openRFigure(self, h=600, w=800):
        from gold.application.RSetup import r
        r.png(filename=self.getDiskPath(True), height=h, width=w, units='px', pointsize=12, res=72)

    def closeRFigure(self):
        from gold.application.RSetup import r
        r('dev.off()')

    def getId(self):
        return self._id
    
    def getExternalTrackName(self):
        from quick.application.ExternalTrackManager import ExternalTrackManager
        return ExternalTrackManager.createStdTrackName(self._id[:-1], self._id[-1] )
        
class StaticImage(StaticFile):
    def __init__(self, id):
        StaticFile.__init__(self, ['images']+id)

class RunSpecificFile(StaticFile):
    #def __init__(self, id, fileEnding, runId, straightOnStaticPath=False): #straightOnStaticPath is temporary solution to be backwards compatible with filenames of presenters..
    #    if straightOnStaticPath:
    #        StaticFile.__init__(self, runId+id, fileEnding)        
    #    else:
    #        StaticFile.__init__(self, ['run_specific']+runId+id, fileEnding)        
    def __init__(self, id, runId):
        StaticFile.__init__(self, getUniqueRunSpecificId(runId + id))        


from quick.util.CommonFunctions import extractIdFromGalaxyFn
class GalaxyRunSpecificFile(RunSpecificFile):
    #def __init__(self, id, fileEnding, galaxyFn, straightOnStaticPath=False):
    #    galaxyId = extractIdFromGalaxyFn(galaxyFn)
    #    RunSpecificFile.__init__(self, id, fileEnding, galaxyId, straightOnStaticPath)
    def __init__(self, id, galaxyFn):
        galaxyId = extractIdFromGalaxyFn(galaxyFn)
        RunSpecificFile.__init__(self, id, galaxyId)
