# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from copy import copy
import os
import sys
from zipfile import ZipFile
from itertools import chain
from gold.description.TrackInfo import TrackInfo
from gold.track.GenomeRegion import GenomeRegion
from gold.track.Track import Track
from gold.track.TrackFormat import TrackFormatReq
from gold.util.CommonFunctions import getStringFromStrand, parseRegSpec, parseTrackNameSpec
from gold.util.CustomExceptions import NotSupportedError
from quick.util.CommonFunctions import ensurePathExists
from quick.util.GenomeInfo import GenomeInfo

class TrackViewLineComposer(object):
    def __new__(cls, trackView, name, region):
        if trackView.trackFormat.reprIsDense():
            if isinstance(trackView.__iter__().next().val(), str):
                return TrackViewFastaLineComposer(trackView, name, region)
            else:
                return TrackViewWigFixedLineComposer(trackView, name, region)
        #elif trackView.trackFormat.isMarked() is False:
        #    return TrackViewBedLineComposer(trackView, name, region)
        #elif trackView.trackFormat.hasStrand() or trackView.trackFormat.isMarked('category'):
        elif not trackView.trackFormat.isMarked() or trackView.trackFormat.isMarked('category') or trackView.trackFormat.isMarked('microarray'):
            return TrackViewBedLineComposer(trackView, name, region)
        else:
            return TrackViewWigBedLineComposer(trackView, name, region)
            #raise NotSupportedError()

    def __init__(self, trackView, name, region):
        self._trackView = trackView
        self._name = name
        self._region = region

    def __iter__(self):
        self._trackViewIter = self._trackView.__iter__()
        return copy(self)

    def next(self):
        return self._compose( self._trackViewIter.next() )
    
    def __len__(self):
        return self._trackView.getNumElements()

    def getHeaderLines(self, append):
        return []
    
class TrackViewWigFixedLineComposer(TrackViewLineComposer):
    FILE_SUFFIX = '.wig'
    
    def __new__(cls, *args):
        return object.__new__(cls)
    
    def getHeaderLines(self, append):
        return (['track type=wiggle_0 name=' + self._name] if not append else []) +\
                ['\t'.join(['fixedStep','chrom=' + self._region.chr, \
                           'start=' + str(self._region.start),\
                           'step=1'])]
    
    def _compose(self, el):
        return '%.5f' % el.val()
    
class TrackViewWigBedLineComposer(TrackViewLineComposer):
    FILE_SUFFIX = '.wig'
    
    def __new__(cls, *args):
        return object.__new__(cls)
    
    def getHeaderLines(self, append):
        return ['track type=wiggle_0 name=' + self._name] if not append else []

    def _compose(self, el):
        tf = self._trackView.trackFormat
        if tf.isMarked('ordinal'):
            val = '%.5f' % el.val() 
        elif tf.isMarked('tc'):
            val = '%i' % el.val()
        elif tf.isMarked('meansd') or tf.isMarked('population'):
            val = ','.join('%.5f' % x for x in el.val())
        else:
            val = '0'
            
        lineList = [self._trackView.genomeAnchor.chr, str(el.start()), str(el.end()),
                    val]
        return '\t'.join(lineList)

class TrackViewBedLineComposer(TrackViewLineComposer):
    FILE_SUFFIX = '.bed'
    
    def __new__(cls, *args):
        return object.__new__(cls)
    
    def _compose(self, el):
        lineList = [self._trackView.genomeAnchor.chr, str(el.start()), str(el.end())]
        if self._trackView.trackFormat.isMarked('category'):
            lineList.append(str(el.val()))
        elif self._trackView.trackFormat.hasStrand():
            lineList.append('blank')
            
        if self._trackView.trackFormat.hasStrand():
            lineList += ['0', getStringFromStrand(el.strand())]
        return '\t'.join(lineList)

class TrackViewFastaLineComposer(TrackViewLineComposer):
    FILE_SUFFIX = '.fasta'
    
    def __new__(cls, *args):
        return object.__new__(cls)
    
    #def __iter__(self):
    #    self._trackViewIter = self._trackView.__iter__()
    #    return self

    def next(self):
        line = self._trackViewIter.next().val()
        
        try:
            for i in range(79):
                line += self._trackViewIter.next().val()
        except StopIteration:
            pass
        
        return line
    
    def getHeaderLines(self, append):
        return (['>' + str(self._region)])
    
class TrackExtractor:
    @staticmethod
    def extract(trackName, region, fn=None, append=False, globalCoords=True, addSuffix=False, asOriginal=False, allowOverlaps=False, ignoreEmpty=False):
        track = Track(trackName)
        track.addFormatReq(TrackFormatReq(allowOverlaps=allowOverlaps, borderHandling='crop'))
        trackView = track.getTrackView(region, includeSource=asOriginal)
        
        if asOriginal:
            assert globalCoords == True
            assert allowOverlaps == True
            if addSuffix:
                fn = os.path.splitext(fn)[0] + '.' + TrackInfo(region.genome, trackName).fileType
            return TrackExtractor._extractAsOriginal(trackView, fn, append, ignoreEmpty)
        else:
            return TrackExtractor._extract(trackView, trackName, region, fn, append, globalCoords, addSuffix, ignoreEmpty)
        
    @staticmethod
    def _getFileObject(fn, append):
        if fn!=None:
            ensurePathExists(fn)
        mode = 'a' if append else 'w'
        out = open(fn, mode) if fn!=None else sys.stdout
        return out

    @staticmethod
    def _closeFileObject(fn, out):
        if fn is not None:
            out.close()
        
    @staticmethod
    def _extract(trackView, trackName, region, fn, append, globalCoords, addSuffix, ignoreEmpty=False):
        if globalCoords:
            trackView.genomeAnchor = copy(region)
            trackView.genomeAnchor.start = 0
            trackView.genomeAnchor.end = GenomeInfo.getChrLen(region.genome, region.chr)
        else:
            trackView.genomeAnchor.chr = str(region)
        
        name = ':'.join(trackName)
        lineIter = TrackViewLineComposer(trackView, name.replace(' ','_'), region)
        
        if ignoreEmpty and len(lineIter) == 0:
            return
        
        if addSuffix:
            fn = os.path.splitext(fn)[0] + lineIter.FILE_SUFFIX
        
        out = TrackExtractor._getFileObject(fn, append)
        
        for line in chain(lineIter.getHeaderLines(append), lineIter):
            out.write(line + os.linesep)
        
        TrackExtractor._closeFileObject(fn, out)
        return fn
        
    @staticmethod
    def _extractAsOriginal(trackView, fn, append, ignoreEmpty=False):
        if ignoreEmpty and trackView.getNumElements() == 0:
            return
            
        out = TrackExtractor._getFileObject(fn, append)
        
        for el in trackView:
            if el.source() is None:
                raise RuntimeError('Preprocessed track does not include source data.')
            out.write(el.source() + os.linesep)

        TrackExtractor._closeFileObject(fn, out)
        return fn
        
    @staticmethod
    def extractManyToRegionDirs(trackNameList, regionList, baseDir, globalCoords=False, asOriginal=False, allowOverlaps=False, ignoreEmpty=True):
        for trackName in trackNameList:
            for region in regionList:
                fn = baseDir + os.sep + \
                    str(region).replace(':','_') + os.sep + \
                    '_'.join(trackName)
                TrackExtractor.extract(trackName, region, fn, False, globalCoords, True, asOriginal, allowOverlaps, ignoreEmpty)
                
    @staticmethod
    def extractOneTrackManyToRegionFilesInOneZipFile(trackName, regionList, zipFn, globalCoords=False, asOriginal=False, allowOverlaps=False, ignoreEmpty=True):
        ensurePathExists(zipFn)
        zipFile = ZipFile(zipFn, 'w')
        for region in regionList:
            fn = os.path.dirname(zipFn) + os.sep + str(region).replace(':','_')
            okFn = TrackExtractor.extract(trackName, region, fn, False, globalCoords, True, asOriginal, allowOverlaps, ignoreEmpty)
            if okFn:
                zipFile.write(okFn, os.path.basename(okFn))
                os.remove(okFn)
        zipFile.close()

    @staticmethod
    def extractOneTrackManyRegsToOneFile(trackName, regionList, fn, globalCoords=False, asOriginal=False, allowOverlaps=False):
        append = False
        for region in regionList:
            TrackExtractor.extract(trackName, region, fn, append, globalCoords, False, asOriginal, allowOverlaps)
            append = True
        
    @staticmethod
    def extractManyToOneDir(trackNameList, regionList, baseDir, globalCoords=False, asOriginal=False, allowOverlaps=False):
        for trackName in trackNameList:
            fn = baseDir + os.sep + '_'.join(trackName)
            TrackExtractor.extractOneTrackManyRegsToOneFile(trackName, regionList, fn, globalCoords, asOriginal, allowOverlaps)
                
if __name__ == "__main__":
    if len(sys.argv) not in [4, 5]:
        print 'Syntax: python TrackExtractor.py trackName:subtype genome:chr:start-end asOriginal [filename]'
        sys.exit(0)
        
    trackName = parseTrackNameSpec(sys.argv[1])
    region = parseRegSpec(sys.argv[2])
    asOriginal = eval(sys.argv[3])
        
    fn = sys.argv[4] if len(sys.argv) == 5 else None
    
    TrackExtractor.extract(trackName, region, fn, asOriginal=asOriginal)
