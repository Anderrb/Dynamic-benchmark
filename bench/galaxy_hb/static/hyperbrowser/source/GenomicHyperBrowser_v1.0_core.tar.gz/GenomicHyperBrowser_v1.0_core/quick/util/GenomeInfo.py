# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import os
from gold.application.Config import ORIG_DATA_PATH
from gold.util.CustomExceptions import NotSupportedError
from third_party.roman import fromRoman

#class GenomeTools
class GenomeInfo:
    _chrLengths = {}
    _genomeChrLists = {}
    _genomeExtChrLists = {}
    _chrArmRegs = {}
    _chrRegs = {}
    _containingChrArms = {}
    _chrMap = {'MT': 'chrM', 'chrMT': 'chrM'}
        
    @classmethod
    def fixChr(cls, chr):
        if chr in cls._chrMap:
            return cls._chrMap[chr]
        else:
            try:
                return 'chr' + str(fromRoman(chr))
            except:
                if chr.find('chr') > 0:
                    return chr[chr.find('chr'):]
                else:
                    return chr

    @classmethod
    def isInstalled(cls, genome):
        from gold.util.CommonFunctions import createOrigPath
        return os.path.exists(createOrigPath(genome, [], ''))
    
    @classmethod
    def getExtendedChrList(cls, genome):
        "Returns a list of all chromosomes that are allowed in input files, as they are part of the full genome build file set, but where some are ignored as their not part of our core set of chromosomes"
        #if genome.lower() in ['ncbi36','hg18']:
            #return ['chrM']
        if genome in cls._genomeExtChrLists:
            return cls._genomeExtChrLists[genome]
            
        from gold.util.CommonFunctions import createOrigPath
        seqFilesPath = createOrigPath(genome, ['sequence'], '')
        fullChrList = [fn.replace('.fa','') for fn in os.listdir(seqFilesPath) if '.fa' in fn]
        
        cls._genomeExtChrLists[genome] = fullChrList
        return fullChrList

    @classmethod
    def getChrList(cls, genome):
        if genome in cls._genomeChrLists:
            return cls._genomeChrLists[genome]
        
        if genome.lower() in ['testgenome']:
            chrList = ['chr21', 'chrM']
        else:
            chrListFn = cls.getChrRegsFn(genome)
            assert chrListFn is not None and os.path.exists(chrListFn), 'did not find file with chr-names: '+str(chrListFn)
            chrList = [line.split()[3].strip() for line in open(chrListFn,'U')]
        #if genome.lower() in ['ncbi36','hg18']:
        #    chrList = ["chr"+str(i) for i in range(1,23)] + ["chrX" , "chrY"]
        #elif genome.lower() in ['testgenome']:
        #    chrList = ['chr21', 'chrM']
        #else:
        #    chrList = [fn.replace('.fa','') for fn in os.listdir( os.sep.join([ORIG_DATA_PATH,genome,'sequence']) ) if fn.endswith('.fa')]
            #raise NotSupportedError()
        cls._genomeChrLists[genome] = chrList
        return chrList

    @classmethod
    def isValidChr(cls, genome, chr):
        return chr in cls.getExtendedChrList(genome)
        # Removed this, as chromosome mismatch now only displays a warning:
        #
        #return chr in cls.getExtendedChrList(genome) or \
        #    (chr.lower() in [x.lower() for x in cls.getExtendedChrList(genome)] and not chr in cls.getChrList(genome)) #allow case mismatch as long as it is an ignored chromosome anyway
    @staticmethod
    def getNumElementsInFastaFile(fn):
        f = open(fn)
        headerLen = len( f.readline() )
        lineLen = len( f.readline() ) #assumes all consecutive lines of same max length
        byteLen = os.path.getsize(fn)
        byteLen -= headerLen
        byteLen -= 1 #last newline char.
        return int(byteLen - (byteLen / lineLen)*len(os.linesep)) #subtract number of newline chars.. 
        
    @classmethod
    def getChrLen(cls, genome, chr):
        # For the unit-tests
        if genome.lower() == 'testgenome':
            if chr == 'chr21':
                return 46944323
            if chr == 'chrM':
                return 16571

        if genome in cls._chrLengths and \
            chr in cls._chrLengths[genome]:
            return cls._chrLengths[genome][chr]
        else:
            try:
                length = cls.getNumElementsInFastaFile(os.sep.join([ORIG_DATA_PATH, genome, 'sequence', cls.fixChr(chr) + '.fa']))
            except Exception, e:
                print "Unable to open sequence file for chromosome '" + chr + "'. Format should be either ('chr1', 'chr2'...) or ('chrX','chrY','chrM')."
                raise

            if not genome in cls._chrLengths:
                cls._chrLengths[genome] = {}
            cls._chrLengths[genome][chr] = length
            return length

        #if genome in cls._chrLengths and \
        #    chr in cls._chrLengths[genome]:
        #    return cls._chrLengths[genome][chr]
        #else:
        #    try:
        #        regs = cls.getChrRegs(genome,[chr])
        #        assert len(regs)==1
        #        length = regs[0].end
        #    except:
        #        try:
        #            length = cls.getNumElementsInFastaFile(os.sep.join([ORIG_DATA_PATH, genome, 'sequence', chr + '.fa']))
        #        except Exception, e:
        #            print "Unable to open sequence file for chromosome '" + chr + "'. Format should be either ('chr1', 'chr2'...) or ('chrX','chrY','chrM')."
        #            raise
        #
        #    if not genome in cls._chrLengths:
        #        cls._chrLengths[genome] = {}
        #    cls._chrLengths[genome][chr] = length
        #    return length
        
    @staticmethod
    def getPropertyTrackName(genome, propertyName):
        propertyName = propertyName.lower()
        if propertyName in ['chrs', 'chrarms', 'chrbands', 'gaps']:
            propertyTNDict = {'chrs': '_Chromosomes',
                              'chrbands': 'Cytobands',
                              'chrarms': 'Chromosome arms',
                              'gaps': 'Assembly gaps'}
#            if genome in ['NCBI36','hg18','TestGenome','pombe2007']:
            prefixTN = ['Genome build properties']
#            else:
#                prefixTN = ['Mapping and Sequencing Tracks']
            return prefixTN + [ propertyTNDict[propertyName] ]
        elif propertyName == 'ensembl':
#            if genome in ['NCBI36','hg18','pombe2007']:
            prefixTN = ['Genes and gene subsets','Genes']
#            else:
#                prefixTN = ['Genes and Gene Prediction Tracks','Genes']
            return prefixTN + ['Ensembl']
        elif propertyName == 'nmer':
#            if genome in ['NCBI36','hg18','pombe2007']:
            prefixTN = ['Sequence']
#            else:
#                prefixTN = ['Mapping And Sequencing Tracks']
            return prefixTN + ['Nmers']
        elif propertyName == 'literature':
            return ['Genes and gene subsets','Gene subsets','Literature-derived']
        elif propertyName == 'sequence':
            return ['sequence']
        
    @staticmethod
    def getChrTrackName(genome):
        return GenomeInfo.getPropertyTrackName(genome, 'chrs')

    @staticmethod
    def getCytobandsTrackName(genome):
        return GenomeInfo.getPropertyTrackName(genome, 'chrbands')

    @staticmethod
    def getChrArmsTrackName(genome):
        return GenomeInfo.getPropertyTrackName(genome, 'chrarms')

    @staticmethod
    def getAssemblyGapsTrackName(genome):
        return GenomeInfo.getPropertyTrackName(genome, 'gaps')

    @staticmethod
    def getEnsemblTrackName(genome):
        return GenomeInfo.getPropertyTrackName(genome, 'ensembl')

    @staticmethod
    def getNmerTrackName(genome):
        return GenomeInfo.getPropertyTrackName(genome, 'nmer')

    @staticmethod
    def getLiteratureTrackName(genome):
        return GenomeInfo.getPropertyTrackName(genome, 'literature')

    @staticmethod
    def getSequenceTrackName(genome):
        return GenomeInfo.getPropertyTrackName(genome, 'sequence')

    @staticmethod
    def getChrRegsFn(genome):
        from gold.util.CommonFunctions import getOrigFn
        return getOrigFn(genome, GenomeInfo.getChrTrackName(genome), '.category.bed')
        
    @classmethod
    def getChrRegs(cls, genome, categoryFilterList = None):
        if not genome in cls._chrRegs:
            from gold.util.CommonFunctions import createOrigPath
            from quick.application.UserBinSource import UnfilteredUserBinSource
            fn = cls.getChrRegsFn(genome)
            if fn is not None and os.path.exists(fn):            
                cls._chrRegs[genome] = UnfilteredUserBinSource('file',fn, genome, categoryFilterList)
            else:
                cls._chrRegs[genome] =  None
        return cls._chrRegs[genome]

    @staticmethod
    def getChrArmRegsFn(genome):
        from gold.util.CommonFunctions import getOrigFn
        return getOrigFn(genome, GenomeInfo.getChrArmsTrackName(genome), '.category.bed')
    
    @classmethod
    def getChrArmRegs(cls, genome, categoryFilterList = None):
        if not genome in cls._chrArmRegs:                    
            from gold.util.CommonFunctions import createOrigPath
            from quick.application.UserBinSource import UserBinSource
            fn = cls.getChrArmRegsFn(genome)
            if fn is not None and os.path.exists(fn):    
                cls._chrArmRegs[genome] = UserBinSource('file', fn, genome, categoryFilterList)
            else:
                cls._chrArmRegs[genome] = None
        return cls._chrArmRegs[genome]
    
    @classmethod
    def getStdGeneRegsTn(cls, genome):
        return cls.getEnsemblTrackName(genome)
    
    @classmethod
    def getStdGeneRegsFn(cls, genome):
        from gold.util.CommonFunctions import getOrigFn
        return getOrigFn(genome, cls.getStdGeneRegsTn(genome), '.category.bed')
    
    @classmethod
    def getStdGeneRegs(cls, genome, categoryFilterList = None, cluster = True):
        fn = cls.getStdGeneRegsFn(genome)
        return cls.getGeneRegs(genome, fn, categoryFilterList, cluster)
        
    @classmethod
    def getGeneRegs(cls, genome, fn, categoryFilterList = None, cluster = True):
        if fn is not None and os.path.exists(fn):
            if cluster:
                from quick.application.UserBinSource import UnBoundedUserBinSource
                return UnBoundedUserBinSource('file',fn, genome, categoryFilterList)
            else:
                from quick.application.UserBinSource import UnClusteredUserBinSource
                return UnClusteredUserBinSource('file',fn, genome, categoryFilterList)
        else:
            return None
    
    @staticmethod
    def getChrBandRegsFn(genome):
        from gold.util.CommonFunctions import getOrigFn
        return getOrigFn(genome, GenomeInfo.getCytobandsTrackName(genome), '.category.bed')
    
    @classmethod
    def getChrBandRegs(cls, genome, categoryFilterList = None):        
        from quick.application.UserBinSource import UserBinSource
        fn = cls.getChrBandRegsFn(genome)
        if fn is not None and os.path.exists(fn):
            return UserBinSource('file',fn, genome, categoryFilterList)
        else:
            return None
    
    @classmethod
    def getContainingChrArms(cls, region):
        if not region in cls._containingChrArms:
            cls._containingChrArms[region] = [arm for arm in cls.getChrArmRegs(region.genome) if arm.overlaps(region)]
        return cls._containingChrArms[region]
            
    @classmethod
    def regIntersectsCentromer(cls, region):
        if cls.getChrArmRegs(region.genome) is None:
            return False
        else:
            return not any([arm.contains(region) for arm in cls.getChrArmRegs(region.genome)])
        
