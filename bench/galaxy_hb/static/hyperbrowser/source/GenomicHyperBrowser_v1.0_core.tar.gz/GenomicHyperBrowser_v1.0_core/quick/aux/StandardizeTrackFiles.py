#!/usr/bin/env python
# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import bz2
import os
import sys
import shutil
import re
#from gold.application.RSetup import r
import shelve

from quick.util.CommonFunctions import ensurePathExists
from quick.util.GenomeInfo import GenomeInfo
from gold.application.Config import DEFAULT_GENOME
from quick.aux.OrigFormatConverter import OrigFormatConverter
from third_party.roman import fromRoman
from gold.util.CommonFunctions import createOrigPath, reverseDict
from quick.application.GalaxyInterface import GalaxyInterfaceTools
from gold.application.Config import PARSING_ERROR_DATA_PATH, NONSTANDARD_DATA_PATH, ORIG_DATA_PATH, DATA_FILES_PATH

class GeneralTrackDataModifier(object):
    @classmethod
    def parseFiles(cls, genome, trackName, **kwArgs):
        inPath = os.sep.join([cls.FROM_BASE_PATH, genome] + trackName)
        assert os.path.exists(inPath), 'Path does not exist: ' + inPath
        assert len(os.listdir(inPath)) != 0, 'Empty dir: ' + inPath
        
        fileWasHandled = False
        firstFile = True
        for baseFn in os.listdir(inPath):
            outFn = os.sep.join([cls.TO_BASE_PATH, genome] + trackName + [baseFn])
            inFn = inPath + os.sep + baseFn
            if os.path.isfile(inFn) and not baseFn.startswith('.'):                
                ensurePathExists(outFn)
                cls.parseFile(inFn, outFn, trackName, genome=genome, firstFile=firstFile, **kwArgs)
                fileWasHandled = True
                print '.',
                firstFile = False
        if not fileWasHandled:
            print 'No action taken on path: ', inPath
            print 'Having contents: ', os.listdir(inPath)
            

    @classmethod
    def parseAllSubTypes(cls, genome, mainTrackName, subTypeDepth=1, **kwArgs):
        subTypeDepth = int(subTypeDepth)
        assert subTypeDepth >= 1
        inPath = os.sep.join([cls.FROM_BASE_PATH, genome] + mainTrackName)
        firstSubType = True
        for subType in os.listdir(inPath):
            fullPath = inPath + os.sep + subType
            if not os.path.isdir(fullPath) and not subType[0]=='_':
                continue

            print
            print '-' * subTypeDepth,
            print 'standardizing subFolder: ', subType
            
            if subTypeDepth == 1:
                cls.parseFiles(genome, mainTrackName+[subType], firstSubType=firstSubType, **kwArgs)
                               
            else:
                cls.parseAllSubTypes(genome, mainTrackName+[subType], subTypeDepth=subTypeDepth-1, **kwArgs)

            firstSubType = False
                    
class GeneralImporter(GeneralTrackDataModifier):
    FROM_BASE_PATH = NONSTANDARD_DATA_PATH
    TO_BASE_PATH = ORIG_DATA_PATH
    "Different ways of importing and standardizing track data from collected tracks to standardized tracks "
    pass

class GeneralDeriver(GeneralTrackDataModifier):
    FROM_BASE_PATH = ORIG_DATA_PATH
    TO_BASE_PATH = ORIG_DATA_PATH
    "Different ways of extending/augmenting data in standardize tracks. E.g. by converting between categorical bed and subfolder of beds containing subtracks"
    pass

#E.g. SNP-files from Sigve..
class RemoveFirstLine(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, **kwArgs):
        print inFn
        inFile = open(inFn)
            
        if not outFn.endswith('.bed'):
            outFn += '.bed'
            
        ensurePathExists(outFn)
        outFile = open(outFn,'w')
        
        #ignore first line..
        first = True
        
        for line in inFile:
            if first:
                first = False
                continue
            outFile.write( line )
    
    
#E.g. methylation:
class ImplicitChrSegments(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, **kwArgs):
        print inFn
        assert(inFn.count('chr')==1)
        assert(inFn.endswith('.txt'))
        
        chrIndex = inFn.find('chr')
        chr = inFn[ chrIndex : inFn.find('_',chrIndex)]

        inFile = open(inFn)
            
        outFn += '.bed'
        ensurePathExists(outFn)
        outFile = open(outFn,'w')
        
        for line in inFile:
            outFile.write( chr + '\t' + line )
        

class OneBasedInclusive(GeneralImporter):
    @classmethod
    def subtactOneFromStart(cls, cols):
        cols[1] = str( int(cols[1]) - 1 )
        return cols
    
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, **kwArgs):
        print inFn, outFn
        assert(inFn.endswith('.txt') or inFn.endswith('.point'))
        
        inFile = open(inFn)

        if not outFn.endswith('.bed'):
            outFn += '.bed'
        
        ensurePathExists(outFn)
        outFile = open(outFn,'w')
        
        for line in inFile:
            cols = line.strip().split('\t')
            outFile.write( '\t'.join(cls._processCols(cols)) + os.linesep )
        
    @classmethod
    def _processCols(cls, cols):
        return cls.subtactOneFromStart(cols)

# E.g DNaseHS clusters       
class OneBasedInclusiveCutExtraCols(OneBasedInclusive):
    @classmethod
    def _processCols(cls, cols):
        return cls.cutExtraCols( cls.subtactOneFromStart(cols) )
    
    @classmethod
    def cutExtraCols(cls, cols):
        return cols[0:6]
    
# E.g DNaseHS individuals
class OneBasedInclusivePointAddNameAndScoreCutExtraCols(OneBasedInclusiveCutExtraCols):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, **kwArgs):
        outFn += '.point'
        super(OneBasedInclusivePointAddNameAndScoreCutExtraCols, cls).parseFile(inFn, outFn, trackName)

    @classmethod
    def _processCols(cls, cols):
        return cls.cutExtraCols( cls.addNameAndScore( cls.subtactOneFromStart(cols) ) )
    
    @classmethod
    def addNameAndScore(cls, cols):
        return cols[0:3] + ['N/A'] + ['0'] + cols[3:]

class TrivialParser(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, **kwArgs):
        print inFn
        assert(inFn.endswith('.wig') or inFn.endswith('.bed'))
        
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn,'w')
        
        for line in inFile:
            outFile.write( line )

class ParseTrackNameFromFnHCNE(GeneralImporter):
    @classmethod
    def parseFiles(cls, genome, trackName, **kwArgs):
        inPath = os.sep.join([NONSTANDARD_DATA_PATH, genome] + trackName)    
        
        for baseFn in os.listdir(inPath):
            subType = [baseFn.replace('HCNE_','').replace('hg18_','').replace('.wig','').replace('.bed','')]
            
            outFn = os.sep.join([ORIG_DATA_PATH, genome] + trackName + subType + [baseFn])
            inFn = inPath + os.sep + baseFn
            if os.path.isfile(inFn) and not baseFn.startswith('.'):
                if baseFn.endswith('.wig'):
                    TrivialParser.parseFile(inFn, outFn, trackName)
                elif baseFn.endswith('.bed'):
                    RemoveFirstLine.parseFile(inFn, outFn, trackName)
                print '.',

#E.g. melting:
class PlainNumbers(GeneralImporter):

    @classmethod
    def parseFile(cls, inFn, outFn, trackName, **kwArgs):
        print inFn
        assert(inFn.count('chr')==1)
        chrIndex = inFn.find('chr')
        chr = inFn[ chrIndex : inFn.find('.',chrIndex)]

        if inFn.endswith('.bz2'):
            inFile = bz2.BZ2File(inFn)
            outFn = outFn.replace('.bz2','')     
        else:
            inFile = open(inFn)
            
        outFn += '.wig'
        ensurePathExists(outFn)
        outFile = open(outFn,'w')
        
        outFile.write( os.linesep.join(['track type=wiggle_0 name=' + ':'.join(trackName),
                '\t'.join(['fixedStep','chrom=' + chr, 'start=1', 'step=1'])]) + os.linesep)
        
        for pos in xrange(GenomeInfo.getChrLen(DEFAULT_GENOME, chr)):
            #for line in inFile:
            line = inFile.readline()
            if line=='':
                print 'Warning: File to short: ',inFn
                outFile.write('0.0 nan')
            else:
                outFile.write(line)
        
        while inFile.readline() != '':
            print 'Warning: Extra bps in file: ' ,inFn
        
class WigVariableStepWithSpanAsWigBedImporter(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, **kwArgs):
        OrigFormatConverter.wigVariableStepWithSpanToWigBed(inFn, outFn)
        

class SplitEachFileToSubdirImporter(GeneralImporter):
    @classmethod
    def parseFiles(cls, genome, mainTrackName, **kwArgs): #directly overwrites parseFiles in plural..
        inPath = os.sep.join([NONSTANDARD_DATA_PATH, genome] + mainTrackName)
        for relFn in os.listdir(inPath):
            subType = ''.join( relFn.split('.')[:-1])
            print 'moving subtype: ', subType
            fullPath = inPath + os.sep + relFn
            outPath = os.sep.join([ORIG_DATA_PATH, genome] + mainTrackName + [subType,relFn])
            ensurePathExists(outPath)
            print outPath
            if os.path.isfile(fullPath) and not relFn[0]=='_':
                shutil.copy(fullPath, outPath)#+os.sep+relFn)
        
class FixChromOfFastaFiles(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, **kwArgs):
        assert inFn.endswith('.fa')
        
        inFile = open(inFn, 'r')
        header = inFile.readline()
        assert header.startswith('>')
        chr = GenomeInfo.fixChr( header.split()[0][1:] )
        
        outFn = os.path.dirname(outFn) + os.sep + chr + '.fa'
        outFile = open(outFn, 'w')
        outFile.write('>' + chr + ' ' + ' '.join(header.split()[1:]) + os.linesep)
        for line in inFile:
            outFile.write(line)

class SplitFasta(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, chromNames, **kwArgs):
        assert inFn.lower().endswith(".fa") or inFn.lower().endswith(".fasta") , "Error: Not a .fa or .fasta file"
        fastaFile=open(inFn, "r")    
        chromFile=None
        includechromosome=False
        for l in fastaFile:
            if l[0]==">":
                if chromFile is not None:
                    chromFile.close()
                ensurePathExists(outFn)
                if l[1:].strip() in chromNames.keys():
                    newchromname=chromNames[l[1:].strip()]
                    chromFile=open(os.path.dirname(outFn) + os.sep + newchromname+".fa", "w")
                    chromFile.write(">"+newchromname+os.linesep)
                    includechromosome=True
                else:
                    includechromosome=False
                    
            else:
                if includechromosome:
                    chromFile.write(l)
        if chromFile is not None:
            chromFile.close()
        fastaFile.close()

class FilterByRegExp(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, regExp='', numHeaderLines=0, **kwArgs):
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
        
        for i in range(int(numHeaderLines)):
            outFile.write(inFile.readline())
    
        for line in inFile:
            if len(re.findall(regExp, line)) > 0:
                outFile.write(line)
                                
class CutColumns(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, colListStr='', numHeaderLines=0, **kwArgs):
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
        
        colList = [int(x) for x in colListStr.split(',')]
        
        for i in range(int(numHeaderLines)):
            outFile.write(inFile.readline())
    
        for line in inFile:
            cols = line.strip().split()            
            outFile.write('\t'.join(cols[x] for x in colList) + os.linesep)
            

class SplitToSeparatChrFiles(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, baseOutFn, trackName, numHeaderLines=0, **kwArgs):
        assert numHeaderLines==0, 'not supported yet (should be easy..)'
        
        inFile = open(inFn)
        ensurePathExists(baseOutFn)
        #outFile = open(outFn, 'w')
        outFiles = {}
        
        for line in inFile:
            if line.strip()=='':
                continue
            cols = line.strip().split()
            assert len(cols) >= 3
            chr = cols[0]
            if not chr in outFiles:
                outFn = os.path.split(baseOutFn)[0] + os.sep + chr + '_' + os.path.split(baseOutFn)[1]
                print 'creating fn: ', outFn
                outFiles[chr] = open(outFn,'w')
            outFiles[chr].write(line)
        
            
                
class FilterOutNonStandardChrLines(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, numHeaderLines=0, **kwArgs):
#        assert genome=='NCBI36' #only supported yet..
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
        
        for i in range(int(numHeaderLines)):
            outFile.write(inFile.readline())
    
        removedChrs = set([])
        removedLines = 0
#        standardChrs = ['chr'+str(x) for x in range(1,23)+list('XYM')]
        standardChrs = GenomeInfo.getExtendedChrList(genome)
        for line in inFile:
            if line.split()[0] in standardChrs:
                outFile.write(line)
            else:
                removedChrs.add(line.split()[0])
                removedLines+=1
        print 'Removed ',removedLines, ' lines, having chromosomes: ',removedChrs
    
class ReplaceByRegExp(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, regExp='', replaceWith='', selectedCol=None, **kwArgs):
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
    
        for line in inFile:
            if selectedCol is None:
                outFile.write(re.sub(regExp, replaceWith, line))
            else:
                cols = line.strip().split()
                cols[int(selectedCol)] = re.sub(regExp, replaceWith, cols[int(selectedCol)])
                outFile.write('\t'.join(cols) +os.linesep)

class ShiftLines(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, linesToShiftDownwards=0, numHeaderLines=0, **kwArgs):
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
        
        for i in range(int(numHeaderLines)):
            outFile.write(inFile.readline())
    
        lines = [line for line in inFile]
        
        for line in lines[-int(linesToShiftDownwards):] + lines[:-int(linesToShiftDownwards)]:
            outFile.write(line)
        
class RemoveBeyondChrRange(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, **kwArgs):
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
                
        for line in inFile:
            cols = line.split()
            if not 'chr' in line or len(cols) < 3:
                print 'Skipping assumed header: ', line
                continue
            
            start,end = [int(x) for x in cols[1:3]]
            if 0 <= start < end < GenomeInfo.getChrLen(genome, cols[0]):
                outFile.write(line)
            else:
                print 'Skipping line: ', line

class SplitFileToSubDirs(GeneralDeriver):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, suffix='.bed', catSuffix='.category.bed', subTypeCol='3', depth='1', **kwArgs):
        depth = int(depth)
        subTypeCol = int(subTypeCol)
        inFile = open(inFn)
        #ensurePathExists(outFn)
        baseOutFolder, baseFn = os.path.split(outFn)
        
        catFns = {}
        i = 0
        data = []
        for line in inFile:
            cols = line.split()
            splittedCat = cols[subTypeCol].split(os.sep)
            cat = os.sep.join( splittedCat[0:depth] )
            ending = catSuffix if len(splittedCat) > depth else suffix
            if not cat in catFns:
                fn = os.sep.join([baseOutFolder,cat,baseFn.split('.')[0] + ending])
                print 'creating path: ', fn
                ensurePathExists(fn)                    
                catFns[cat] = fn
            data.append([cat, '\t'.join(cols[:subTypeCol] + ([os.sep.join(splittedCat[depth:depth+1])] if len(splittedCat)>depth else [cat]) + \
                                          (cols[subTypeCol+1:] if len(cols)>4 else [])) + os.linesep])
        inFile.close()
        print 'Finished reading'
        data = sorted(data)
        print 'Finished sorting'
        
        prevCat = ''
        outFile = None
        for el in data:
            if el[0] != prevCat:
                if outFile is not None:
                    outFile.close()
                outFile = open(catFns[el[0]], 'w+')
                prevCat = el[0]
            outFile.write(el[1])
        outFile.close()
            
            #outFiles[cat].write(line)
            #files[cats[cat][1]] += '\t'.join(cols[:3] + ([os.sep.join(splittedCat[depth:depth+1])] if len(splittedCat)>depth else ['-']) + \
             #                             (cols[4:] if len(cols)>4 else [])) + os.linesep
        
class RemoveCombinedCategoryBeds(GeneralDeriver):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, allSubTypes=False, **kwArgs):
        baseDir = os.sep.join(outFn.split(os.sep)[: (-2 if allSubTypes else -1) ])
        combinedFn = os.sep.join([baseDir, 'combined.category.bed'])
        print 'Removing %s' %combinedFn
        if os.path.exists(combinedFn):
            os.remove(combinedFn)

class SubtypesAsCategories(GeneralDeriver):
    'Makes a categorical file from all subtypes of a given track name, which will make is possible to select "all subTypes" for this track name'

    @classmethod
    def parseFile(cls, inFn, outFn, trackName, keepCategories=False, firstSubType=False, firstFile=False, **kwArgs):
        print inFn, outFn
        if type(keepCategories) == str:
            keepCategories = eval(keepCategories)
        if not inFn.endswith('.bed'):
            return

        subDir = os.path.dirname(outFn).split(os.sep)
        subType = subDir[-1].replace(' ', '_')
        baseDir = os.sep.join(subDir[:-1])
        
        combinedFn = os.sep.join([baseDir, 'combined.category.bed'])
        if firstSubType and firstFile and os.path.exists(combinedFn):
            print 'Removing %s' %combinedFn
            os.remove(combinedFn)

        outF = open(combinedFn,'a')
        
        for line in open(inFn):
            cols = line.strip().split()
            if len(cols) < 3:
                raise InvalidFormatError('Line does not have enough columns: %s' %line)

            if len(cols) == 3:
                cols.append(subType)  
            elif len(cols) > 3:
                if not keepCategories:
                    cols[3] = subType
                
            outF.write('\t'.join(cols) + os.linesep)
            
        outF.close()

class FilterOnCategoryDepth(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, depth='1', **kwArgs):
        depth = int(depth)
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
        for line in inFile:
            cols = line.split()
            splittedCat = cols[3].split(os.sep)
            outFile.write( '\t'.join(cols[:3] + [os.sep.join(splittedCat[:depth])] + \
                                          (cols[4:] if len(cols)>4 else [])) + os.linesep)
        outFile.close()
        inFile.close()
            
class CopyAndSplitTcWigToSubDirs(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, **kwArgs):
        #copy:
        assert inFn.endswith('targetcontrol.wig')
        ensurePathExists(outFn)
        shutil.copy(inFn, outFn)
        
        #split:
        inFile = open(inFn)
        #ensurePathExists(outFn)
        baseOutFolder, baseFn = os.path.split(outFn)
        
        outFiles = {}
        header = None
        for line in inFile:
            if header is None:
                header = line
                continue
            
            cols = line.split()            
            cat = cols[3]
            ending = '.wig'
            if not cat in outFiles:
                fn = os.sep.join([baseOutFolder,cat,baseFn.split('.')[0] + ending])
                print 'creating path: ', fn
                ensurePathExists(fn)           
                outFiles[cat] = open(fn, 'w')
                outFiles[cat].write(header)
            outFiles[cat].write(line)
        
        for cat in outFiles:
            outFiles[cat].close()

class PlainTransfer(GeneralImporter):
    FILE_OPERATION = 'copy'

    @classmethod
    def parseFile(cls, fromFn, toFn, trackName, genome, **kwArgs):
        if not os.path.exists(toFn):
            print FILE_OPERATION + ' from %s to %s' % (fromFn, toFn)
            ensurePathExists(toFn)
            if cls.FILE_OPERATION == 'copy':
                shutil.copy(fromFn, toFn)
            elif cls.FILE_OPERATION == 'move':
                shutil.move(fromFn, toFn)
            else:
                raise
        else:
            print 'File already exists in target folder: ', toFn

class FromErrorToStdMover(PlainTransfer):
    FILE_OPERATION = 'move'
    FROM_BASE_PATH = PARSING_ERROR_DATA_PATH
#class ReverseCopier(GeneralImporter):
#    @classmethod
#    def parseFiles(cls, genome, trackName, newTrackName=None, **kwArgs):
#        if type(newTrackName) == str:
#            newTrackName = newTrackName.replace(os.sep, ':').split(':')
#
#        inPath = os.sep.join([cls.TO_BASE_PATH, genome] + trackName)
#        if newTrackName is not None:
#            trackName = newTrackName
#        print inPath
#        for baseFn in os.listdir(inPath):
#            outFn = os.sep.join([cls.FROM_BASE_PATH, genome] + trackName + [baseFn])
#            inFn = inPath + os.sep + baseFn
#            if os.path.isfile(inFn) and not baseFn.startswith('.'):
#                cls.parseFile(inFn, outFn, trackName, genome=genome, **kwArgs)
#                print '.',
    
    #@classmethod
    #def parseAllSubTypes(cls, genome, mainTrackName, newTrackName=None, **kwArgs):
    #    if type(newTrackName) == str:
    #        newTrackName = newTrackName.replace(os.sep, ':').split(':')
    #
    #    inPath = os.sep.join([cls.TO_BASE_PATH, genome] + mainTrackName)
    #    
    #    for subType in os.listdir(inPath):
    #        fullPath = inPath + os.sep + subType
    #        if not os.path.isfile(fullPath) and not subType[0]=='_':
    #            print 'standardizing subFolder: ', subType
    #            cls.parseFiles(genome, mainTrackName+[subType], newTrackName=newTrackName+[subType] if newTrackName is not None else None, **kwArgs)

class ReverseCopier(PlainTransfer):
    FROM_BASE_PATH = ORIG_DATA_PATH
    TO_BASE_PATH = NONSTANDARD_DATA_PATH
    
class ReverseMover(ReverseCopier):    
    FILE_OPERATION = 'move'

#class ReverseMover(ReverseCopier):
#    @classmethod
#    def parseFile(cls, stdFn,collFn, trackName, genome, **kwArgs):
#        if not os.path.exists(collFn):
#            print 'Move from std to coll'
#            ensurePathExists(collFn)
#            shutil.move(stdFn, collFn)
#        else:
#            print 'File already exists in coll: ', collFn

class MoveToParseErrors(ReverseMover):
    TO_BASE_PATH = PARSING_ERROR_DATA_PATH
    #@classmethod
    #def parseFile(cls, stdFn,collFn, trackName, genome, **kwArgs):
    #    if not os.path.exists(collFn):
    #        print 'Move from std to coll'
    #        ensurePathExists(collFn)
    #        shutil.move(stdFn, collFn)
    #    else:
    #        print 'File already exists in coll: ', collFn

class TrackFileCopier(GeneralDeriver):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, newBaseTrackName=None, parentsAsPrefix='False', **kwArgs):
        assert newBaseTrackName is not None, 'You must provide a new base track name'
        newBaseTrackName = newBaseTrackName.replace('/',':').split(':')

        parentsAsPrefix = eval(parentsAsPrefix)
        assert parentsAsPrefix in [False, True]

        outFn = os.sep.join([ORIG_DATA_PATH, genome] + newBaseTrackName + \
                            [(trackName[-2] + ' - ' if parentsAsPrefix else '') + trackName[-1], os.path.basename(inFn)])
        
        print 'Copy from %s to %s' % (inFn, outFn)

        ensurePathExists(outFn)
        shutil.copy(inFn, outFn)

class TrackFullTreeCopier(GeneralDeriver):
    @classmethod
    def parseFiles(cls, genome, trackName, newBaseTrackName=None, **kwArgs):
        assert newBaseTrackName is not None, 'You must provide a new base track name'
        newBaseTrackName = newBaseTrackName.replace('/',':').split(':')

        inPath = os.sep.join([ORIG_DATA_PATH, genome] + trackName)
        outPath = os.sep.join([ORIG_DATA_PATH, genome] + newBaseTrackName)
        
        print 'Copy from %s to %s' % (inPath, outPath)
        shutil.copytree(inPath, outPath)

class RemoveEmptyFiles(ReverseCopier):
    @classmethod
    def parseFiles(cls, genome, trackName, **kwArgs):
        inPath = os.sep.join([ORIG_DATA_PATH, genome] + trackName)
        
        if all([os.path.getsize(os.sep.join([ORIG_DATA_PATH, genome] + trackName + [baseFn])) == 0 \
                for baseFn in os.listdir(inPath)]):
            print 'Removing directory %s' %inPath
            shutil.rmtree(inPath)
                
class RemoveSmallFiles(ReverseCopier):
    @classmethod
    def parseFiles(cls, genome, trackName, minNumLines=0, **kwArgs):
        inPath = os.sep.join([ORIG_DATA_PATH, genome] + trackName)
        
        if all([len(open(os.sep.join([ORIG_DATA_PATH, genome] + trackName + [baseFn]), 'r').readlines()) < int(minNumLines) \
                for baseFn in os.listdir(inPath)]):
#            print inPath, len(open(os.sep.join([ORIG_DATA_PATH, genome] + trackName + [baseFn]), 'r').readlines())
            print 'Removing directory %s' %inPath
            shutil.rmtree(inPath)
                
class CreateAssemblyGapsAndChromosomeArmsFiles(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, **kwArgs):
        gapsFn = os.path.split(outFn)[0] + os.sep + 'assemblyGaps.category.bed'
        chromArmsFn = createOrigPath(genome, GenomeInfo.getPropertyTrackName(genome, 'chrarms'),'chromosomeArms.category.bed')

        ensurePathExists(gapsFn)
        ensurePathExists(chromArmsFn)
        
        inFile = open(inFn)
        inFile.readline()
        
        outFileGaps = open(gapsFn, 'w')
        outFileArms = open(chromArmsFn, 'w')
        
        centromere_starts = {}
        centromere_ends = {}
        
        for line in inFile:
            cols = line.strip().split()
            outFileGaps.write('\t'.join(cols[i] for i in [1,2,3,7]) + os.linesep)
            
            chr = cols[1]
            if not chr in centromere_starts:
                centromere_starts[chr] = []
                centromere_ends[chr] = []
                
            if any(x in cols[7].lower() for x in ['centromere', 'heterochromatin', 'arms']):
                centromere_starts[chr].append(int(cols[2]))
                centromere_ends[chr].append(int(cols[3]))
        
        for chr in GenomeInfo.getChrList(genome):
            chrLen = GenomeInfo.getChrLen(genome, chr)
            if len(centromere_starts[chr]) == 0:
                outFileArms.write('\t'.join([chr, str(0), str(chrLen), chr]) + os.linesep)
            else:
                centromerStart = sorted(centromere_starts[chr])[0]
                centromerEnd = list(reversed(sorted(centromere_ends[chr])))[0]
                
                if 0 < centromerStart:
                    outFileArms.write('\t'.join([chr, str(0), str(centromerStart), chr + 'p']) + os.linesep)
                if centromerEnd < chrLen:
                    outFileArms.write('\t'.join([chr, str(centromerEnd), str(chrLen), chr + 'q']) + os.linesep)
        
        outFileGaps.close()
        outFileArms.close()
        inFile.close()

class FilterOnColumnVal(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, valCol='4', valKeepFunc='lambda x:True', **kwArgs):
        inFile = open(inFn)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
        for line in inFile:
#            if line.startswith('track'):
#                continue
            cols = line.split()
            valCol = int(valCol)
            if not valCol < len(cols):
                continue
            if not eval(valKeepFunc)(float(cols[valCol])):
                continue
            outFile.write( '\t'.join(cols) + os.linesep)
        outFile.close()
        inFile.close()

#class LambdaOnSelectedColumn(GeneralImporter):
#    '''Evaluates a custom lambda function on a selected column, replacing the column value with what the lambda evaluates to
#    Example: 'lambda x:str(int(x)*2) would replace the values at the selected column with that of its double..
#    '''
#    @classmethod
#    def parseFile(cls, inFn, outFn, trackName, genome, col='3', customLambda='lambda x:x', **kwArgs):
#        pass
#        inFile = open(inFn)
#        ensurePathExists(outFn)
#        outFile = open(outFn, 'w')
#        for line in inFile:
##            if line.startswith('track'):
##                continue
#            cols = line.split()
#            valCol = int(valCol)
#            if not valCol < len(cols):
#                continue
#            if not eval(valKeepFunc)(float(cols[valCol])):
#                continue
#            outFile.write( '\t'.join(cols) + os.linesep)
#        outFile.close()
#        inFile.close()
        
class CalculateHypergeometricPVal(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, n='1', minQ='2', excludeCats='[]', onlyIncludeCatsFn='', minArticles='0', \
                  maxPval='1.0', numTests='1', useLog='True', increaseEnds='False', makeCategoryBed='False', **kwArgs):
        from gold.application.RSetup import r
        
        minArticles = int(minArticles)
        
        inFile = open(inFn)
        ensurePathExists(outFn)
        
        assert outFn.endswith('.bed')
        if eval(makeCategoryBed) and not outFn.endswith('.category.bed'):
            outFn = outFn.replace('.bed', '.category.bed')
        outFile = open(outFn, 'w')

        if onlyIncludeCatsFn != '':
            onlyIncludeCats = [line.strip() for line in open(onlyIncludeCatsFn, 'r')]
        else:
            onlyIncludeCats = None

        hasWritten = False
        
        for line in inFile:
            cols = line.strip().split()
            if onlyIncludeCats is not None:
                if cols[3] not in onlyIncludeCats:
                    continue
            else:
                if cols[3] in eval(excludeCats):
                    continue
            
            q, m, n, k = int(cols[6]), int(cols[7]), int(n) - int(cols[7]), int(cols[8])
            if k < minArticles:
                outFile.close()
                inFile.close()
                return
            
            if q < int(minQ):
                continue
            
            pval = r('function(q, m, n, k, log) { phyper(q, m, n, k, lower.tail=FALSE, log.p=log) }')(q, m, n, k, eval(useLog))
            maxPvalBonfCorr = float(maxPval)/int(numTests)
            
            if useLog:
                from math import log
                maxPvalBonfCorr = log(maxPvalBonfCorr)
            if pval > maxPvalBonfCorr:
                continue
            if eval(increaseEnds):
                cols[2] = str(int(cols[2]) + 1)
                
            outFile.write('\t'.join(cols[0:4] + [str(pval), cols[5]]) + os.linesep)
            hasWritten = True
            
        outFile.close()
        inFile.close()

        if not hasWritten:
            outDir = os.path.dirname(outFn)
            print 'Nothing written. Removing directory %s' %outDir
            shutil.rmtree(outDir)

class RemapCategoryColumn(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, insuffix='bed', outsuffix='category.bed', catCol='3', shelveMapFile='', **kwArgs):
        inFile = open(inFn)
        outFn = outFn.replace(insuffix, outsuffix)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
        if not os.path.exists(shelveMapFile):
            print 'Map file \'%s\' does not exist.' % shelveMapFile
            sys.exit(0)
        mapFile = shelve.open(shelveMapFile, 'r')
        
        for line in inFile:
            if line.startswith('track'):
                continue
            cols = line.strip().split()
            catCol = int(catCol)
            if not catCol < len(cols):
                continue
            if cols[catCol] in mapFile:
                for cat in mapFile[cols[catCol]]:
                    outFile.write( '\t'.join([cols[x] for x in [0,1,2]] + [cat] + [cols[x] for x in range(4, len(cols))]) + os.linesep)

        mapFile.close()
        outFile.close()
        inFile.close()

class ExpandBedSegments(GeneralDeriver):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, upFlank='0', downFlank='0', removeChrBorderCrossing='False', **kwArgs):
        removeChrBorderCrossing = eval(removeChrBorderCrossing)
        assert removeChrBorderCrossing in [False, True]
        assert inFn == outFn
        inFn = inFn + '.orig'
        shutil.copy(outFn, inFn)
        GalaxyInterfaceTools.expandBedSegments(inFn, outFn, genome, upFlank, downFlank, removeChrBorderCrossing)
        os.remove(inFn)

class ImportBarJoseph(GeneralImporter):
    @classmethod
    def parseFile(cls, inFn, outFn, trackName, genome, **kwArgs):
        id2Name = reverseDict( shelve.open(DATA_FILES_PATH + '/pwmName2id.shelf') )
        
        outF = open(outFn+'.category.bed', 'w')
        header=True
        for line in open(inFn):
            cols = line.split()
            if header:
                assert cols[0:3] == ['chr','position','gene']
                pwmIds = cols[3:]
                ignoredIds = [id for id in pwmIds if not id.lower() in id2Name]
                print 'Warning! Ignoring %i out of %i pwm IDs: '%(len(ignoredIds),len(pwmIds)), ignoredIds
                header = False
            else:
                positionData = cols[0:2] + [str(int(cols[1])+1)]
                pwmIndicators = cols[3:]
                assert len(pwmIndicators) == len(pwmIds)
                for pwmIndex in range(len(pwmIndicators)):
                    if pwmIds[pwmIndex] in ignoredIds:
                        continue
                    if pwmIndicators[pwmIndex] == '1':
                        outF.write('\t'.join(positionData+[id2Name[pwmIds[pwmIndex]]]) + os.linesep)

if __name__ == "__main__":
    if not (len(sys.argv) == 4 or ( len(sys.argv) > 4 and \
                                    all(sys.argv[i].find('=') != -1 for i in range(4,len(sys.argv))) )):
        print ''
        print "Usage: StandardizeTrackFiles genome trackName:subtype parserClassName [allSubTypes=True] [subTypeDepth=1] [other keyword arguments..]"
        print 'NB: Adding the term AllSubtypes will assume subtypes are located in subdirectories..'
        print ''
        print 'All defined GeneralImporter-based classes: '
        print ', '.join(sorted([x.__name__ for x in globals().values() if type(x)==type(GeneralImporter) and issubclass(x,GeneralImporter)]))
        print ''
        print os.linesep + 'Available parser-classes are (possibly incomplete list): '
        print 'RemoveFirstLine, ImplicitChrSegments, OneBasedInclusive, OneBasedInclusiveCutExtraCols, '
        print 'OneBasedInclusivePointAddNameAndScoreCutExtraCols, ParseTrackNameFromFnHCNE, TrivialParser, '
        print 'PlainNumbers, WigVariableStepWithSpanAsWigBedImporter, SplitEachFileToSubdirImporter, '
        print 'FixChromOfFastaFiles, SplitFasta(chromNames=""), FilterByRegExp(regExp=\'\', numHeaderLines=0), '
        print 'ReplaceByRegExp(regExp=\'\', replaceWith=\'\',selectedCol=None), ShiftLines(linesToShiftDownwards=0, numHeaderLines=0)'
        print 'RemoveBeyondChrRange, SplitFileToSubDirs(suffix=".category.bed", catSuffix=".bed", subTypeCol=3, depth=1), RemoveCombinedCategoryBeds, '
        print 'SubtypesAsCategories(keepCategories=False), FilterOnCategoryDepth(depth=1), CopyAndSplitTcWigToSubDirs, ReverseCopier(newTrackName=None)'
        print 'ReverseMover, TrackFileCopier(newBaseTrackName=None),  TrackFullTreeCopier(newBaseTrackName=None), '
        print 'CreateAssemblyGapsAndChromosomeArmsFiles, CutColumns(colListStr='', numHeaderLines=0)'
        print 'SplitToSeparatChrFiles(numHeaderLines=0), FilterOnColumnVal(valCol=4, valKeepFunc="lambda x:True")'
        print 'RemoveEmptyFiles, RemoveSmallFiles(minNumLines=0) '
        print 'CalculateHypergeometricPVal(n=1, minQ=1, excludeCats=[], onlyIncludeCatsFn='', maxPval=1.0, minArticles=0, numTests=1, useLog=True, increaseEnds=False, makeCategoryBed=False)'
        print 'RemapCategoryColumn(insuffix=bed, outsuffix=category.bed, catCol=3, shelveMapFile=\'\')'
        print 'ExpandBedSegments(upFlank=0, downFlank=0, removeChrBorderCrossing=False), ImportBarJoseph, MoveToParseErrors, FromErrorToStdMover'
        sys.exit(0)
            
    genome = sys.argv[1]
    trackName = sys.argv[2].replace('/',':').split(':')
    parserClass = sys.argv[3]
    kwArgs = dict((kwArg[0:kwArg.find('=')], kwArg[kwArg.find('=')+1:]) for kwArg in sys.argv[4:])
    
    if 'allSubTypes' in kwArgs and kwArgs['allSubTypes'] in [True,'True']:
        globals()[parserClass].parseAllSubTypes(genome, trackName, **kwArgs)
    else:
        globals()[parserClass].parseFiles(genome, trackName, **kwArgs)
