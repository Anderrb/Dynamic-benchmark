# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from quick.postprocess.Plotter import Plotter
from quick.postprocess.GlobalCollectorPP import GlobalCollectorPP
#from gold.statistic.AllStatistics import ZipperStat
from quick.postprocess import *
#from pylab import *


class ScatterPlotter:
    def __init__(self, data, outputFileName):
        self._outputFileName = outputFileName
        self._data = data
        
    def buildPlot(self):
        results = [(x,y) for x,y in self._data]
        return results
        

#        coll = XBinnerPP(coll, self._binSize)
#        coll = YSummarizerPP(coll, lmean)
#        data = StatRunner.run(geSource, track, track2, ZipperStat, CountStat, MeanStat)
#        data = GlobalCollectorPP(self._geSource, self._track1, self._track2, ZipperStat, self._statClass1, self._statClass2)
#        data = XBinnerPP(data, 5)
#        for x,y in data:
#            print x,y
#        figure()
#        scatter([d[0] for d in data], [d[1] for d in data])
#        savefig(self._outputFileName)
#        results = [[result[i] for result in self._data] for i in range(2)]

 