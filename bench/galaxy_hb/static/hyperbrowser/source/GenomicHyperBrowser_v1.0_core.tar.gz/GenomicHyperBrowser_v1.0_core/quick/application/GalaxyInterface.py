# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

import functools
import os
import os.path
import sys
from urllib import unquote, quote

from gold.application.Config import DEFAULT_GENOME, VERBOSE, STATIC_REL_PATH, USE_PROFILING,\
    IS_DEVELOPER_VERSION, ORIG_DATA_PATH, VERSION #, brk
from gold.util.Profiler import Profiler
from gold.application.StatRunner import AnalysisDefJob, AssemblyGapJob
from gold.track.Track import Track
from gold.util.CommonFunctions import parseRegSpec, insertTrackNames, smartStrLower, isRedirectTrackName,\
    constructRedirectTrackName, getClassName, prettyPrintTrackName, createOrigPath, \
    generateStandardizedBpSizeText, parseShortenedSizeSpec, getOrigFn
from quick.application.ProcTrackOptions import ProcTrackOptions
from quick.application.UserBinSource import UserBinSource, UnfilteredUserBinSource, GlobalBinSource
from quick.aux.CustomTrackCreator import CustomTrackCreator, TrackViewBasedCustomTrackCreator
from quick.aux.TrackExtractor import TrackExtractor
#from quick.batch.BatchRunner import BatchRunner,SuperBatchRunner
from quick.postprocess.GlobalCollectorPP import GlobalCollectorPP
from gold.result.Results import Results
#from gold.result.ResultsViewer import ResultsViewerCollection
from quick.aux.FunctionCategorizer import FunctionCategorizer
from gold.statistic.ResultsMemoizer import ResultsMemoizer
#from gold.description.Analysis import Analysis
from gold.description.AnalysisDefHandler import AnalysisDefHandler
#from gold.description.AnalysisManager import AnalysisManager
from quick.application.ExternalTrackManager import ExternalTrackManager
from gold.description.TrackInfo import TrackInfo
from tempfile import NamedTemporaryFile
import re
from gold.util.CustomExceptions import ShouldNotOccurError, NotImplementedError, NotSupportedError#, IncompatibleTracksError
from quick.util.CommonFunctions import extractIdFromGalaxyFn, getUniqueWebPath, ensurePathExists
from gold.origdata.GenomeElementSource import GenomeElementSource
from quick.origdata.AllTracksPreProcessor import AllTracksPreProcessor
from quick.aux.OrigFormatConverter import OrigFormatConverter
#from gold.description.RunDescription import RunDescription
from quick.util.GenomeInfo import GenomeInfo
import traceback
import shutil
from copy import copy
from gold.application.LogSetup import logging, HB_LOGGER, USAGE_LOGGER, LACK_OF_SUPPORT_LOGGER, usageAndErrorLogging, runtimeLogging, logException, detailedJobRunHandler, logMessage
from gold.origdata.GEMarkRemover import GEMarkRemover
#from quick.webtools.GeneralGuiToolsFactory import GeneralGuiToolsFactory
from quick.application.SignatureDevianceLogging import takes,returns
from gold.result.HtmlCore import HtmlCore
from gold.aux.nmers.NmerManager import NmerManager
from quick.util.StaticFile import GalaxyRunSpecificFile, StaticFile

class GalaxyInterfaceAux:
    @classmethod
    def installNmerSupport(cls, genome, maxNmerLenForChains, maxNmerLenForTracks):
        #asserts to avoid unnecessarily large generation jobs (typically by mistake..)
        assert maxNmerLenForChains <= 20
        assert 4**maxNmerLenForTracks < 10000
        
        for i in range(1,maxNmerLenForChains+1):
            cls.createNmerChains(genome, i)
        for i in range(1,maxNmerLenForTracks+1):
            cls.createNmerTracks(genome, i)
            
    @staticmethod
    def createNmerChains(genome, n):
        NmerManager(genome).createNmerChains(n)

    @staticmethod
    def createNmerTracks(genome, n):
        NmerManager(genome).createNmerTracks(n)

    @staticmethod
    def createNmerTrack(genome, nmer):
        print '<pre>'
        nmerManager = NmerManager(genome)
        if nmerManager.nmerChainExists( len(nmer) ):
            print 'Creating nmer track from index chain'
            nmerManager.createNmerTrack(nmer)
        else:        
            chainOrder = nmerManager.getHighestExistingChainOrderLessThanN( len(nmer) )
            #chainOrder = 5#temp hack!!
            assert chainOrder is not None, 'no nmer data is available for this genome'
            print 'Creating nmer track (order:%i) from index chain of lower order (%i)' % (len(nmer),chainOrder)
            
            nmerManager.createNmerTrackFromLowerOrderChain(nmer, chainOrder)
        print '</pre>'

    @staticmethod
    def createGenome(genome, fullName, fastaFn, allChromosomes, extendedChromosomes, experimental=True):
        from quick.aux.CustomFuncCatalog import createGenome as cg
        cg(genome, fullName, fastaFn, allChromosomes, extendedChromosomes, experimental)
        
class GalaxyInterfaceTools:
    @staticmethod
    def updateTrackInfo(genome, trackname,description,reference,hbContact,quality,private):
        if type(trackname)==str:
            trackname = trackname.split(':')
        info = {}
        if description!=None:
            info['description'] = description
        if reference!=None:
            info['reference'] = reference
        if hbContact!=None:
            info['hbContact'] = hbContact
        if quality!=None:
            info['quality'] = quality
        if private!=None:
            info['private'] = private
        ti = TrackInfo(genome, trackname)
        ti.setAttrs(info,'batch-modified')
        ti.store()
        
    @staticmethod
    def _writePrevReg(prevReg, outFile, numGenes):
        numSkipped = 0
        if prevReg is not None:
            if numGenes <= 2:
                outFile.write('\t'.join(str(prevReg[x]) for x in xrange(3)) + os.linesep)
            else:
                numSkipped = 1
        return numSkipped
    
    @staticmethod
    def getEnsemblGenes(genome, geneList, fn):
        GalaxyInterface.getGeneTrackFromGeneList(genome, GenomeInfo.getStdGeneRegsTn(genome), geneList, fn)
        print open(fn).readlines()

    @staticmethod
    def getGeneTrackFromGeneList(genome, geneRegsTrackName, geneList, outFn):
        if type(geneList) == str:
            geneList = eval(geneList)
            assert type(geneList) in [tuple, list]
            
        geneRegsFn = getOrigFn(genome, geneRegsTrackName, '.category.bed')
        assert geneRegsFn != None
        
        ubSource = GenomeInfo.getGeneRegs(genome, geneRegsFn, categoryFilterList=geneList, cluster=False)
        ensurePathExists(outFn)
        outFile = open(outFn, 'w')
        for region in ubSource:
            outFile.write(region.source + os.linesep)
        outFile.close()
        #'\t'.join(str(x) for x in [region.chr, region.start, region.end, region.val, '0', region.strand]) + os.linesep)
        #ensemblTN = GenomeInfo.getPropertyTrackName(genome, 'ensembl')
        #TrackExtractor.extractOneTrackManyRegsToOneFile(ensemblTN, ubSource, fn, globalCoords=True, asOriginal=True, allowOverlaps=True)
    #
    #@staticmethod
    #def getGeneListOfRegulomeCluster(diseases, tfs):
    #    shelfFn = '/work/hyperbrowser/results/developer/static/maps/common/tfAndDisease2rankedGeneLists.shelf'
    #    assert all([x.split('(')[0].count('.') in [0,1] and x.count('(') in [0,1] for x in diseases.split(',')]), 'Multiple . or ( in: '+str(x)
    #    assert all([x.split('(')[0].count('.') in [0,1] and x.count('(') in [0,1] for x in tfs.split(',')]), 'Multiple . or ( in: '+str(x)
    #    
    #    diseaseList = [d.split('(')[0].split('.')[-1].strip() for d in diseases.split('|')]
    #    tfList = [t.split('(')[0].split('.')[-1].strip() for t in tfs.split('|')]
    #    return GalaxyInterface._getGeneListOfRegulomeCluster(diseaseList, tfList, shelfFn)
    #    
    #@staticmethod
    #def _getGeneListOfRegulomeCluster(diseases, tfs, geneListShelfFn, colTitle, rowTitle, hitText):
    #    print '<pre>'
    #    print 'Getting gene lists with diseases ',diseases, ' and tfs ',tfs
    #    print '#diseases: ',len(diseases), ' and #tfs: ',len(tfs)
    #    geneCounts = {}
    #    gene2diseaseSet = {}
    #    gene2tfSet = {}
    #    import shelve
    #    
    #    geneListShelf = shelve.open(geneListShelfFn,'r')
    #    for disease in diseases:
    #        for tf in tfs:
    #            geneList = geneListShelf[repr((tf.replace(' ','_').lower(), disease.lower()))]
    #            for geneTriplet in geneList:
    #                gene = geneTriplet[0]
    #                count = geneTriplet[1]
    #                if count==0:
    #                    continue
    #                
    #                if not gene in geneCounts:
    #                    geneCounts[gene] = 0
    #                    gene2diseaseSet[gene] = set([])
    #                    gene2tfSet[gene] = set([])
    #
    #                geneCounts[gene] += count
    #                gene2diseaseSet[gene].add(disease)
    #                gene2tfSet[gene].add(tf)
    #
    #    geneCountItems = geneCounts.items()
    #    sortedItems = list(reversed(sorted(geneCountItems, key=lambda t:(t[1],t[0]) )))
    #    rankedGenes = [x[0] for x in sortedItems]
    #
    #    genesOut = ', '.join(rankedGenes)
    #    countsOut = ', '.join([str(x[1]) for x in sortedItems])
    #    diseaseAssocOut = ', '.join([str(len(gene2diseaseSet[g])) for g in rankedGenes])
    #    tfAssocOut = ', '.join([str(len(gene2tfSet[g])) for g in rankedGenes])
    #
    #    headerLines = ['Ranked gene list:', \
    #                   'Corresponding total ' + hitText + ' counts:', \
    #                   'Corresponding number of ' + colTitle + ' each gene is involved with:', \
    #                   'Corresponding number of ' + rowTitle + ' each gene is involved with:']
    #    contentLines = [genesOut, countsOut, diseaseAssocOut, tfAssocOut]
    #    print '/n'.join(['%s\n%s\n' % (headerLines[i], contentLines[i]) for i in range(len(headerLines))])
    #    print '</pre>'
    #    return '<br>'.join(['<b>%s</b><br>%s<br>' % (headerLines[i], contentLines[i]) for i in range(len(headerLines))])
    #
    @staticmethod
    def getCombinedGeneList(genome, geneType1, geneType2, outFn):
        from gold.origdata.GenomeElementSource import GenomeElementSource
        from gold.util.CommonFunctions import getOrigFn
        from gold.origdata.GenomeElementSorter import GenomeElementSorter
        from gold.origdata.GEOverlapClusterer import GEOverlapClusterer
        from quick.origdata.RegionBoundaryFilter import RegionBoundaryFilter
        from gold.origdata.GECategoryFilter import GECategoryFilter
        from quick.application.UserBinSource import GlobalBinSource
        
        superTN = ['Genes and Gene Prediction Tracks', 'Genes']
        fn1, fn2 = [getOrigFn(genome, superTN + [type.replace('_', ' ')], '.bed') for type in [geneType1, geneType2]]
        for fn,genetype in [(fn1,geneType1), (fn2,geneType2)]:
            if fn is None:
                raise Exception("Path does not exist for gene name: " + genetype)
            
        genes1, genes2 = [GenomeElementSource(fn, genome) for fn in [fn1, fn2]]
        genes1, genes2 = [RegionBoundaryFilter(GEOverlapClusterer(GenomeElementSorter(geSource)), GlobalBinSource(genome))\
                          for geSource in [genes1, genes2]]
    
        allRegs = []
        for genes in [genes1, genes2]:
            allRegs += [[g.chr, g.start, g.end] for g in genes]
            
        outFile = open('/norstore_osl/hyperbrowser/data/' + outFn, 'w')
            
        numGenes = 1
        countSkipped = 0
        prevReg = None
        for reg in sorted(allRegs):
            if prevReg is not None and int(reg[1]) - int(prevReg[2]) <= 0 and prevReg[0] == reg[0]:
                if int(reg[2]) > int(prevReg[2]):
                    prevReg[2] = reg[2]
                numGenes += 1
            else:
                countSkipped += GalaxyInterface._writePrevReg(prevReg, outFile, numGenes)                
                prevReg = reg
                numGenes = 1
        countSkipped += GalaxyInterface._writePrevReg(prevReg, outFile, numGenes)
        print 'Number of genes skipped: ' + str(countSkipped)

    @staticmethod
    def convertWigBedToWigVStepFillingGaps(inFn, outFn, gapValue):
        OrigFormatConverter.convertWigBedToWigVStepFillingGaps(inFn, outFn, gapValue)
    
    @staticmethod
    def convertSegmentsToPoints(inFn, outFn, pointToUse):
        OrigFormatConverter.segments2points(inFn, outFn, pointToUse)

    @staticmethod
    def filterMarkedSegments(inFn, outFn, criteria, genome):
        if type(criteria) == str:
            criteriaFunc = eval(criteria)
        elif type(criteriaFunc) in [list,tuple]:
            criteriaFunc = lambda x: (criteria[0] is None or x>=criteria[0]) and (criteria[1] is None or x<=criteria[1])
        else:
            criteriaFunc = criteria
        OrigFormatConverter.filterMarkedSegments(inFn, outFn, criteriaFunc, genome)
    #should be refactored to instead use a geSource, which would accept both vStep and wigBed-formats etc..

    @staticmethod
    def filterSegmentsByLength(inFn, outFn, criteria):
        if type(criteria) in [list,tuple]:
            assert len(criteria) == 2
            criteriaFunc = lambda x: (criteria[0] is None or x>=criteria[0]) and (criteria[1] is None or x<=criteria[1])
        else:
            assert type(criteria) == str
            criteriaFunc = eval(criteria)
        OrigFormatConverter.filterSegmentsByLength(inFn, outFn, criteriaFunc)

    @staticmethod
    def joinTracksToCategoryTrack(catNameToTrackNameDict):
        print 'This will be joined file contents..'
        return

    
    #$createDnaBasedCustomTrack('testMit','Private:GK:test3011','21','g[0]+c[0]')
    #$createDnaBasedCustomTrack('testMit','Private:GK:test2','5','sum([g[i]+c[i] for i in winIndexes])')
    @staticmethod
    def createDnaBasedCustomTrack(genome, outTrackName, windowSize, expression, midPointIsZero=False):
        def wrappedDnaFunc(tv):
            s = tv.valsAsNumpyArray()
            
            winSize = len(s)
            winIndexes = range(winSize)            
            import numpy
            
            if midPointIsZero:
                s = numpy.append(s[winSize/2:], s[:winSize/2])
                #s[0]='c'
            a = numpy.zeros(winSize)
            c = numpy.zeros(winSize)
            g = numpy.zeros(winSize)
            t = numpy.zeros(winSize)
            n = numpy.zeros(winSize)
            
            a[s=='a'] = 1
            c[s=='c'] = 1
            g[s=='g'] = 1
            t[s=='t'] = 1
            n[s=='n'] = 1

            a[s=='A'] = 1
            c[s=='C'] = 1
            g[s=='G'] = 1
            t[s=='T'] = 1
            n[s=='N'] = 1

            #assert not 'import' in expression
            #max,min,sum,if,else ...
            #su = sum #make it local..
            #return eval(expression,{'__builtins__':[]},locals())
            #allowedWords = 'winSize,winIndexes,sum,max,min,if,else,for,in,len,range'.split(',')
            #for word in re.findall('[a-zA-Z]{2,}',expression):
            #    if not word in allowedWords:
            #        print 'Sorry, due to security concerns only a limited set of terms are allowed. Your term "%s" is not currently allowed. Please contact us if you think it should be added.' % word
            #        logging.getLogger(LACK_OF_SUPPORT_LOGGER).debug('Unsupported word encountered in createDnaBasedCustomTrack: '+word)    
            #        raise NotSupportedError
            GalaxyInterface.validateDnaBasedExpressionAndReturnError(winSize, expression, \
                                                                     raiseExceptions=True, logUnsupported=True)
            
            return eval(expression)
        
        inTrackName = GenomeInfo.getPropertyTrackName(genome, 'sequence')
        #funcStr = 'lambda s:'+expression
        #GalaxyInterface.createCustomTrack(genome, inTrackName, outTrackName, windowSize, funcStr)
        GalaxyInterface.createCustomTrack(genome, inTrackName, outTrackName, windowSize, wrappedDnaFunc)

    @staticmethod
    def validateDnaBasedExpressionAndReturnError(windowSize, expression, raiseExceptions=False, logUnsupported=False):
        try:
            winSize = int(windowSize)
        except Exception, e:
            if raiseExceptions:
                raise
            else:
                return 'Choose a valid number as the window size. Current: %s' % windowSize
            
        if winSize % 2 == 0:
            return 'The window size must be an odd number. Current: %i' % winSize
        
        winIndexes = range(winSize)
        
        if expression.strip() == '':
            return ''
        
        allowedWords = 'winSize,winIndexes,sum,max,min,if,else,for,in,len,range'.split(',')
        for word in re.findall('[a-zA-Z]{2,}',expression):
            if not word in allowedWords:
                if logUnsupported:
                    logging.getLogger(LACK_OF_SUPPORT_LOGGER).debug('Unsupported word encountered in createDnaBasedCustomTrack: '+word)
                msg = 'Sorry, due to security concerns only a limited set of terms are allowed. Your term "%s" is not currently allowed. Please contact us if you think it should be added.' % word
                if raiseExceptions:
                    print msg
                    raise NotSupportedError(msg)
                else:
                    return msg
         
        import numpy
        
        a = numpy.zeros(winSize)
        c = numpy.zeros(winSize)
        g = numpy.zeros(winSize)
        t = numpy.zeros(winSize)
        n = numpy.zeros(winSize)
        
        try:
            eval(expression)
        except Exception, e:
            if raiseExceptions:
                raise
            else:
                return e

    @staticmethod
    def createCustomTrack(genome, inTrackName, outTrackName, windowSize, func):
    #def createCustomTrack(genome, outTrackName, windowSize, funcStr):
        #print 'Lacking inTrackName, change to new method definition..'
        #inTrackName=['sequence']
        #genome = 'sacCer1'
        
        if type(outTrackName) is str:
            outTrackName = outTrackName.split(':')
        if type(windowSize) is str:
            windowSize = int(windowSize)
        
        GalaxyInterface._cleanUpTrackName(inTrackName)

        #What is this?...
        if len(outTrackName)==2 and outTrackName[1]=='':
            outTrackName = outTrackName[0].split(':')
            print 'Splitting outTN ...'
        
        if ExternalTrackManager.isGalaxyTrack(outTrackName):
            outTrackName = ExternalTrackManager.getStdTrackNameFromGalaxyTN(outTrackName)    
        
        #print 'Genome: ',genome
        #print 'TrackName out: ', outTrackName
        if type(func) is str:
            func = eval(func)
        TrackViewBasedCustomTrackCreator.createTrackGW(genome, inTrackName, outTrackName, int(windowSize), func)

    @staticmethod
    def createCustomTrackChr(genome, trackName, windowSize, funcStr, chr):
        GalaxyInterface._cleanUpTrackName(trackName)
        TrackViewBasedCustomTrackCreator.createTrackChr(genome, trackName, int(windowSize), eval(funcStr), chr)

    @staticmethod
    def createSegmentation(genome, inTrackName, outTrackName, categorizerMethodLines, minSegLen=5):
        GalaxyInterface._cleanUpTrackName(inTrackName)
        exec( os.linesep.join( ['def categorizerMethod(val,diff):'] + categorizerMethodLines) )
        FunctionCategorizer(inTrackName, categorizerMethod, genome, minSegLen).createNewTrack(outTrackName)

    @staticmethod
    def combineToTargetControl(inBedFnTarget, inBedFnControl, outWigFn):
        outF = open(outWigFn,'w')
        outF.write('track type=wiggle_0'+os.linesep)
        for mark,fn in [['1',inBedFnTarget], ['0',inBedFnControl]]:
            for line in open(fn):
                cols = line.split()
                newCols = cols[:3] +[mark]
                outF.write( '\t'.join(newCols) + os.linesep)
        outF.close()

    @staticmethod
    def startPreProcessing(genome, trackNameFilter=[]):
        if type(trackNameFilter) == str:
            trackNameFilter = trackNameFilter.split(':')
        print '<PRE>'
        AllTracksPreProcessor.process(genome, trackNameFilter)
        print '</PRE>'

    @staticmethod
    def integrateTrackFromHistory(genome, historyTrackName, integratedTrackName):
        assert ExternalTrackManager.isGalaxyTrack(historyTrackName)
        assert all(type(tn) in [list,tuple] for tn in [historyTrackName, integratedTrackName])

        GalaxyInterface._cleanUpTrackName(historyTrackName)
        
        path = createOrigPath(genome, integratedTrackName, '')
        assert not os.path.exists(path), 'Path allready exists in standardized tracks: ' + path

        galaxyFn = ExternalTrackManager.extractFnFromGalaxyTN(historyTrackName)
        suffix = ExternalTrackManager.extractFileSuffixFromGalaxyTN(historyTrackName)
        if suffix == 'customtrack':
            suffix = 'wig'
        origFn = path + 'fromHistory.' + suffix
        ensurePathExists(origFn)
        shutil.copy(galaxyFn, origFn)
        os.chmod(origFn, 0664)
        GalaxyInterface.startPreProcessing(genome, integratedTrackName)

    @classmethod
    #constructs unique id from galaxyFn and withinRunId. If this function is used several times per run, uniqueness must be ensured by using different withinRunId
    def expandBedSegmentsFromTrackNameUsingGalaxyFn(cls, inTrackName, genome, upFlank, downFlank, galaxyFn, withinRunId='1', treatTrackAs='segments', removeChrBorderCrossing=False):
        uniqueStaticId = GalaxyRunSpecificFile(['uniqueIdForExpandSegmentsMethod',withinRunId],galaxyFn).getId()
        outTrackName = GalaxyRunSpecificFile(['expandedSegments',withinRunId],galaxyFn).getExternalTrackName()
        cls.expandBedSegmentsFromTrackName(inTrackName, outTrackName, uniqueStaticId, genome, upFlank, downFlank, treatTrackAs, removeChrBorderCrossing)        
        return outTrackName

    @classmethod
    #expands segments of inTrackName to a new track with outTrackName
    def expandBedSegmentsFromTrackName(cls, inTrackName, outTrackName, uniqueStaticId, genome, upFlank, downFlank, treatTrackAs='segments', removeChrBorderCrossing=False):
        if type(inTrackName)==str:
            inTrackName = inTrackName.split(':')
        if type(outTrackName)==str:
            outTrackName = outTrackName.split(':')
        if type(uniqueStaticId)==str:
            uniqueStaticId= uniqueStaticId.split(':')
            
        #extract inTrackName to fn
        origSegsFn = StaticFile(uniqueStaticId+['inFn.bed']).getDiskPath(True)
        TrackExtractor.extractOneTrackManyRegsToOneFile(inTrackName, GlobalBinSource(genome), origSegsFn, True, False, False)        
        #construct expandedFn from outTrackName
        expandedFn = createOrigPath(genome, outTrackName, 'outFn.bed' )
        #expand segments to expandedFn
        cls.expandBedSegments(origSegsFn, expandedFn, genome, upFlank, downFlank, treatTrackAs, removeChrBorderCrossing)
        #pre-process outTrackName
        cls.startPreProcessing(genome, outTrackName)
        

    @staticmethod
    def expandBedSegments(inFn, outFn, genome, upFlank, downFlank, treatTrackAs='segments', removeChrBorderCrossing=False):
        assert int(upFlank) >= 0 or int(downFlank) >= 0
        assert treatTrackAs in ['segments', 'upstream', 'middle', 'downstream']
        upFlank, downFlank = int(upFlank), int(downFlank)
        
        ensurePathExists(outFn)
        outF = open(outFn, 'w')
        for line in open(inFn):
            cols = line.strip().split()
            chr, start, end = cols[:3]
            start, end = int(start), int(end)
            remainingLine = cols[3:]
            if len(cols)>=6:
                strand = (cols[5]=='+')
            else:
                strand = True
               
            if treatTrackAs in ['upstream', 'middle', 'downstream']:
                if (treatTrackAs =='upstream' and strand == False) or \
                    (treatTrackAs == 'downstream' and strand == True):
                    start = end - 1
                
                if treatTrackAs == 'middle':
                    start = (end + start)/2
                
                end = start + 1
            
            if strand == True:
                leftFlank, rightFlank = upFlank, downFlank
            else:
                leftFlank, rightFlank = downFlank, upFlank

            try:
                chrSize = GenomeInfo.getChrLen(genome, chr)
            except:
                chrSize = sys.maxint
                        
            assert leftFlank >= 0 or rightFlank >= 0
            if leftFlank >= 0:
                newStart = start - leftFlank
            else:
                newStart = end + leftFlank
            if rightFlank >= 0:
                newEnd = end + rightFlank
            else:
                newEnd = start - rightFlank

            if removeChrBorderCrossing and (newStart < 0 or newEnd > chrSize):
                continue

            newStart = max(0, newStart)
            newEnd = min(chrSize, newEnd)

            outF.write( '\t'.join( [chr, str(newStart), str(newEnd)] + remainingLine) + os.linesep )
        outF.close()
                
    
    #MAIN TOOLS:
    @staticmethod
    def createIntensityTrack(mainTrackName, controlTrackNameList, outTrackName, regSpec, binSpec, genome):
        GalaxyInterface._cleanUpSpecs(mainTrackName, None, genome, True)
        for i in range(len(controlTrackNameList)):
            GalaxyInterface._cleanUpTrackName(controlTrackNameList[i])
        
        if type(outTrackName)==str:
            outTrackName = outTrackName.split(':')
        
        if ExternalTrackManager.isGalaxyTrack(outTrackName):
            outTrackName = ExternalTrackManager.getStdTrackNameFromGalaxyTN(outTrackName)
        
        userBinSource = GalaxyInterface._getUserBinSource(regSpec, binSpec, genome)
        
        
        if len(controlTrackNameList)==1:
            job = AnalysisDefJob('[dataStat=SimpleBpIntensityStat] [outTrackName=' + '|'.join(outTrackName) + '] [numDiscreteVals=10] -> CreateFunctionTrackStat', \
                                 controlTrackNameList[0], mainTrackName, userBinSource)
        else:
            encodedControlTrackNameList = '||'.join(['|'.join(tn) for tn in controlTrackNameList])
            job = AnalysisDefJob('[dataStat=BpIntensityStat] [outTrackName=' + '|'.join(outTrackName) + '] [numDiscreteVals=10]'+\
                                 '[reducedNumDiscreteVals=10] [controlTrackNameList=' + encodedControlTrackNameList + '] -> CreateFunctionTrackStat', \
                                  mainTrackName, None, userBinSource)
        
        print str(HtmlCore().styleInfoBegin(styleClass='debug'))
        job.run()
        
        core = HtmlCore()
        core.styleInfoEnd()
        core.paragraph('This history element contains pre-processed track data.')
        controlTnStrList = [prettyPrintTrackName(tn) for tn in controlTrackNameList]
        core.paragraph('An intensity track has been created for the track %s, controlled for possible confounders in the following tracks : %s' \
            % ( prettyPrintTrackName(mainTrackName), ', '.join(controlTnStrList[:-1]) + (' and ' if len(controlTnStrList) > 1 else '') + controlTnStrList[-1]) )
        core.paragraph('This custom track can be analyzed by selecting this history element as one of the input tracks of an analysis.')
        print core
        
        
    @staticmethod
    def _getExtractionOptionsFromFormat(extractionFormat):
        if extractionFormat.lower().startswith('segments, possibly overlapping'):
            asOriginal, allowOverlaps = False, True
        elif any(x in extractionFormat.lower() for x in ['clustered', 'function', 'partition']):
            asOriginal, allowOverlaps = False, False
        elif extractionFormat.lower().startswith('original file format'):
            asOriginal, allowOverlaps = True, True
        else:
            raise ShouldNotOccurError()
        return asOriginal, allowOverlaps
        
    @staticmethod
    def extractTrackManyBins(genome, trackName, regSpec, binSpec, globalCoords, extractionFormat, fn):
        ##print 'parse'
        #GalaxyInterface._cleanUpTrackName(trackName)
        trackName = GalaxyInterface._cleanUpSpecs(trackName, None, genome, True)[0]
        bins = GalaxyInterface._getUserBinSource(regSpec,binSpec,genome)
        #print 'extract'
        #reg = parseRegSpec(regSpec)
        #TrackExtractor.extract(trackName, reg, fn)
        #TrackExtractor.extract(trackName, reg, fn)
        asOriginal, allowOverlaps = GalaxyInterface._getExtractionOptionsFromFormat(extractionFormat)
        TrackExtractor.extractOneTrackManyRegsToOneFile(trackName, bins, fn, globalCoords, asOriginal, allowOverlaps)
 
    @staticmethod
    def extractTrackManyBinsToRegionDirsInZipFile(genome, trackName, regSpec, binSpec, globalCoords, extractionFormat, galaxyFn):
        #GalaxyInterface._cleanUpTrackName(trackName)
        trackName = GalaxyInterface._cleanUpSpecs(trackName, None, genome, True)[0]
        bins = GalaxyInterface._getUserBinSource(regSpec,binSpec,genome)
        asOriginal, allowOverlaps = GalaxyInterface._getExtractionOptionsFromFormat(extractionFormat)
        zipBaseFn = trackName[-1].replace(' ','_') + '.extract.zip'
        zipFile = GalaxyRunSpecificFile([zipBaseFn], galaxyFn)
        TrackExtractor.extractOneTrackManyToRegionFilesInOneZipFile(trackName, bins, zipFile.getDiskPath(), globalCoords, asOriginal, allowOverlaps, ignoreEmpty=True)
        
        core = HtmlCore()
        core.paragraph('This history element contains data extracted from the track %s.' % prettyPrintTrackName(trackName))
        core.paragraph('The data is extracted as %s, %s' %
                       (extractionFormat[0].lower() + extractionFormat[1:], bins.description[0].lower() + bins.description[1:]))
        core.paragraph('The data is compressed into this Zip file: %s' % zipFile.getLink(zipBaseFn))
        print core
        
        
    @staticmethod
    def generateGoogleMapFromHistoryResult(galaxyFn):        
        print 'Her kommer tool for aa lage regulom..'
        
        id = extractIdFromGalaxyFn(galaxyFn)
        mapName = '_'.join(['Usermap'] + id)

#    @staticmethod
#    def getWebToolGuiPrototype(toolId):
#        return GeneralGuiToolsFactory.getWebTool(toolId)
        #if toolId == 'hb_generic_1':
        #    return GeneralGuiToolsFactory.getWebTool("tool1")
        #if toolId == 'hb_generic_2':
        #    from test.sandbox.div.Lomes import HbPrototypeGui
        #    return HbPrototypeGui()
        #if toolId == 'hb_generic_3':
        #    from test.sandbox.div.DraftGuiPrototyper import HbPrototypeGui
        #    return HbPrototypeGui()
        #raise Exception('no such prototype: ' + toolId)
            
    
class GalaxyInterface(GalaxyInterfaceTools, GalaxyInterfaceAux):
    ALL_SUBTYPES_TEXT = '-- All subtypes --'
    APPEND_ASSEMBLY_GAPS = True
    APPEND_COUNTS = True
    
    @staticmethod
    @runtimeLogging    
    def getMainTrackNames(genome, preTracks=[], postTracks=[], username=''):
        #return ['HPV_200kb, allTss']
        #return ProcTrackOptions().getMainTypes(extraTracks)
        fullAccess = GalaxyInterface._userHasFullAccess(username)
        tracks = ProcTrackOptions.getSubtypes(genome, [], fullAccess)
        opts = []
        for track in tracks:
            opts.append((track, track, False))
        return preTracks + opts + postTracks
    
    @staticmethod
    @runtimeLogging        
    def getSubTrackNames(genome, parentTrack, deep=True, username=''):
        ##temporary hack to test nmer funcitonality!!:
        #if parentTrack==['Sequence','Nmers','6-mers']:
        #    return [('aaaaaa','aaaaaa',False),('caaaaa','caaaaa',False)]
        #
        
        assert (not deep)
        fullAccess = GalaxyInterface._userHasFullAccess(username)
        
        tracks = ProcTrackOptions.getSubtypes(genome, parentTrack, fullAccess)
        if len(tracks) > 0 and ProcTrackOptions.isValidTrack(genome, parentTrack, fullAccess):
            tracks += [GalaxyInterface.ALL_SUBTYPES_TEXT]
        
        opts = []
        for track in tracks:
            opts.append((track, track, False))
        
        return opts
        
    @staticmethod
    def _userHasFullAccess(username):
        return username in ['geirkjetil@gmail.com','morj@rr-research.no','ehovig@ifi.uio.no','geirkjetil@gmail.com','morj@medisin.uio.no','halfdan.rydbeck@rr-research.no','lundandersen@gmail.com','sveinugu@gmail.com','hrydbeck@gmail.com','Marit.Holden@nr.no','tlavelle@rr-research.no','eivindto@math.uio.no','vegardny@radium.uio.no','kristian@bioinfo.hr','trevor.clancy@rr-research.no','stale.nygard@medisin.uio.no','hiepln@ifi.uio.no','eivindgl@student.matnat.uio.no','jonaspau@ifi.uio.no','finn.drablos@ntnu.no','oyvind.overgaard@gmail.com','trengere@gmail.com']
    
    @staticmethod
    def getSupportedGalaxyFileFormats():
        return ExternalTrackManager.getSupportedFileSuffixes()
    
    @staticmethod
    @runtimeLogging        
    def getStatOptions(genome, trackName1, trackName2, mainCategory):
        try:
            realPreProc = False
            trackName1, trackName2 = GalaxyInterface._cleanUpSpecs(trackName1, trackName2, genome, realPreProc)[0:2]

            #GalaxyInterface._cleanUpTrackNames(trackName1, trackName2)
            if not GalaxyInterface.areTrackNamesValid(genome, trackName1, trackName2):
                return []
            
            #trackName1 = GalaxyInterface._handleHistoryTrack(trackName1, '1')
            #trackName2 = GalaxyInterface._handleHistoryTrack(trackName2, '2')
                            
            opts = []
            from gold.description.AnalysisManager import AnalysisManager
            for subCategory in AnalysisManager.getSubCategoryNames(mainCategory):
                fullCategory = AnalysisManager.combineMainAndSubCategories(mainCategory, subCategory)
                subCatAnalyses = []
                for analysis in AnalysisManager.getValidAnalysesInCategory(fullCategory, genome, trackName1, trackName2):
                    #print 'analysisDef: ', analysis.getDef(), '<br>'
                    subCatAnalyses.append([str(analysis).split(':')[0] , quote( ('_' if analysis._reversed else '') + analysis.getDef(), ''), False])
                if len(subCatAnalyses)>0:
                    opts.append( [subCategory, '', True])
                    opts += sorted(subCatAnalyses, key=smartStrLower)
            return opts
        except Exception,e:
            logException(e)
            return []
        
    #@staticmethod
    #def _handleHistoryTrack(tn, trackNum):
    #    if len(tn)==4 and tn[0].lower() == 'galaxy':
    #        fn = ExternalTrackManager.extractFnFromGalaxyTN(tn)
    #        suffix = ExternalTrackManager.extractFileSuffixFromGalaxyTN(tn)
    #        assert(externalType in suffix for externalType in ['wig','bed','customtrack'])
    #        
    #        geSource = ExternalTrackManager.getGESource(fn, suffix)
    #        return constructRedirectTrackName([getClassName(geSource)], 'ModelsForExternalTracks', 'chr21', 'Track'+trackNum+'-elements')
    #    else:
    #        return tn

    @staticmethod
    def _prepareRunLogging(analysisDef, regSpec, binSpec):
        #logMessage('run: ' + regSpec + ' ' + binSpec + ' ' + analysisDef)
        logging.getLogger(HB_LOGGER).addHandler(detailedJobRunHandler)
    
    @staticmethod
    def _prepareRun(trackName1, trackName2, analysisDef, regSpec, binSpec, genome=DEFAULT_GENOME, trackNameIntensity=[], **kwArgs):
        userBinSource = GalaxyInterface._getUserBinSource(regSpec,binSpec,genome)
        
        #print '<div class="debug">Corresponding batch-run line:<br>' + \
            #GalaxyInterface._revEngBatchLine(trackName1, trackName2, analysisDef, regSpec, binSpec, genome) + '<br><br>'

        # fixme: Temporary hack, so that CompBinSplitting can be turned off in most cases.
        if any(x in analysisDef for x in ['CategoryDivergenceMatrixStat', 'CategoryPointCountInSegsMatrixStat']):
            import gold.util.CompBinManager
            gold.util.CompBinManager.CompBinManager.ALLOW_COMP_BIN_SPLITTING = True

        fullRunArgs = {}
        if trackNameIntensity not in [[],None]:
            fullRunArgs['trackNameIntensity'] = '|'.join(trackNameIntensity)
        return userBinSource, fullRunArgs
 
    @staticmethod
    def _handleRunResult(res, runDescription, userBinSource, genome, galaxyFn): 
        assert(res is not None)
        
        presCollectionType = res.getPresCollectionType()

        if len(res.getResDictKeys()) > 0 and GalaxyInterface.APPEND_ASSEMBLY_GAPS and presCollectionType=='standard':
            gapRes = AssemblyGapJob(userBinSource, genome).run()
            res.includeAdditionalResults(gapRes, ensureAnalysisConsistency=False)

        #if len(res.getResDictKeys()) > 0 and GalaxyInterface.APPEND_COUNTS:
        #    try:
        #        countRes = CountBothTracksJob(userBinSource).run()
        #        res.includeAdditionalResults(countRes, ensureAnalysisConsistency=False)
        #    except IncompatibleTracksError:
        #        pass
        
        core = HtmlCore()
        core.line('Generating result figures and tables..')
        core.styleInfoEnd()
        print core
        
        #print runDescription
        core = HtmlCore()
        core.styleInfoBegin(styleId='run_description', styleClass='infomessagesmall rundescription')
        core.line(runDescription)
        core.styleInfoEnd()
        runDescriptionBox = str(core)
        
        res.setRunDescription(runDescriptionBox)

        if USE_PROFILING:
            profiler = Profiler()
            profiler.run('GalaxyInterface._viewResults([res], galaxyFn)', globals(), locals())
            profiler.printStats()
        else:
            GalaxyInterface._viewResults([res], galaxyFn)

#        adj._endProgress()
                    
       
    @staticmethod
    @usageAndErrorLogging
    #@takes(list,list,str,str,str,str,str,list,str)
    def run(trackName1, trackName2, analysisDef, regSpec, binSpec, genome=DEFAULT_GENOME, galaxyFn=None, trackNameIntensity=[], userName=None, **kwArgs):

        GalaxyInterface._prepareRunLogging(analysisDef, regSpec, binSpec)
        print str(HtmlCore().styleInfoBegin(styleClass='debug'))
        runDescription = GalaxyInterface.getRunDescription(trackName1, trackName2, analysisDef, regSpec, binSpec, genome, userName)
        trackName1, trackName2, analysisDef, trackNameIntensity = GalaxyInterface._cleanUpSpecs(trackName1, trackName2, genome, True, analysisDef, trackNameIntensity)
        userBinSource, fullRunArgs = GalaxyInterface._prepareRun(trackName1, trackName2, analysisDef, regSpec, binSpec, genome, trackNameIntensity, **kwArgs)
        res = AnalysisDefJob(analysisDef, trackName1, trackName2, userBinSource, **fullRunArgs).run()
        GalaxyInterface._handleRunResult(res, runDescription, userBinSource, genome, galaxyFn)

        return res

    @staticmethod
    def getHelpText(topic):
        HELP_TEXTS = {'track1':'Select the first genome annotation track to analyse. Start by selecting category and then specific tracks.',
                      'track2':'Select the second genome annotation track to analyse. Select "No track" if a single-track analysis is desired.',
                      'analysis':'Select which analysis to perform on your track(s). The analyses are ordered as hypothesis tests or descriptive statistics. '\
                      'The shortcuts for track type are as follows - UP: unmarked points, US: unmarked segments, MP: marked points, MS: marked segments, F: function.',
                      'trackType':'Select how to treat your track data, either in their original formats or converted to simplified representations (e.g. points instead of segments).',
                      'options':'Customize null hypothesis, alternative hypothesis and other options associated with the analysis.',                      
                      'binning':'Select the region of the genome in which to analyze and/or how the analysis region should be divided into bins.',
                      'trackIntensity':'Select an intensity track (created on the basis of confounding tracks) that is to be controlled for in the analysis.'}
        text = HELP_TEXTS.get(topic)
        if text is None:
            return ''
        else:
            return text

    
    @staticmethod
    def isNmerTrackName(genome, tn):
        nmerTn = GenomeInfo.getNmerTrackName(genome)
        return tn is not None and tn[0:len(nmerTn)] == nmerTn and type(tn[-1]) is str and len(tn[-1])>0
    
    @staticmethod
    def _cleanUpSpecs(trackName1, trackName2, genome, realPreProc, analysisDef='', trackNameIntensity=[]):
        #GalaxyInterface._cleanUpTrackNames(trackName1, trackName2, trackNameIntensity)
        GalaxyInterface._cleanUpTrackName(trackName1)
        GalaxyInterface._cleanUpTrackName(trackName2)
        GalaxyInterface._cleanUpTrackName(trackNameIntensity)
        
        if len(analysisDef) > 0:
            analysisDef = unquote(analysisDef.replace('X','%'))

            if analysisDef[0] == '_':
               analysisDef = analysisDef[1:]
               trackName1, trackName2 = trackName2, trackName1 
                
        #print 'galaxyFn: ', galaxyFn
        #print regSpec,binSpec
        #nmerTn = GenomeInfo.getNmerTrackName(genome)
        tnList = [trackName1, trackName2, trackNameIntensity] 
        for i,tn in enumerate(tnList):
            #logMessage('statOpt: '+str(tn))

            #print 'TrackName from Galaxy:', tn
            if ExternalTrackManager.isGalaxyTrack(tn):
            #if len(tn)>0 and 'galaxy' == tn[0].lower(): #and \
                #not ExternalTrackManager.checkIfGalaxyTNPreProcessed(tn):
                #logMessage(str(tn))
                assert os.sep not in tn[-1], 'History element name contains %s: %s' % (os.sep, tn[-1])
                if realPreProc:
                    preProcessedTrackName = ExternalTrackManager.getPreProcessedTrackFromGalaxyTN(genome, tn)
                    tnList[i] = preProcessedTrackName
                #newTn = ExternalTrackManager.mapGalaxyTrackNameToStd(tn)
                #fn = ExternalTrackManager.extractFnFromGalaxyTN(tn)
                #ExternalTrackManager.preProcess(fn, newTn)
                else:
                    fn = ExternalTrackManager.extractFnFromGalaxyTN(tn)
                    suffix = ExternalTrackManager.extractFileSuffixFromGalaxyTN(tn)
                    #assert(suffix == externalType for externalType in ['wig','bed','customtrack'])
                    
                    geSource = ExternalTrackManager.getGESource(fn, suffix)
                    #trackNum = str(i+1)
                    tnList[i] = constructRedirectTrackName([getClassName(geSource)], 'ModelsForExternalTracks', 'chr21', tn[-1])#'Track'+trackNum+'-elements')
            elif GalaxyInterface.isNmerTrackName(genome, tn):
                tn[-1] = tn[-1].lower()
                nmer = tn[-1]
                if not tn[-2].endswith('-mers'):
                    tn = tn[0:-1] + [str(len(nmer))+'-mers'] + tn[-1:]
                tnList[i] = tn
                if not ProcTrackOptions.isValidTrack(genome, tn, True):
                    #print genome, tn
                    if realPreProc:
                        from gold.aux.nmers.NmerTools import NmerTools
                        assert NmerTools.isNmerString(nmer), NmerTools.getNotNmerErrorString(nmer)
                        GalaxyInterface.createNmerTrack(genome, nmer)
                        #nmerManager = NmerManager(genome)
                        #if nmerManager.nmerChainExists( len(nmer) ):
                        #    nmerManager.createNmerTrack(nmer)
                        #else:
                        #    chainOrder = nmerManager.getHighestExistingChainOrderLessThanN( len(nmer) )
                        #    assert chainOrder is not None, 'no nmer data is available for this genome'
                        #    nmerManager.createNmerTrackFromLowerOrderChain(nmer, chainOrder)
                    else:                            
                        tnList[i] = constructRedirectTrackName([NmerManager.GE_SOURCE.__name__], 'ModelsForExternalTracks', 'chr21', 'nmer')                    
        trackName1, trackName2, trackNameIntensity = tnList
        
        return trackName1, trackName2, analysisDef, trackNameIntensity
    
    @staticmethod
    @runtimeLogging        
    def runValid(trackName1, trackName2, statClassName, regSpec, binSpec, genome=DEFAULT_GENOME, galaxyFn=None, **kwArgs):
        #logMessage('runValid: ' + regSpec + ' ' + binSpec)
        #print 'runValidGenome: ',genome
        #print 'VALID: ',regSpec,binSpec
        #if 'tull' in regSpec:
        #    return 'Error: tull as input'
        #else:
        #    return True
        #
    
        #GalaxyInterface._cleanUpTrackNames(trackName1, trackName2)
        realPreProc = False
        trackName1, trackName2, dummy, trackNameIntensity = GalaxyInterface._cleanUpSpecs(trackName1, trackName2, genome, realPreProc, trackNameIntensity=kwArgs.get('trackNameIntensity'))

        for tn in (trackName1, trackName2, trackNameIntensity):
            if not GalaxyInterface.isTrackNameValid(genome, tn):
                if VERBOSE:
                    logMessage('Invalid Trackname: ' + str(genome) + ' - ' + str(tn) )
                return 'There was a problem with the track ' + prettyPrintTrackName(tn) + ', please select a different track.'
        #for tn in (trackName1,trackName2):
        #    if tn not in [None,[]] and \
        #        not ExternalTrackManager.isExternalTrack(tn) and \
        #        TrackInfo(genome, tn).timeOfPreProcessing is None:
        #            return 'There was a problem with the track ' + prettyPrintTrackName(tn) + ', please select a different track.'
            
        if len(statClassName) == 0 or statClassName in [None,'None']:
            return 'No statistic selected: select a statistic or try a different combintion of tracks'
    
        try:
            if regSpec not in ['wig','bed','customtrack','__chrs__','__chrArms__','__chrBands__','__genes__'] and binSpec != '*':
                GalaxyInterface._getUserBinSource('chr1',binSpec, genome)
                #assert( int(binSpec) > 0)
        except Exception,e:
            #logException(e, level=logging.WARNING)
            return "Binsize has to be specified either as '*' or as a positive number (with k and m denotes thousand and million bps, respectively): " + str(binSpec)
        
        try:
            GalaxyInterface._getUserBinSource(regSpec,binSpec,genome)
        except Exception, e:
            #logException(e)
            return "Error in specification of analysis region. Use '*' or make specification in the same format of UCSC genome browser. Genome may be added first using a colon, e.g. as 'NCBI36:chr1:1-1000'"
        
        return True
    
    @staticmethod
    def areTrackNamesValid(genome, trackName1, trackName2):
        for tn in (trackName1,trackName2):
            if not GalaxyInterface.isTrackNameValid(genome, tn):
                return False
        return True

    @staticmethod
    def isTrackNameValid(genome, tn):
        if tn not in [None,[]] and \
                not ExternalTrackManager.isHistoryTrack(tn) and \
                TrackInfo(genome, tn).timeOfPreProcessing is None:
            return False
        else:
            return True
        
    @staticmethod
    @usageAndErrorLogging
    def runBatchLines(batchLines, galaxyFn=None, genome=DEFAULT_GENOME, username=''):
        print 'Running batch, with script: '
        print os.linesep.join(batchLines)
        print ''
        toolLines = []
        analysisLines = []
        
        for line in batchLines:
            line = line.strip()            
            if line == '' or line[0] == '#':
                continue
            elif line[0] == '$':
                toolLines.append(line[1:])
            else:
                assert len(line.split()) in [4,5], 'Error, expected 4 or 5 columns: ' + str(line.split())
                analysisLines.append(line)
                    
        if len(analysisLines) == len(toolLines) == 0:
            raise Exception('Error, no line with content supplied.. Expected run-specs with 5 (super-batch) or 6 (std batch) columns: ')

        logging.getLogger(HB_LOGGER).addHandler(detailedJobRunHandler)

        if len(toolLines) > 0:
            for line in toolLines:
                import time
                startTime = time.time()

                print 'Running tool line: ',line
                #try:
                res = eval('GalaxyInterface.' + line, globals(), locals())
                print 'Result: ', res
                print 'Time spent executing line %s: %.1f seconds' % (line, time.time()-startTime)
                #except Exception,e:
                    #print 'Error, invalid line: ' + line
                    #print 
        
        if len(analysisLines) > 0:
            from quick.batch.BatchRunner import SuperBatchRunner
            res = SuperBatchRunner.runManyLines(analysisLines, genome, True)            
            GalaxyInterface._viewResults(res, galaxyFn)           
            return res
        return True
        
    #get classes to extract a x/y-value from track in each user bin
    @staticmethod
    def getSummarizerStatOptions(trackName):
        return 'DummyClassName'
 
    @staticmethod
    def getTrackExtractionOptions(genome, trackName):
        #determine extractionFormat        
        #determine filetype
        GalaxyInterface._cleanUpTrackName(trackName)
        ti = TrackInfo(genome, trackName)
        
        if 'function' in ti.trackFormatName.lower():
            return [('Function (format: customtrack)','customtrack')]
        elif 'partition' in ti.trackFormatName.lower():
            return [('Partition (format: customtrack)','customtrack')]
        else:
            basicFormats = (['Segments, possibly overlapping'] if not GalaxyInterface.isNmerTrackName(genome, trackName) else []) \
                + ['Segments, any overlaps clustered']
            #newFileType = 'bed' if (ti.markType is not None and ti.markType.lower() == 'category') else 'wig'
            #newFileType = ti.fileType.split('.')[-1]
            newFileType = 'bed' if (ti.markType in [None,''] or ti.markType.lower() in ['category','microarray']) else 'customtrack'
            extractionFormats = [(x + ' (format: %s)' % newFileType, newFileType) for x in basicFormats]
            if ('unmarked' in ti.trackFormatName.lower() and ti.fileType not in [None, '']) or ti.fileType in ['marked.bed'] or \
                any((x in ti.markType.lower()) for x in ['category', 'microarray', 'meansd', 'mapping', 'population']): #fixme: Not very understandable, Should be refactored
                extractionFormats = [ ('Original file format (%s)' % ti.fileType, ti.fileType) ] + extractionFormats
            return extractionFormats        
        
    @staticmethod
    def isRScriptValid(trackName1, trackName2, rScriptAnalysisId):
        GalaxyInterface._cleanUpTrackName(trackName1)
        GalaxyInterface._cleanUpTrackName(trackName2)
        return True #currently, until it works all correctly...
        if any([tn[0].lower() == 'galaxy' and len(tn)==4 for tn in (trackName1, trackName2) if len(tn)>0] ):
            return True
        #analysis = Analysis(rScriptAnalysisId)
        #analysis.setTracks(trackName1, trackName2)
        #return analysis.isValid()

    @staticmethod
    def getTrackTypeOptions(analysisDef):
        #print 'From Morten: ',analysisDef
        analysis = AnalysisDefHandler(unquote(analysisDef))        
        #return q.getOptionLabelsAsText(), q.getOptionsAsText()
        #trackTypeKeys = [ x for x in ['tf1','tf2'] if x in analysis.getChoices().keys() ]
        return [analysis.getFormatConverterOptionLabelsAsText(), analysis.getFormatConverterOptionsAsText()]
#        raise Exception(str(a) + ' ' + str(optionLabelKeys))
        return a
        #assert False, str(q.getOptionLabelsAsText() ) + ' - ' + str(q.getOptionsAsText())
        #return q.getOptionLabelsAsText()[0:1], {a: q.getOptionsAsText()[a]}

    @staticmethod
    def getConfigOptions(analysisDef):
        analysis = AnalysisDefHandler(unquote(analysisDef))
        return [analysis.getInterfaceOptionLabelsAsText(), analysis.getInterfaceOptionsAsText()]
        #print 'From Morten: ',analysisDef
        #q = AnalysisDefHandler(unquote(analysisDef))
        #ret = [q.getOptionLabelsAsText(), q.getOptionsAsText()]
        #a = ret[0][0]
        #ret[0] = ret[0][1:]
        #del ret[1][a]
        #return ret
    
    #@staticmethod
    #def getConfigOptions(analysisDef):
    #    #print 'From Morten: ',analysisDef
    #    q = AnalysisDefHandler(unquote(analysisDef))
    #    return q.getOptionLabelsAsText(), q.getOptionsAsText()
        
    @staticmethod
    def setConfigChoices(analysisDef, optionsDict):
        intensityTrigger = '_intensityTN'
        if intensityTrigger in optionsDict:
            print 'HANDLING INTENSITY TRACK..'
            intensityTN = optionsDict[intensityTrigger]
            optionsDict = copy(optionsDict)
            del optionsDict[intensityTrigger]
            intensityPrefix = '[' + intensityTrigger + '=' + intensityTN + ']'
        else:
            intensityPrefix = ''

        try:
            q = AnalysisDefHandler(unquote(analysisDef))
            for labelText in optionsDict:
                q.setChoice( unquote(labelText), unquote(optionsDict[labelText]) )
            q.syncH1WithTail()
            return intensityPrefix + q.getDefAfterChoices()
                
        except Exception, e:
            logException( e, message='Error in setConfigChoices with resulting definition: ' + q.getDefAfterChoices() )
            return ''
    #    
    #@staticmethod   
    #def _syncH1WithTail(analysisDef):
    #    optionKeys = analysisDef.getAllOptionsAsKeys()
    #    if 'H1' in optionKeys and 'tail' in optionKeys:
    #        try:
    #            tailChoice = analysisDef.getChoice('tail')                
    #            analysisDef.setChoice('H1', tailChoice)
    #        
    #        except (ShouldNotOccurError), e:
    #            logException(e, logging.WARNING,'Could not find H1, probably mismatch between tail and H1 in analysisDef (tail choice: %s)' % self.getChoice('tail') )                
    #        except Exception, e:
    #            logException(e, logging.WARNING,'Could not find H1')
    #    
    #    return analysisDef
    
    @staticmethod
    def getTextFromAnalysisDef(analysisDef, genome, trackName1, trackName2):
        realPreProc = False
        trackName1, trackName2, analysisDef = GalaxyInterface._cleanUpSpecs(trackName1, trackName2, genome, realPreProc, analysisDef)[0:3]
        from gold.description.Analysis import Analysis
        text = str( Analysis(analysisDef, genome, trackName1, trackName2) )
        return AnalysisDefHandler.splitAnalysisText(text)[1]
        #return text[ text.find(':')+1 :]
        #return text.split(':')[-1]
        
    @staticmethod
    @takes(str, list)
    @returns(str)
    def getTrackInfo(genome, trackName):
        #genome ='NCBI36'
        #return 'further info on ' + ':'.join(trackName) + ' will come..'
        #try:
        GalaxyInterface._cleanUpTrackName(trackName)
        return str(TrackInfo(genome, trackName))
        #except Exception,e:
        #    traceback.print_exc()
        #    brk(host='localhost', port=9000, idekey='galaxy')
        #    return str(e.__class__) + str(e) + str(trackName) + str(genome)
        
    @staticmethod
    @returns(str)
    def getHbVersion():
        return VERSION

    @staticmethod
    @runtimeLogging        
    def getRunDescription(trackName1, trackName2, analysisDef, regSpec, binSpec, genome=DEFAULT_GENOME, userName=None, trackNameIntensity=[]):
        #logMessage('getRunDescription: ' + regSpec + ' ' + binSpec + ' ' + analysisDef)
        #assert userName != None

        #Clean up and if necessary switch tracknames:
        #trackName1, trackName2, analysisDef, dummy = GalaxyInterface._handleSpecs(trackName1, trackName2, analysisDef, genome)
        
        #analysisDef = unquote(analysisDef.replace('X','%'))
        #GalaxyInterface._cleanUpTrackNames(trackName1, trackName2, trackNameIntensity)
        #trackName1 = GalaxyInterface._handleHistoryTrack(trackName1, '1')
        #trackName2 = GalaxyInterface._handleHistoryTrack(trackName2, '2')
        #
        #if analysisDef[0] == '_':
        #    analysisDef = analysisDef[1:]
        #    trackName1, trackName2 = trackName2, trackName1
        realPreProc = False
        trackName1, trackName2, analysisDef, trackNameIntensity = GalaxyInterface._cleanUpSpecs(trackName1, trackName2, genome, realPreProc, analysisDef, trackNameIntensity)
        try:
            userBinSource = GalaxyInterface._getUserBinSource(regSpec, binSpec, genome)
            if GalaxyInterface._userHasFullAccess(userName):
                revEngBatchLine = GalaxyInterface._revEngBatchLine(trackName1, trackName2, analysisDef, regSpec, binSpec, genome)
            else:
                revEngBatchLine = None
        except:
            revEngBatchLine = None
            
        from gold.description.RunDescription import RunDescription
        return RunDescription.getRunDescription(trackName1, trackName2, analysisDef, userBinSource, revEngBatchLine)
    
    #@staticmethod
    #def getAnalysisInfo(analysisDef):
    #    return 'further info on ' + str( Analysis(analysisDef) ) + ' will come..'

    #@staticmethod
    #def getBinningInfo(regSpec, binSpec):
    #    return 'further info on ' + regSpec + ', ' + binSpec + ' will come..'
    
    @staticmethod
    def getAnalysisCategories(genome):
        from gold.description.AnalysisManager import AnalysisManager
        catNames = AnalysisManager.getMainCategoryNames()
        return [ (c,c,False) for c in reversed(sorted(catNames, key=smartStrLower)) ]
    
    @staticmethod
    def getValidAnalysisDefFromTitle(analysisTitle, genome, trackName1, trackName2):
        GalaxyInterface._cleanUpTrackName(trackName1)
        GalaxyInterface._cleanUpTrackName(trackName2)
        from gold.description.AnalysisManager import AnalysisManager
        return quote(AnalysisManager.getValidAnalysisDefFromTitle(unquote(analysisTitle), genome, trackName1, trackName2), '')
        
    @staticmethod
    def getAnalysisList(genome, category, trackName1, trackName2):
        return GalaxyInterface.getStatOptions(genome, trackName1, trackName2, category)

    @staticmethod
    def getTrackInfoRecord(genome, trackName):
        GalaxyInterface._cleanUpTrackName(trackName)
        return TrackInfo(genome, trackName).getUIRepr()
    
    @staticmethod
    def setTrackInfoRecord(genome, trackName, attrDict, allSubtypes, userName):
        GalaxyInterface._cleanUpTrackName(trackName)
        if allSubtypes:
            if ProcTrackOptions.isValidTrack(genome, trackName):
                GalaxyInterface.setTrackInfoRecord(genome, trackName, attrDict, False, userName)

            subTypes = ProcTrackOptions.getSubtypes(genome, trackName)
            for subType in subTypes:
                GalaxyInterface.setTrackInfoRecord(genome, trackName + [subType], attrDict, True, userName)
        
        else:
            trackInfo = TrackInfo(genome, trackName)
            trackInfo.setAttrs(attrDict, userName)
            trackInfo.store()
    
    @staticmethod
    def _getName(genome, experimental=False):
        nameFn = createOrigPath(genome, [], '_name.txt' if experimental else '#name.txt')
        if os.path.exists(nameFn):
            return open(nameFn, 'r').read().strip()
        return None
    
    @staticmethod
    def getAllGenomes():
        "returns list of genome types in hb. Not sure about the last boolean entry?"
#        genomes = [('Human Mar. 2006 (hg18/NCBI36)','hg18',False), ('Mouse July 2007 (mm9)','mm9',False), \
#                ('Mouse Feb. 2006 (mm8)','mm8',False), ('Saccharomyces cerevisiae June 2009 (Ensembl: SGD1.01)','sacCer1',False), \
#                ('Schizosaccharomyces pombe Aug 2007 (Ensembl: EF1)','pombe2007',False)]
#        if IS_DEVELOPER_VERSION:
#            genomes.append(('Test based on human chrM  used as chr1..','testMit',False))
        genomeDir = ORIG_DATA_PATH
        candidateGenomes = sorted([fn for fn in os.listdir(genomeDir) if \
                                    os.path.isdir(genomeDir + os.sep + fn) \
                                    and not os.path.islink(genomeDir + os.sep + fn)], key=str.lower)
        genomes = []
        for candidate in candidateGenomes:
            #logMessage('Candidate: %s' % candidate)
            name = GalaxyInterface._getName(candidate)
            #logMessage('Name: %s' % name)
            if name is None and IS_DEVELOPER_VERSION:
                name = GalaxyInterface._getName(candidate, experimental=True)
            if name is not None:
                genomes.append((name, candidate, False))

        #logMessage('Genomes: %s' % genomes)
        return genomes
    
    #@staticmethod
    #def _getUserBinSource(regSpec,binSpec,genome):
    #    if regSpec == '__chrs__':
    #        fn = createOrigPath(genome, ['Mapping and Sequencing Tracks','_Chromosomes'],'chromosomes.category.bed')
    #    elif regSpec == '__chrArms__':
    #        fn = createOrigPath(genome, ['Mapping and Sequencing Tracks','Chromosome arms'],'ucscChrArms.category.bed')
    #    elif regSpec == '__chrBands__':
    #        fn = createOrigPath(genome, ['Mapping and Sequencing Tracks','Chromosome bands'],'ucscChrBands.category.bed')
    #    else:
    #        return UserBinSource(regSpec,binSpec,genome)
    #
    #    categoryFilterList = None if binSpec=='*' else binSpec.replace(' ','').split(',')
    #    return UserBinSource('file',fn, genome, categoryFilterList)

    @staticmethod
    def _getBinningCategoriesCommon(genome, forExtraction=False):
        binCatList = []
        for label, method in [['Chromosome arms',GenomeInfo.getChrArmRegsFn],['Chromosomes',GenomeInfo.getChrRegsFn],['Cytobands',GenomeInfo.getChrBandRegsFn], ['Genes (Ensembl)',GenomeInfo.getStdGeneRegsFn]]:
            fn = method(genome)
            if fn is not None:
                binCatList.append(label)
        binCatList += ['Custom specification','Bins from history']
        if forExtraction:
            binCatList[0], binCatList[1] = binCatList[1], binCatList[0]
        #logMessage(str(binCatList))    
        return binCatList

    @staticmethod
    def getBinningCategories(genome):
        return GalaxyInterface._getBinningCategoriesCommon(genome, False)
        
    @staticmethod
    def getBinningCategoriesForExtraction(genome):
        return GalaxyInterface._getBinningCategoriesCommon(genome, True)
        
    @staticmethod
    def _getUserBinSource(regSpec, binSpec, genome):
        categoryFilterList = None if binSpec=='*' else binSpec.replace(' ','').split(',')
        if regSpec == '__chrs__' or (binSpec == '*' and regSpec == '*'):
            ubSource = GEMarkRemover(GenomeInfo.getChrRegs(genome, categoryFilterList))
            ubSource.description = GalaxyInterface._generateUbDescription('chromosomes', genome, categoryFilterList)
        elif regSpec == '__chrArms__':
            ubSource = GenomeInfo.getChrArmRegs(genome, categoryFilterList)
            ubSource.description = GalaxyInterface._generateUbDescription('chromosome arms', genome, categoryFilterList)
        elif regSpec == '__chrBands__':
            ubSource = GenomeInfo.getChrBandRegs(genome, categoryFilterList)
            ubSource.description = GalaxyInterface._generateUbDescription('chromosome bands', genome, categoryFilterList)
        elif regSpec == '__genes__':
            ubSource = GenomeInfo.getStdGeneRegs(genome, categoryFilterList)
            ubSource.description = GalaxyInterface._generateUbDescription('ensemble genes (clustered)', genome, categoryFilterList)
        else:
            ubSource = UserBinSource(regSpec,binSpec,genome)
            #if regSpec == binSpec == '*':
            #    ubSource.description = GalaxyInterface._generateUbDescription('chromosomes', genome, None)
            #else:
            if regSpec in ['file','wig','bed','customtrack']:
                ubSource.description = 'Using regions from file of type "' + regSpec + '" of genome build "' + genome + '" as bins'
            else:
                region = parseRegSpec(regSpec, genome)
                isWholeChr = (region.chr is None) or ( (region.start, region.end) == (0, GenomeInfo.getChrLen(genome, region.chr)) )
                
                ubSource.description = 'Using' +\
                                       ((' chromosome ' + region.chr) if region.chr is not None else ' all chromosomes') +\
                                       ' of genome build "' + genome + '"' +\
                                       ((' from position ' + str(region.start+1) + ' to ' + str(region.end)) if not isWholeChr else '') +\
                                       ((', divided into intervals of size ' +\
                                       generateStandardizedBpSizeText( parseShortenedSizeSpec( binSpec ) ) + ',') if binSpec != '*' else '') +\
                                       ' as bins'
        return ubSource
    
    @staticmethod
    def _generateUbDescription(binType, genome, categoryFilterList):
        if categoryFilterList is None:
            return 'Using all ' + binType + ' of genome build "' + genome + '" as bins'
        else:
            return 'Using the following ' + binType + ' of genome build "' + genome + '" as bins: ' +\
                                   ', '.join(categoryFilterList)
        
    #@staticmethod
    #def _cleanUpTrackNames(trackName1, trackName2, trackNameIntensity=[]):
    #    GalaxyInterface._cleanUpTrackName(trackName1)
    #    GalaxyInterface._cleanUpTrackName(trackName2)
    #    GalaxyInterface._cleanUpTrackName(trackNameIntensity)
    
    @staticmethod    
    def _revEngBatchLine(trackName1, trackName2, analysisDef, regSpec, binSpec, genome):
        GalaxyInterface._cleanUpTrackName(trackName1)
        GalaxyInterface._cleanUpTrackName(trackName2)

        from gold.description.RunDescription import RunDescription
        return RunDescription.getRevEngBatchLine(trackName1, trackName2, analysisDef, regSpec, binSpec, genome)
    
    @staticmethod
    def _cleanUpTrackName(trackName):
        if trackName is not None:
            for i in range(len(trackName)):
                trackName[i] = trackName[i].replace(GalaxyInterface.ALL_SUBTYPES_TEXT,'') 
            while len(trackName)>0 and trackName[-1] == '': 
                del trackName[-1]

    @staticmethod
    def _viewResults(resultList, galaxyFn):
        if galaxyFn is not None:
            galaxyId = extractIdFromGalaxyFn(galaxyFn)
            uniqueWebPath = getUniqueWebPath(galaxyId)
            from gold.result.ResultsViewer import ResultsViewerCollection
            print ResultsViewerCollection(resultList, uniqueWebPath)
        else:
            print 'Only printing plain python representations, due to lack of galaxyFn:'
            print resultList


    @staticmethod
    def getIllustrationRelURL(analysisDef):
        fn = AnalysisDefHandler(unquote(analysisDef)).getIllustrationFn()
        if fn != None:
            return os.sep.join([STATIC_REL_PATH, 'images', 'illustrations',fn])
        else:
            return None

    @staticmethod
    def getDemoAnalysisIntro(demoID):
        core = HtmlCore()
        core.styleInfoBegin(styleClass='infomessagesmall')
        if demoID == 'H3K27me3 vs SINE':
            core.paragraph('''
                This demo shows hypothesis testing using the Genomic HyperBrowser. The analysis is part of an
                analysis of the relation between H3K27me3 histone modifications and SINE repeats,
                as presented in the main article describing our system (a link to the corresponding
                section of the article will be provided when the article is published).''')
            core.paragraph('''
                H3K27me3 histone modifications and SINE repeats are selected as the two tracks of interest.
                When clicking on "Start analysis", the significance of the observed overlap between H3K27me3
                and SINE will be calculated using a Monte Carlo-based approach.''')
            core.paragraph('''
                The alternative hypothesis and the null model assumptions can be changed under "Options".
                We have pre-selected 200 Monte Carlo iterations to make the demo run faster, but for a real
                analysis a higher number, like 20000, should be used. The analysis will be performed in bins
                of size 5 million base pairs in chromosome 17 of mouse (mm8), excluding the 3 million first base pairs, which are centromeric.''')
        elif demoID == 'Gene Coverage':
            core.paragraph('''This demo shows a very simple example of using the Genomic HyperBrowser: finding out how much of the genome is covered by genes.
                           This is done by simply selecting a gene track, and selecting count as analysis.
                           ''')
            core.paragraph('''Note that even this very simple question reveals a complication: there is no unanimous definition of exactly what constitute genes.
                When selecting a gene track, one therefore has to select which gene source to use.
                In the demo the Consensus Coding Sequence (CCDS) has been used.
                ''')
            core.paragraph('''We here also select "Cytobands" in the "Region and scale"-box, in order to do
                           a local analysis of the coverage of genes in all cytobands.
                           ''')
        elif demoID == 'H3K4me3 vs T-cell expression':
            core.paragraph('''This demo shows an analysis that involves the use of ad hoc created tracks.
                The second track consists of segments 1kb downstream of TSS, where each segment is marked
                with the expression of the corresponding gene in a T-cell microarray experiment.
                This second track would then typically be created ac hoc by extracting an expression track,
                consisting of gene regions with an attached expression value, to history
                This track would then be expanding 1kb flanks from the TSS, by using the "Extract BED segments" tool.
                The resulting track could then be selected as a track from history. See the screencast for more details.
                ''')
            core.paragraph('''The question raised is whether there is a connection between the expression mark associated
                           with a 1kb segment and the number of nucleosomes with H3K4me3 histone modifications falling inside it.
                           ''')
            core.paragraph('''
                The analysis is part of an analysis of the relation between histone modifications and gene expression,
                as presented in the main article describing our system (a link to the corresponding
                section of the article will be provided when the article is published).
                ''')
        elif demoID == 'MLV vs Expanded FirstEF promoters':
            core.paragraph('''This demo shows local analysis using the Genomic HyperBrowser.
                The question raised is whether virus (MLV) integrates more into FirstEF promoters (including 2kb flanks) than expected by chance.
                This analysis is performed in 30 Mbp bins throughout the genome, and the local variation of the virus-promoter relation can thus be investigated.
                ''')
            core.paragraph('''This analysis is included in the main article describing our system (a link to the corresponding
                section of the article will be provided when the article is published).
               ''')
        elif demoID == 'Exon boundaries vs melting fork probs':
            core.paragraph('''
                This demo shows how to take confounding tracks into account when doing analyses in the HyperBrowser.
                The question raised is whether exon boundaries (left sides) coincide with positions of high probability of melting bubble formation.                
                ''')
            core.paragraph('''
                The main point with the analysis is the possibly confounding effect GC content plays on a study of the direct relation between exons and melting bubbles.
                This is because both exons and melting bubbles are by themselves related to GC content
                (GC content is generally higher in exons, melting temperature is higher with G and C than with A or T).
                To see whether exons and melting bubbles (melting fork probabilities) coincide more than expected given their common dependence on GC content,
                we sample exons in the null model based on dependency between exons and GC content.
                This is done by selecting ".. randomize positions by intensity" as null model,
                and selecting an intensity track of exon probability given GC content.
                The screencast of this example will show how such intensity tracks can be created.
                ''')
            core.paragraph('''
                The analysis is part of an analysis of the relation between histone modifications and gene expression,
                as presented in the main article describing our system (a link to the corresponding
                section of the article will be provided when the article is published).
                As this analysis is somewhat intricate, it is easier to understand after consulting the discussion of confounder track handling in the article.
                ''')
        #elif demoID == '': #sample regulome
        #    core.paragraph('''
        #                   ''')
        else:
            core.paragraph("Intro for " + demoID)
        core.styleInfoEnd()
        return str(core)
        
    @staticmethod
    def getDemoResultsIntro(demoID):
        core = HtmlCore()
        core.styleInfoBegin(styleClass='infomessagesmall')
        if demoID == 'H3K27me3 vs SINE':
            core.paragraph('''
                This page shows the result of the H3K27me3 vs SINE repeats-demo, which shows how to do hypothesis
                testing in the Genomic HyperBrowser. The analysis is part of an analysis of the relation between
                H3K27me3 histone modifications and SINE repeats, as presented in the main article describing our
                system (a link to the corresponding section of the article will be provided when the article is
                published).''')
            core.paragraph('''
                The main point with this case, as discussed in the article, is how the computed p-value will
                depend on the selected null model. Depending on the selected null model, you will get from zero
                to several significant bins when asking whether H3K27me3-segments and SINE repeats overlap more
                than expected by chance at the base pair level. These varying results for different null models make up
                a table in the article summarizing the results for this case.''')
            core.paragraph('''
                Note that different tests are used across null models, with some null models allowing a quick
                parametric solution (based on the binomial distribution), while others require Monte Carlo-based
                calculation of significance.''')
        elif demoID == 'Gene Coverage':
            core.paragraph('''
                This page shows the result of the Gene Coverage demo. According to the CCDS gene definition, 25.97% of the genome consists of genes.
                By looking at "Table: values per bin", one can also look at coverage proportion for each of the cytobands.
                ''')
            core.paragraph('''
                The "Assembly gap coverage" row shows the proportion of base pairs that are missing (i.e. not sequenced) in the
                genome assembly used. If this value is high for a particular bin (or for the global analysis), you should be sceptical about
                your results. Most assembly gaps are centromeres or other heterochromatic regions.
                ''')
        elif demoID == 'H3K4me3 vs T-cell expression':
            core.paragraph('''
                This page shows the result of the demo of H3K4me3 vs gene expression.
                The analysis is part of an analysis of the relation between histone modifications and gene expression,
                as presented in the main article describing our system (a link to the corresponding
                section of the article will be provided when the article is published).
                ''')
            core.paragraph('''
                Figure 2 of the article mentioned above shows the correlation between gene expression and histone modification count inside TSS flanks 
                for 21 histone modifications and 4 variants of TSS flanks. The value of the test statistic for this demo (0.23) thus makes up one out of 84 data points in Figure 2.
                ''')
        elif demoID == 'MLV vs Expanded FirstEF promoters':
            core.paragraph('''
                This page shows the result of the demo of MLV vs Expanded FirstEF promoters.
                The analysis is included in the main article describing our system (a link to the corresponding
                section of the article will be provided when the article is published).
                ''')
            core.paragraph('''
                The focus of this analysis is the local variation. This can be inspected by clicking on results for the test in "each bin separately".
                It can also be inspected visually by clicking "See full details" and clicking "Plot: values per bin"-"Figure" for FDR-adjusted p-values.
                ''')
            core.paragraph('''
                The local results can be exported to the history by clicking "As track in history"-"Load" in the same table. FDR-adjusted p-values can then
                be visualized in the UCSC Genome Browser by clicking on the name of the new history element, and then clicking "display at UCSC main".
                ''')
            
        elif demoID == 'Exon boundaries vs melting fork probs':
            core.paragraph('''
                This page shows the result of the demo of Exon boundaries vs melting fork probabilities.                
                The analysis is included in the main article describing our system (a link to the corresponding
                section of the article will be provided when the article is published).
                ''')
            core.paragraph('''
                The question raised is whether exon boundaries (left sides) coincide with positions of high probability of melting bubble formation,
                more than expected by chance, but given their common dependency on GC content.
                Although the relation between exons and melting bubbles is clearly significant when not taking GC content into consideration (see discussion in article),
                the relation here usually turns out significant in 1 out of 17 bins at 10% FDR.
                By clicking on "A collection of FDR-corrected p-values per bin" one can further see values for each chromosome,
                and see that the only chromsome with signifint relation was chromosome M, the mithocondrial DNA.
                This suggest that the relation between exons and melting temperature may just be a reflection of their common dependency with GC content.                
                ''')
        else:
            core.paragraph("Results page intro for " + demoID)
        core.styleInfoEnd()
        return str(core)
