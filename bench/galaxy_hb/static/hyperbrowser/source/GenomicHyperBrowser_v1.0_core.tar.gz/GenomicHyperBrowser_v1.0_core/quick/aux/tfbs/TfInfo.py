from collections import OrderedDict

class TfInfo:
    @staticmethod
    def getTfTrackNameMappings(genome):
        if genome == 'NCBI36':
            #return {'UCSC tfbs conserved':['Gene regulation','TFBS','UCSC prediction track'],
            #        'Bar-Joseph target gene predictions':['Gene regulation','TFBS','Bar-Joseph predictions'],
            #        'Genome-wide ChIP-seq':['Gene regulation','TFBS','ChIP-seq','Peaks'],
            #        'Genome-wide ChIP-chip':['Gene regulation','TFBS','High throughput']}

            return OrderedDict([('UCSC tfbs conserved',['Gene regulation','TFBS','UCSC prediction track']),
                    ('Bar-Joseph target gene predictions',['Gene regulation','TFBS','Bar-Joseph predictions']),
                    ('Genome-wide ChIP-seq',['Gene regulation','TFBS','ChIP-seq','Peaks']),
                    ('Genome-wide ChIP-chip',['Gene regulation','TFBS','High throughput'])])
        else:
            return {}