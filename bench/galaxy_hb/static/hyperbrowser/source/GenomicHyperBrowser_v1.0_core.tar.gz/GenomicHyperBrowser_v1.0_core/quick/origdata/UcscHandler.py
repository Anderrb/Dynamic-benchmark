#!/usr/bin/env python
import mechanize
import time
import os.path
import re
from gold.util.CustomExceptions import MissingEntryError, ArgumentValueError
from gold.description.TrackInfo import TrackInfo
from gold.application.Config import DATA_FILES_PATH


class UcscHandler(object):
    UCSC_CATEGORIES = ('clade','org','db','hgta_group','hgta_track','hgta_table')
    GENOME_TO_CATEGORY_PATH = '/Users/trengere/HB/ucsc_docs/'
    
    
    def __init__(self, state=None):
        if state:
            temp = state.split('#')
            self._sessionId = temp[0]
            self._category = temp[-1]
        else:
            self._sessionId = self._category = None
        
        self.genomeToCategoryValues = self._getGenomeCategoryValDict()
    
    def _getGenomeCategoryValDict(self):
        dict = {}
        for w in [v.split('$$') for v in open(DATA_FILES_PATH+'/HB_UCSC_MAPPING.dat','r').read().split('\n')]:
            dict[w[0]] = w[1].split('#') 
        return dict
        #{'NCBI36':'mammal#Human#hg18', 'hg18':'mammal#Human#hg18'}
        
    def _makeRequestObj(self, url):
        
        request_obj = mechanize.Request(url)
        #request_obj.add_header('Accept','application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5')
        #request_obj.add_header('Accept-Charset','ISO-8859-1,utf-8;q=0.7,*;q=0.3')
        #request_obj.add_header('Accept-Encoding','gzip,deflate,sdch')
        #request_obj.add_header('Accept-Language','nb-NO,nb;q=0.8,no;q=0.6,nn;q=0.4,en-US;q=0.2,en;q=0.2')
        #request_obj.add_header('Connection','keep-alive')
        
        request_obj.add_header('User-Agent','Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.237 Safari/534.10')
        #req_obj.add_header('User-Agent',    'Mozilla/5.0')
        return request_obj
    
    
    def _getNextParamKey(self, get_key=None):
        next_key_dict = {'clade':'org', 'org':'db', 'db':'hgta_group', 'hgta_group':'hgta_track', 'hgta_track':'hgta_table','hgta_table':None}
        if get_key:
            return next_key_dict[get_key]
        else:
            return 'clade'
    
    
    
    
        
    
    def _makeUrlstreng(self, hgsid=False, param=False, valg=False):
        #http://genome.ucsc.edu
        if hgsid:
            urlstreng ='http://moma.ki.au.dk/genome-mirror/cgi-bin/hgTables?hgsid='+hgsid+ '&'+param+'='+valg.replace(' ','+')
        else:
            urlstreng ='http://moma.ki.au.dk/genome-mirror/cgi-bin/hgTables'
        return urlstreng
    
    
        
    def _getWebpage(self, urlstreng):
        print urlstreng
        req_obj = self._makeRequestObj(urlstreng)
        response = mechanize.urlopen(req_obj)
        return response
    
    def _getWebPageAndForm(self, urlstreng):
        webObject = self._getWebpage(urlstreng)
        return webObject, self._getForm(webObject)
    
    
    def _getForm(self, response):
        forms = mechanize.ParseResponse(response, backwards_compat=False)
        
        return forms[0]
    
    def _submitFinalForm(self, response_obj):
        print 'ferdig med oppgave...'
    
    
    
    
    
    def _loopThroughUcscPages(self, genome, category, catValue):
        
        if not category:
            parameterValueList = self.genomeToCategoryValues[genome]
            webObject, paramForm = self._getWebPageAndForm(self._makeUrlstreng())
        
            for i in range(len(parameterValueList)):
                time.sleep(0.5)
                webObject, paramForm = self._getWebPageAndForm( self._makeUrlstreng(paramForm['hgsid'], self.UCSC_CATEGORIES[i], parameterValueList[i]) )
            
            self._category = self.UCSC_CATEGORIES[len(parameterValueList)-1]
            self._catValue = parameterValueList[-1]
            return paramForm
        
        else:
            webObject, paramForm = self._getWebPageAndForm( self._makeUrlstreng(self._sessionId, category, catValue) )
            return paramForm
        
        
    
    def _fillParamValueList(self, genome, trackName):
        try:
            parameterValueList = self.genomeToCategoryValues[genome] # actually lookup the genome variable in the dict here
            parameterValueList.extend(trackName[1:])
            return parameterValueList
        except:
            raise MissingEntryError()
    
    
    
    def _isUcscValuesCorrect(genome):
        parameterValueList = self.genomeToCategoryValues[genome]
        webObject, paramForm = self._getWebPageAndForm(self._makeUrlstreng())
        
        for i in range(len(parameterValueList)):
            if parameterValueList[i] in [item.name for item in paramForm.find_control(self.UCSC_CATEGORIES[i]).items]:
                webObject, paramForm = self._getWebPageAndForm( self._makeUrlstreng(paramForm['hgsid'], self.UCSC_CATEGORIES[i], parameterValueList[i]) )
            else:
                return False
        return True
        
    
    
    def isGenomeAvailable(self, genome):
        return genome in self.genomeToCategoryValues and self._isUcscValuesCorrect(genome)
        
        
     
    def _getCategoryValue(self, trackName):
        #trackname = ['ucsc','org','Human']
        if self._category:
            return trackName[-1]
        else:
            return None
    
        
    def _storeUcscInfoBox(self, genome, parameterForm):
        htmlText = mechanize.urlopen(parameterForm.click('hgta_doSchema')).read()
        htmlSubText = htmlText[htmlText.find('<H2>'):htmlText.rfind('</P>')]
        if htmlSubText:
            htmlSubText += '</P>'
            trackName = [parameterForm['hgta_group'][0],parameterForm['hgta_track'][0],parameterForm['hgta_table'][0]]
            print ' : '.join(trackName) +',   '+genome
            trackInfoObject = TrackInfo(genome, trackName)
            
            htmlSubList = htmlSubText.split('<H2>')[1:]            
            for i in htmlSubList:
                header = i[:i.find('</H2>')]
                if header == 'Description':
                    print 'Description'
                    trackInfoObject.description = i.split('</H2>')[1]
                elif header == 'Methods':
                    print 'Methods'
                    trackInfoObject.description = i.split('</H2>')[1]
                elif header == 'Credits':
                    print 'Credits'
                    trackInfoObject.description = i.split('</H2>')[1]
                elif header == 'References':
                    print 'References'
                    trackInfoObject.description = i.split('</H2>')[1]
                else:
                    pass
            trackInfoObject.store()
            
    
    def getSubTrackNames(self, genome, trackName=[], state=None):
        
        self._catValue = self._getCategoryValue(trackName)
        paramForm = self._loopThroughUcscPages(genome, self._category, self._catValue )
        
        if self._category =='hgta_table':
            self._storeUcscInfoBox(genome, paramForm)
            #her skal vi returnere en tom liste og staten...
            #return [],state
            self._getBedData(paramForm)
            if 'bed' in [item.name for item in paramForm.find_control("hgta_outputType").items]:
                print 'all parameters have been set. time to fetch the bed format'
            else:
                print 'Bed-format does not exist for these choices...'
                print [item.name for item in paramForm.find_control("hgta_outputType").items]
                print ''
                print [item.name for item in paramForm.find_control(self._category).items]
        else:
            self.state = paramForm['hgsid']+'#'+self._getNextParamKey(self._category)
            print self.state
            self.valueList = [item.name for item in paramForm.find_control(self._getNextParamKey(self._category)).items]
            #print paramForm['hgsid']
            #print self._getNextParamKey(self._category)
            print self.valueList
            #return valueList, state
        
    
    def _getBedData(self, parameterForm):
        parameterForm['hgta_outputType'] = ['bed']
        response = mechanize.urlopen(parameterForm.click('hgta_doTopSubmit'))
        lastForm =  self._getForm(response)
        bedString = mechanize.urlopen(lastForm.click('hgta_doGetBed')).read()
        print bedString[:200]    
        
        
    def getBedData(self, genome, trackName):
        parameterValueList = self._fillParamValueList(genome, trackName)
        #parameterValueList = self.genomeToCategoryValues[genome].split('#') # actually lookup the genome variable in the dict here
        #parameterValueList.extend(trackName[1:])# values selected for the tracs, fetched previously from ucsc
        print parameterValueList
        assert len(parameterValueList) == len(self.UCSC_CATEGORIES)
        paramForm = self._loopThroughUcscPages(parameterValueList)   
        self._getBedData(paramForm)
        
    
if __name__ == "__main__":
    ucscObject = UcscHandler()
    
    ucscObject.getSubTrackNames('hg18')
    #session=raw_input('skriv inn session_id: ')
    tilstand = ucscObject.state
    while True:
        #key=raw_input('skriv inn key: ')
        index =int(raw_input('skriv inn index for value: '))
        value = ucscObject.valueList[index]
        
        ucscObject = UcscHandler(tilstand)
        ucscObject.getSubTrackNames('hg18',['ucsc',tilstand,value])
        if hasattr(ucscObject, 'state'):
            tilstand = ucscObject.state
        else:
            break
            
    #ucscObject.getBedData('NCBI36', ['ucsc','rna','intronEst'])
