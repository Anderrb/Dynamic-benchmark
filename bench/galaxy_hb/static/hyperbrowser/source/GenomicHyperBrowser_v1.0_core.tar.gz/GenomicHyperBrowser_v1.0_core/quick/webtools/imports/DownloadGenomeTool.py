from quick.webtools.GeneralGuiTool import GeneralGuiTool
from quick.aux.GenomeImporter import GenomeImporter
import os
#This is a template prototyping GUI that comes together with a corresponding web page.
#

class DownloadGenomeTool(GeneralGuiTool):
    @staticmethod
    def getToolName():
        return "Download genome sequence"

    @staticmethod
    def getInputBoxNames(prevChoices=None):
        "Returns a list of names for input boxes, implicitly also the number of input boxes to display on page. Each such box will call function getOptionsBoxK, where K is in the range of 1 to the number of boxes"
        return ['Genome abbreviation','Genome name','Genome sequence URL(s)']

    @staticmethod    
    def getOptionsBox1():
        "Returns a list of options to be displayed in the first options box"
        return ''
    
    @staticmethod    
    def getOptionsBox2(prevChoices): 
        '''Returns a list of options to be displayed in the second options box, which will be displayed after a selection is made in the first box.
        prevChoices is a list of selections made by the web-user in the previous input boxes (that is, list containing only one element for this case)        
        '''
        return ''
    
    @staticmethod    
    def getOptionsBox3(prevChoices):
        return ''

    #@staticmethod    
    #def getOptionsBox4(prevChoices):
    #    return {'chr1':False, 'chr2':True}
    

    #@staticmethod
    #def getDemoSelections():
    #    return ['testChoice1','..']
        
    @classmethod    
    def execute(cls, choices, galaxyFn=None):
        '''Is called when execute-button is pushed by web-user.
        Should print output as HTML to standard out, which will be directed to a results page in Galaxy history.
        If needed, StaticFile can be used to get a path where additional files can be put (e.g. generated image files).
        choices is a list of selections made by web-user in each options box.
        '''
        #print 'Executing... with choices %s'%str(choices)
        abbrv = choices[0]
        name = choices[1]
        
        #Should test that the genome is not in hyperbrowser.
        
        from quick.util.GenomeInfo import GenomeInfo
        if GenomeInfo.isInstalled(abbrv):
            print "Genome "+abbrv+ " is allready in HyperBrowser! Remove the old first (function not implemeted)."
        else:
            #cls.printTrackNameHistoryElement(abbrv, name, GenomeInfo.getSequenceTrackName(abbrv))
            urls = choices[2].split()
            for url in urls:
                GenomeImporter.downloadGenomeSequence(abbrv, url)
            chrs=GenomeImporter.extractChromosomesFromGenome(abbrv)
            
            galaxyFile=open(galaxyFn, "w")
            galaxyFile.write( 'Genome abbreviation: ' + abbrv + os.linesep)
            galaxyFile.write( 'Genome full name: ' + name + os.linesep)
            galaxyFile.write( 'Track name: ' + ':'.join(GenomeInfo.getSequenceTrackName(abbrv)) + os.linesep)
            galaxyFile.write( 'Temp chromosome names: ' + ' || '.join(chrs) + os.linesep)
            #GenomeImporter.saveTempInfo(abbrv, name, chrs)
            #print 'Chromosomes: '+chrs

       
    @staticmethod     
    def printTrackNameHistoryElement(genomeAbbrv, genomeFullName, trackName):
        print 'Genome abbreviation: ' + genomeAbbrv
        print 'Genome full name: ' + genomeFullName
        print 'Track name: ' + ':'.join(trackName)
        
    #@staticmethod
    #def isPublic():
    #    return True
    #
    #@staticmethod
    def getToolDescription(self):
        return 'Genome sequence should be given as one or more FASTA files, optionally compressed'
    
    @staticmethod    
    def getOutputFormat():
        return 'hbgenome'
    #    
    #@staticmethod
    #def getToolIllustration():
    #    return None
    #
    #@staticmethod
    #def isDebugMode():
    #    return True