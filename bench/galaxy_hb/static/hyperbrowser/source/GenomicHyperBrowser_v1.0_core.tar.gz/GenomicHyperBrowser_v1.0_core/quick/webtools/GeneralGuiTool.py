from quick.util.CommonFunctions import getUniqueWebPath, getRelativeUrlFromWebPath, extractIdFromGalaxyFn
import os

class GeneralGuiTool(object):
    @classmethod
    def getPathAndUrlForFile(cls, galaxyFn, relFn):
        '''
        Gets a disk path and a URL for storing a run-specific file.
        galaxyFn is connected to the resulting history item in Galaxy,
          and is used to determine a unique disk path for this specific run.
        relFn is a relative file name (i.e. only name, not full path) that one
          wants a full disk path for, as well as a URL referring to the file.
        '''
        fullFn = cls.getDiskPathForFiles(galaxyFn) + os.sep + relFn
        url = cls.getBaseUrlForFiles(fullFn)
        return fullFn, url
        
        
    @staticmethod
    def getDiskPathForFiles(galaxyFn):
        galaxyId = extractIdFromGalaxyFn(galaxyFn)
        return getUniqueWebPath(id)
    
    @staticmethod
    def getBaseUrlForFiles(diskPath):
        return getRelativeUrlFromWebPath(diskPath)
    
    @staticmethod
    def isPublic():
        return False

    @staticmethod
    def isRedirectTool():
        return False

    @staticmethod
    def getToolDescription():
        return ''
    
    @staticmethod
    def getToolIllustration():
        return None

    @staticmethod
    def isDebugMode():
        return True
    
    @staticmethod
    def isRedirectTool():
        return False

    @staticmethod    
    def getOutputFormat():
        return 'html'
    
    @staticmethod
    def validateAndReturnErrors(choices):
        '''
        Should validate the selected input parameters. If the parameters are not valid,
        an error text explaining the problem should be returned. The GUI then shows this text
        to the user (if not empty) and greys out the execute button (even if the text is empty).
        If all parameters are valid, the method should return None, which enables the execute button.
        '''
        return None
        
    @staticmethod
    def _isValidTrack(prevChoices, tnChoiceIndex=1):
        from quick.application.GalaxyInterface import GalaxyInterface
        from quick.application.ProcTrackOptions import ProcTrackOptions
        
        genome = prevChoices[0]
        tn = prevChoices[tnChoiceIndex].split(':')
        
        return ProcTrackOptions.isValidTrack(genome, tn, True) or \
            GalaxyInterface.isNmerTrackName(genome, tn)

    @staticmethod    
    def _getBasicTrackFormat(choices, tnChoiceIndex=1):
        from quick.application.GalaxyInterface import GalaxyInterface
        from gold.description.TrackInfo import TrackInfo
        
        genome = choices[0]
        tn = choices[tnChoiceIndex].split(':')
        
        if GalaxyInterface.isNmerTrackName(genome, tn):
            tfName = 'Unmarked points'
        else:
            tfName = TrackInfo(genome, tn).trackFormatName
        
        tfName = tfName.lower()
        
        if tfName not in ['', 'step function']:
            tfName = tfName.split()[-1]
            
        return genome, tn, tfName
    