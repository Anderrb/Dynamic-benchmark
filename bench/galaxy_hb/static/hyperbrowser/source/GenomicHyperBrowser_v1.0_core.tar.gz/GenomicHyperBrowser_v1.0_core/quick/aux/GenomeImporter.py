

import os
import urllib
import tarfile
import zipfile
import gzip
from quick.util.CommonFunctions import ensurePathExists
from quick.util.GenomeInfo import GenomeInfo
from gold.application.Config import NONSTANDARD_DATA_PATH
from quick.aux.StandardizeTrackFiles import SplitFasta
from quick.origdata.AllTracksPreProcessor import AllTracksPreProcessor
from gold.util.CommonFunctions import createOrigPath
from quick.aux.CustomFuncCatalog import createChromosomeFile, createAssemblyGapsFile

class GenomeImporter:
    @classmethod
    def extractChromosomesFromGenome(cls, abbrv):
        """Method that reads allt the chromosone files for one genome and picks out the Chromosone names
           it uses the constant NONSTANDARD_DATA_PATH and abbrv to find correct path.
           all files within this path is examined for chromosone names and a list of found names is returned from the method
        """
        resultList = []
        basePath = cls._getBasePath(abbrv) + os.sep
        
        for i in os.listdir(basePath):
            
            faFile = open(basePath + i,'r')
            resultList += [fileString[1:].strip() for fileString in faFile if fileString[0]=='>']
            faFile.close()
        return resultList
    
    @classmethod
    def getTempInfo(cls, fileName):
        """Returns al dict of (key, value) where key is keyword and value its value"""
        return dict([(v[:v.find(':')].strip(), v[v.find(':')+1:].strip().replace(' || ', os.linesep)) for v in open(fileName,'r').readlines()])
        #tempDict = dict()
        #print fileName
        #tmpFile = open(fileName,'r')
        #for v in tmpFile:
        #    index = v.find(':')
        #    key = v[:index].strip()
        #    value = v[index+1:].strip().replace(' || ', os.linesep)
        #    tempDict[key] = value
        #return tempDict
            
    @classmethod
    def downloadGenomeSequence(cls, abbrv, url):
        #laste ned fil og lagre under abbr
        #Filer maa ha endelsen fa fasta tar tgz tar.gz zip gz
        basePath = cls._getBasePath(abbrv)
        #print "basePath="+basePath
        fn = basePath +"/"+ url.split("/")[-1]
        ensurePathExists(fn)
        urllib.urlretrieve(url, fn)
        #print "wd="+os.getcwd()
        
        if url.lower().endswith(".fa") | url.lower().endswith(".fasta"):
            print "fasta file"
        elif url.lower().endswith(".tar") | url.lower().endswith(".tgz") | url.lower().endswith(".tar.gz"):
            print "tar file"
            te=tarfile.open(fn)
            te.extractall(path=basePath)
            te.close()
            os.remove(fn)
        elif url.lower().endswith(".zip"):
            print "zip file"
            sourceZip = zipfile.ZipFile(fn, 'r')
            sourceZip.extractall(path=basePath)
            sourceZip.close()
            os.remove(fn)
        elif url.lower().endswith(".gz"):
            print "gz file"
            f = gzip.open(fn, 'rb')
            retfn=fn[0:fn.rfind(".")]#Renames file except last part, ".gz"?
            resfile=open(retfn, "wb")
            resfile.write(f.read())
            resfile.close()
            os.remove(fn)
        else:
            print "Not a supported file format. File must end with: fa fasta tar tgz tar.gz zip gz"
            
    @classmethod
    def _getBasePath(cls, abbrv):
        return os.sep.join([NONSTANDARD_DATA_PATH, abbrv] + GenomeInfo.getSequenceTrackName(abbrv))
    
    @classmethod     
    def createGenome(cls, genome, fullName, allChromosomes, standardChromosomes, experimental=True):
        """genome fullName chromNames experimental=True"""
        
        basePath = cls._getBasePath(genome)
        trackName=GenomeInfo.getSequenceTrackName(genome)
        print("Splitting genome file into chromosomes.")
        SplitFasta.parseFiles(genome, trackName, chromNames=allChromosomes)
        print("Processing genome")
        AllTracksPreProcessor.process(genome)
        
        print("Writing name file.")    
        nameFn=createOrigPath(genome,[], "_name.txt" if experimental else "#name.txt")
        f=open(nameFn, "w")
        f.write(fullName)
        f.close()
        
        print("Creating chromosome file")
        createChromosomeFile(genome, ",".join(standardChromosomes))
        print("Creating assambly gaps file")
        createAssemblyGapsFile(genome)
        print("Processing genome")
        AllTracksPreProcessor.process(genome)
        print(genome + " genome added")
    
    
"""
print "starter"
import os
os.chdir("/Users/vegard/jobb/hyperbrowser/temp")
# gzipped
GenomeImporter.downloadGenomeSequence("tullegenom", "http://hyperbrowser.uio.no/hb/static/hyperbrowser/div/testgenome/Schizosaccharomyces_pombe.EF1.dna.chromosome.I.fa.gz")
#zipped
#GenomeImporter.downloadGenomeSequence("tullegenom", "http://hyperbrowser.uio.no/hb/static/hyperbrowser/div/testgenome/zippedtest.zip")
#tar.gz
#GenomeImporter.downloadGenomeSequence("tullegenom", "http://hyperbrowser.uio.no/hb/static/hyperbrowser/div/testgenome/testgenome.tar.gz")
#tar
#GenomeImporter.downloadGenomeSequence("tullegenom", "http://hyperbrowser.uio.no/hb/static/hyperbrowser/div/testgenome/testgenometaronly.tar")
#fa
#GenomeImporter.downloadGenomeSequence("tullegenom", "http://hyperbrowser.uio.no/hb/static/hyperbrowser/div/testgenome/testgenomefastaonly.fa")

print "ferdig"


"""
