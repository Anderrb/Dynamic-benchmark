#!/usr/bin/env python
import mechanize
import time
import os.path
from gold.util.CustomExceptions import MissingEntryError, ArgumentValueError


class UcscHandler(object):
    UCSC_CATEGORIES = ('clade','org','db','hgta_group','hgta_track','hgta_table')
    GENOME_TO_CATEGORY_PATH = '/Users/trengere/HB/ucsc_docs/'
    
    def __init__(self, sessionId):
        
        self._sessionId = sessionId
        self.genomeToCategoryValues = self._getGenomeCategoryValDict()
    
    def _getGenomeCategoryValDict(self):
        dict = {}
        for w in [v.split('$$') for v in open(self.GENOME_TO_CATEGORY_PATH+'HB_UCSC_MAPPING.dat','r').read().split('\n')]:
            dict[w[0]] = w[1].split('#') 
        print dict
        return {'NCBI36':'mammal#Human#hg18', 'hg18':'mammal#Human#hg18'}
        
    def _makeRequestObj(self, url):
        
        request_obj = mechanize.Request(url)
        request_obj.add_header('Accept','application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5')
        request_obj.add_header('Accept-Charset','ISO-8859-1,utf-8;q=0.7,*;q=0.3')
        request_obj.add_header('Accept-Encoding','gzip,deflate,sdch')
        request_obj.add_header('Accept-Language','nb-NO,nb;q=0.8,no;q=0.6,nn;q=0.4,en-US;q=0.2,en;q=0.2')
        request_obj.add_header('Connection','keep-alive')
        
        request_obj.add_header('User-Agent','Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_3; en-US) AppleWebKit/534.10 (KHTML, like Gecko) Chrome/8.0.552.237 Safari/534.10')
        #req_obj.add_header('User-Agent',    'Mozilla/5.0')
        return request_obj
    
    
    def _getNextParamKey(self, get_key=None):
        next_key_dict = {'clade':'org', 'org':'db', 'db':'hgta_group', 'hgta_group':'hgta_track', 'hgta_track':'hgta_table','hgta_table':None}
        if get_key:
            return next_key_dict[get_key]
        else:
            return 'clade'
    
    
    
    def _getChosenValueFromParam(self, form, key):
        values = [item.name for item in form.find_control(key).items]
        print key
        print values
        arg_val = raw_input('choose a value from the list: ')
        value = values[int(arg_val)]
        return value
        
    
    def _makeUrlstreng(self, hgsid=False, param=False, valg=False):
        if hgsid:
            urlstreng ='http://genome.ucsc.edu/cgi-bin/hgTables?hgsid='+hgsid+ '&'+param+'='+valg.replace(' ','+')
        else:
            urlstreng ='http://genome.ucsc.edu/cgi-bin/hgTables'
        return urlstreng
    
    
        
    def _getWebpage(self, urlstreng):
        req_obj = self._makeRequestObj(urlstreng)
        response = mechanize.urlopen(req_obj)
        return response
    
    
    def _getForm(self, response):
        forms = mechanize.ParseResponse(response, backwards_compat=False)
        return forms[0]
    
    def _submitFinalForm(self, response_obj):
        print 'ferdig med oppgave...'
    
    def _getWebPageAndForm(self, urlstreng):
        webObject = self._getWebpage(urlstreng)
        return webObject, self._getForm(webObject)
    
    def _getBedData(self, parameterForm):
        parameterForm['hgta_outputType'] = ['bed']
        response = mechanize.urlopen(parameterForm.click('hgta_doTopSubmit'))
        lastForm =  self._getForm(response)
        bedString = mechanize.urlopen(lastForm.click('hgta_doGetBed')).read()
        print bedString[:400]
    
    def _loopThroughUcscPages(self, parameterValueList):
        webObject, paramForm = self._getWebPageAndForm(self._makeUrlstreng())
        
        for i in range(len(parameterValueList)):
            time.sleep(0.5)
            webObject, paramForm = self._getWebPageAndForm( self._makeUrlstreng(paramForm['hgsid'], self.UCSC_CATEGORIES[i], parameterValueList[i]) )
        return paramForm
    
    def _fillParamValueList(self, genome, trackName):
        try:
            parameterValueList = self.genomeToCategoryValues[genome] # actually lookup the genome variable in the dict here
            parameterValueList.extend(trackName[1:])
            return parameterValueList
        except:
            raise MissingEntryError()
    
    
    
    def _isUcscValuesCorrect(genome):
        parameterValueList = self.genomeToCategoryValues[genome].split('#')
        webObject, paramForm = self._getWebPageAndForm(self._makeUrlstreng())
        
        for i in range(len(parameterValueList)):
            if parameterValueList[i] in [item.name for item in paramForm.find_control(self.UCSC_CATEGORIES[i]).items]:
                webObject, paramForm = self._getWebPageAndForm( self._makeUrlstreng(paramForm['hgsid'], self.UCSC_CATEGORIES[i], parameterValueList[i]) )
            else:
                return False
        return True
        
    
    
    def isGenomeAvailable(self, genome):
        return genome in self.genomeToCategoryValues and self._isUcscValuesCorrect(genome)
        
        
        
    
    def getSubTrackNames(self, genome, trackName):
        
        parameterValueList = self.genomeToCategoryValues[genome].split('#') # actually lookup the genome variable in the dict here
        parameterValueList.extend(trackName[1:])# values selected for the tracs, fetched previously from ucsc
        
        paramForm = self._loopThroughUcscPages(parameterValueList)          
        
        if len(parameterValueList) == len(self.UCSC_CATEGORIES): #all parameters has a value proceed with getting the bed_list
            print 'all parameters have been set. time to fetch the bed format'
            print parameterValueList
            self._getBedData(paramForm)
        else:
            print paramForm
            print [item.name for item in paramForm.find_control(self.UCSC_CATEGORIES[len(parameterValueList)]).items]
    
    
        
        
        
    def getBedData(self, genome, trackName):
        parameterValueList = self._fillParamValueList(genome, trackName)
        #parameterValueList = self.genomeToCategoryValues[genome].split('#') # actually lookup the genome variable in the dict here
        #parameterValueList.extend(trackName[1:])# values selected for the tracs, fetched previously from ucsc
        print parameterValueList
        assert len(parameterValueList) == len(self.UCSC_CATEGORIES)
        paramForm = self._loopThroughUcscPages(parameterValueList)   
        self._getBedData(paramForm)
        
    
if __name__ == "__main__":
    ucscObject = UcscHandler('')
    ucscObject.getSubTrackNames('NCBI36', ['ucsc','rna','intronEst'])#,'genes','refGene'
    #ucscObject.getBedData('NCBI36', ['ucsc','rna','intronEst'])
