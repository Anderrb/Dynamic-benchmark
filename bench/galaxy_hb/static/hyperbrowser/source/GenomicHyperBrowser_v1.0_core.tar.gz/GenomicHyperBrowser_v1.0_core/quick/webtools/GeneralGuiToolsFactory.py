from quick.webtools.Tool1 import Tool1
from quick.webtools.Tool2 import Tool2
from quick.webtools.Tool3 import Tool3
from quick.webtools.Tool4 import Tool4
from quick.webtools.Tool5 import Tool5

#from quick.webtools.EivindGLsTool import EivindGLsTool
from quick.webtools.HiepsTool import HiepsTool
from quick.webtools.create.CreateDnaBasedCustomTrackTool import CreateDnaBasedCustomTrackTool
from quick.webtools.create.CreateSegmentsFromGeneListTool import CreateSegmentsFromGeneListTool
from quick.webtools.create.SmoothedTrackTool import SmoothedTrackTool
from quick.webtools.export.ExtractIntersectingGenesTool import ExtractIntersectingGenesTool
from quick.webtools.nmer.NmerAnalyzeTool import NmerAnalyzeTool
from quick.webtools.nmer.NmerExtractTool import NmerExtractTool
from quick.webtools.nmer.NmerInspectTool import NmerInspectTool
from quick.webtools.plot.BinScaledPlotTool import BinScaledPlotTool
from quick.webtools.plot.ScatterPlotTool import ScatterPlotTool
from quick.webtools.tfbs.TfTargetsTool import TfTargetsTool
from quick.webtools.tfbs.GeneRegulatorsTool import GeneRegulatorsTool
from quick.webtools.tfbs.GeneSetRegulatorsTool import GeneSetRegulatorsTool
from quick.webtools.imports.DownloadGenomeTool import DownloadGenomeTool
from quick.webtools.imports.InstallGenomeTool import InstallGenomeTool
from quick.webtools.track.RenameTrackTool import RenameTrackTool

class GeneralGuiToolsFactory:
    @staticmethod
    def getWebTool(toolId):
        if toolId == 'hb_generic_1':
            return DownloadGenomeTool()
        elif toolId == 'hb_generic_2':
            #return EivindGLsTool()
            return Tool2()
        elif toolId == 'hb_generic_3':
            return Tool3()
        elif toolId == 'hb_generic_4':
            return Tool4()
        elif toolId == 'hb_generic_5':
            return InstallGenomeTool()
        elif toolId == 'hb_genelist':
            return CreateSegmentsFromGeneListTool()
        elif toolId == 'hb_create_dna_based':
            return CreateDnaBasedCustomTrackTool()
        elif toolId == 'hb_create_smoothed_track':
            return SmoothedTrackTool()
        elif toolId == 'hb_intersecting_genes':
            return ExtractIntersectingGenesTool()
        elif toolId == 'hb_nmer_analyze':
            return NmerAnalyzeTool()
        elif toolId == 'hb_nmer_extract':
            return NmerExtractTool()
        elif toolId == 'hb_nmer_inspect':
            return NmerInspectTool()
        elif toolId == 'hb_plot_scatter':
            return ScatterPlotTool()
        elif toolId == 'hb_plot_progpattern':
            return BinScaledPlotTool()
        elif toolId == 'hb_tf_reg_gene':
            return GeneRegulatorsTool()
        elif toolId == 'hb_tf_reg_gene_set':
            return GeneSetRegulatorsTool()
        elif toolId == 'hb_tf_gene_targets':
            return TfTargetsTool()
        elif toolId == 'hb_rename_track':
            return RenameTrackTool()
        #
        # hb_nmer_analyze
        # hb_nmer_extract
        # hb_nmer_inspect
        # hb_plot_scatter
        # hb_plot_progpattern
        
        else:
            raise Exception('no such prototype: ' + toolId)            