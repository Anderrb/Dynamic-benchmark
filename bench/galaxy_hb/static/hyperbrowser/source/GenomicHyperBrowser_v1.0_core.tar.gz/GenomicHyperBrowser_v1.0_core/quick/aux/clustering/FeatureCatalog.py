from gold.description.AnalysisManager import AnalysisManager
from quick.util.CommonFunctions import obsoleteHbFunction

class FeatureCatalog(object):
    @staticmethod
    @obsoleteHbFunction
    def getFeaturesFromTrackFormatCombination(tfName1, tfName2):
        if tfName1.lower() == tfName2.lower() == 'unmarked segments':
            return {'#Bp overlap': ['-> RawOverlapStat', 'Both'],
                    '#Bp overlap, diff from expected': ['[tail=more] [assumptions=bothIndependentBps]-> BpOverlapPValStat', 'DiffFromMean']}
        
    @staticmethod
    @obsoleteHbFunction
    def getFeaturesFromTracks(genome, trackName1, trackName2): #change to one out of three specific catalogs..
        return ReferenceAnalsesAsFeaturesCatalog.getValidAnalyses(genome, trackName1, trackName2)
    
    @classmethod
    def getValidAnalyses(cls, genome, trackName1, trackName2):
        allFeatures = cls.getAllFeatures()
        validFeatures = {}
        for key in allFeatures:
            analysisDef = allFeatures[key][0]
            #print AnalysisManager._tryAnalysisDefForValidity(analysisDef, genome, trackName1, trackName2, tryReversed=False)
            if AnalysisManager._tryAnalysisDefForValidity(analysisDef, genome, trackName1, trackName2, tryReversed=False)[0] is not None: #maybe also try reversed..
                validFeatures[key] = allFeatures[key]
                
        return validFeatures
    
class DirectDistanceCatalog(FeatureCatalog):
    @staticmethod
    def getAllFeatures():
        allFeatures = {}
        #US-US
        allFeatures['Ratio of intersection vs union of segments'] = ['dummy -> DerivedOverlapStat', 'intersectionToUnionRatio']
        return allFeatures
        
class LocalResultsAsFeaturesCatalog(FeatureCatalog):
    @staticmethod
    def getAllFeatures():
        allFeatures = {}
        #US-US
        allFeatures['Prop. Bp coverage'] = ['dummy -> ProportionCountStat', 'Result']
        return allFeatures
    
class ReferenceAnalsesAsFeaturesCatalog(FeatureCatalog):
    @staticmethod
    def getAllFeatures():
        #NB! Must be a word/option before '->' in order for analysisDef to be valid
        #Allowed track conversions can be restricted by setting option for tf1 or tf2 in analysisDef
        allFeatures = {}
        #US-US
        allFeatures['#Bp overlap'] = ['dummy -> RawOverlapStat', 'Both']
        allFeatures['#Bp overlap, diff from expected'] = ['[tail=more] [assumptions=bothIndependentBps]-> BpOverlapPValStat', 'DiffFromMean']
        #US-F
        allFeatures['Mean inside'] = ['dummy -> MeanInsideStat','Result']
        #UP-US
        allFeatures['#Points inside'] = ['dummy [tf1=TrivialFormatConverter] ->PointCountInsideSegsStat','Result']
        return allFeatures        

if __name__ == '__main__':
    featureDict = ReferenceAnalsesAsFeaturesCatalog.getValidAnalyses('NCBI36','Phenotype and disease associations:Assorted experiments:Virus integration, Derse et al. (2007):ASV'.split(':')\
                                                       ,'DNA structure:Fragile sites'.split(':'))
    print 'vs ref: ', featureDict.keys()
    
    featureDict = DirectDistanceCatalog.getValidAnalyses('NCBI36','Phenotype and disease associations:Assorted experiments:Virus integration, Derse et al. (2007):ASV'.split(':')\
                                                       ,'DNA structure:Fragile sites'.split(':'))
    print 'direct dist: ', featureDict.keys()
    
    featureDict = LocalResultsAsFeaturesCatalog.getValidAnalyses('NCBI36','Phenotype and disease associations:Assorted experiments:Virus integration, Derse et al. (2007):ASV'.split(':')\
                                                       ,[])
    print 'local res: ', featureDict.keys()

#featureDict = FeatureCatalog.getFeaturesFromTracks('NCBI36','Phenotype and disease associations:Assorted experiments:Virus integration, Derse et al. (2007):ASV'.split(':')\
#                                                   ,'DNA structure:Fragile sites'.split(':'))
#print featureDict.keys()
        
#featureDict = FeatureCatalog.getFeaturesFromTrackFormatCombination(tfName1, tfName2)
#print 'Choose between: ', featureDict.keys()
#
#choice = '#Bp overlap'
#analysisDef, resDictKey = featureDict[choice]
#
#result = AnalysisDefJob(analysisDef).run()
#value = result[resDictKey]