from quick.webtools.GeneralGuiTool import GeneralGuiTool
from quick.aux.GenomeImporter import GenomeImporter
from quick.application.ExternalTrackManager import ExternalTrackManager
from collections import OrderedDict
import os
#This is a template prototyping GUI that comes together with a corresponding web page.
#

class InstallGenomeTool(GeneralGuiTool):
    @staticmethod
    def getToolName():
        return "Install Genome Tool"

    @staticmethod
    def getInputBoxNames():
        "Returns a list of names for input boxes, implicitly also the number of input boxes to display on page. Each such box will call function getOptionsBoxK, where K is in the range of 1 to the number of boxes"
        return ['Select genome from history','Chromosome names found in fasta file', 'Select chromosomes to use', 'Select standard chromosomes'] 

    @staticmethod    
    def getOptionsBox1():
        ""
        return '__history__', 'hbgenome'
    
    @staticmethod    
    def getOptionsBox2(prevChoices):
        "Returns a list of options to be displayed in the first options box"
        #tempinfofile="/usit/invitro/work/hyperbrowser/sync/results/developer/files/006/dataset_6000.dat"
        tempinfofile=""
        if prevChoices[0]:
            tempinfofile=ExternalTrackManager.extractFnFromGalaxyTN(prevChoices[0].split(":"))
            tempinfo=GenomeImporter.getTempInfo(tempinfofile)
            return tempinfo['Temp chromosome names']
        return None
           
    
    @staticmethod    
    def getOptionsBox3(prevChoices): 
        '''Returns a list of options to be displayed in the second options box, which will be displayed after a selection is made in the first box.
        prevChoices is a list of selections made by the web-user in the previous input boxes (that is, list containing only one element for this case)        
        '''
        #print 'genomehbfile='+ExternalTrackManager.extractFnFromGalaxyTN(prevChoices[0])+'=\n'
        chrDict = OrderedDict()
        if prevChoices[1]:
            
            for line in prevChoices[1].split(os.linesep):
                chrDict[line.strip()] = False
        return chrDict
    
    @staticmethod
    def getOptionsBox4(prevChoices): 
        '''Returns a list of options to be displayed in the second options box, which will be displayed after a selection is made in the first box.
        prevChoices is a list of selections made by the web-user in the previous input boxes (that is, list containing only one element for this case)        
        '''
        chrDict = OrderedDict()
        for key in [x for x in prevChoices[2] if prevChoices[2][x]]:
            chrDict[key] = True
        return chrDict
    
    #@staticmethod    
    #def getOptionsBox3(prevChoices):
    #    return ['']

    #@staticmethod    
    #def getOptionsBox4(prevChoices):
    #    return ['']

    #@staticmethod
    #def getDemoSelections():
    #    return ['testChoice1','..']
        
    @staticmethod    
    def execute(choices, galaxyFn=None):
        '''Is called when execute-button is pushed by web-user.
        Should print output as HTML to standard out, which will be directed to a results page in Galaxy history.
        If needed, StaticFile can be used to get a path where additional files can be put (e.g. generated image files).
        choices is a list of selections made by web-user in each options box.
        '''
        print 'Executing...'
        #tempinfofile="/usit/invitro/work/hyperbrowser/sync/results/developer/files/006/dataset_6000.dat"
        tempinfofile=ExternalTrackManager.extractFnFromGalaxyTN(choices[0].split(":"))
        print "tempinfofile="+tempinfofile+"\n"
        tempinfo=GenomeImporter.getTempInfo(tempinfofile)
        print "tempinfo="+str(tempinfo)+"\n"
        chrnamesinfasta=tempinfo['Temp chromosome names'].split(os.linesep)
        
        allchrs={}
        for i in range(len(choices[2])):
            key = choices[2].keys()[i]
            if choices[2][key]:
                allchrs[chrnamesinfasta[i]]=key
        print 'All chromosomes chosen: ' + "\n" +str(allchrs)
        stdchrs=[]
        for key in choices[3]:
            if choices[3][key]:
                stdchrs.append(key)
        print 'stdchrs chromosomes chosen :' + "\n<br/>".join(stdchrs)
        
        GenomeImporter.createGenome( tempinfo['Genome abbreviation'], tempinfo['Genome full name'], allchrs, stdchrs, experimental=True)
        
        

    #@staticmethod
    #def isPublic():
    #    return True
    #
    @staticmethod
    def getToolDescription():
        ret = '1. Choose a file from history were you previously have used the "Download Genome Tool". If you have not first used that tool no apropiate file will appear in the list.\n<BR/>'
        ret +='2. Rename the chromosome names found in the fasta files if needed. Do not delete or add lines!\n<BR/>'
        ret +='3. Choose which chromosomes to install.\n<BR/>'
        ret +='3. Choose which chromosomes to install as "standard" (typically, chr1, chr2, chrX). The unchecked will be treated as "extended" and not usually included in tests in hyperbrowser. \n<BR/>'
        return ret
    #@staticmethod
    #def getToolIllustration():
    #    return None
    #
    #@staticmethod
    #def isDebugMode():
    #    return True