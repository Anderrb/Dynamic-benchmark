# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from gold.util.CommonFunctions import parseRegSpec, parseShortenedSizeSpec
from gold.util.CustomExceptions import NotImplementedError, ShouldNotOccurError
from gold.track.GenomeRegion import GenomeRegion
from gold.application.Config import DEFAULT_GENOME
from gold.origdata.GenomeElementSource import GenomeElementSource, BedGenomeElementSource, WigGenomeElementSource
from gold.origdata.BedGenomeElementSource import BedCategoryGenomeElementSource
from quick.application.AutoBinner import AutoBinner
from gold.origdata.GenomeElementSorter import GenomeElementSorter
from gold.origdata.GEOverlapClusterer import GEOverlapClusterer
from quick.origdata.RegionBoundaryFilter import RegionBoundaryFilter
from gold.origdata.GECategoryFilter import GECategoryFilter
from quick.util.GenomeInfo import GenomeInfo

class UserBinSource(object):
    def __new__(cls, regSpec, binSpec, genome=None, categoryFilterList=None): #,fileType):
        if regSpec in ['file','wig','bed','customtrack']:
            #if fileType != 'bed':
            #    raise NotImplementedError
            if regSpec == 'file':
                SelectedGEClass = GenomeElementSource
            elif regSpec == 'bed':
                SelectedGEClass = BedGenomeElementSource
            #elif regSpec == 'category.bed':
            #    SelectedGEClass = BedCategoryGenomeElementSource
            elif regSpec in ['wig','customtrack']:
                SelectedGEClass = WigGenomeElementSource
            #elif regSpec == 'meansd.wig':
            #    SelectedGEClass = WigBedMeanSdGenomeElementSource
            #elif regSpec == 'targetcontrol.wig':
            #    SelectedGEClass = WigBedTargetControlGenomeElementSource
            else:
                raise ShouldNotOccurError
            if genome is None:
                genome = DEFAULT_GENOME
            geSource = SelectedGEClass(binSpec, genome)
            #geSource = RegionBoundaryFilter(GEOverlapClusterer(GenomeElementSorter(SelectedGEClass(binSpec, genome))),\
                                        #GlobalBinSource(genome))
            if categoryFilterList is not None:
                geSource = GECategoryFilter(geSource, categoryFilterList)
            return cls._applyEnvelope(geSource)
        else:
            if binSpec == '*':
                binSize = None
            else:
                binSize = parseShortenedSizeSpec(binSpec)
            return AutoBinner(parseRegSpec(regSpec, genome), binSize)
    
    @staticmethod
    def _applyEnvelope(geSource):
        return RegionBoundaryFilter(GEOverlapClusterer(GenomeElementSorter(geSource)), GlobalBinSource(geSource.genome))
    
class UnBoundedUserBinSource(UserBinSource):
    @staticmethod
    def _applyEnvelope(geSource):
        return GEOverlapClusterer(GenomeElementSorter(geSource))

class UnClusteredUserBinSource(UserBinSource):
    @staticmethod
    def _applyEnvelope(geSource):
        return GenomeElementSorter(geSource)

class UnfilteredUserBinSource(UserBinSource):
    @staticmethod
    def _applyEnvelope(geSource):
        return geSource
    
class GlobalBinSource(object):
    def __new__(cls, genome):
        return UserBinSource(genome+':*','*')
    
class MinimalBinSource(object):
    def __new__(cls, genome):
        return [GenomeRegion(genome, GenomeInfo.getChrList(genome)[0], 0, 1)]
