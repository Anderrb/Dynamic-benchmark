# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#from quick.application.ExternalTrackManager import ExternalTrackManager
#import os.path
import os
import re
from gold.application.Config import DEFAULT_GENOME, URL_PREFIX
from gold.origdata.BedGenomeElementSource import BedGenomeElementSource, PointBedGenomeElementSource, \
                                                 BedMarkedGenomeElementSource, BedCategoryGenomeElementSource
from gold.origdata.WigGenomeElementSource import WigGenomeElementSource, WigPointBedGenomeElementSource, \
                                                 WigBedMeanSdGenomeElementSource, WigBedMappingGenomeElementSource, \
                                                 WigBedTargetControlGenomeElementSource
from gold.origdata.MicroarrayGenomeElementSource import MicroarrayGenomeElementSource
from gold.origdata.HBFunctionGenomeElementSource import HBFunctionGenomeElementSource
from gold.origdata.TrackPreProcessor import TrackPreProcessor
from gold.track.TrackFormat import TrackFormat
from gold.util.CommonFunctions import createDirPath, getClassName, isRedirectTrackName
from gold.util.CustomExceptions import ShouldNotOccurError
from quick.util.GenomeInfo import GenomeInfo
from quick.util.CommonFunctions import extractIdFromGalaxyFn as commonExtractIdFromGalaxyFn

class ExternalTrackManager:
    '''Handles external track names. These are of two types:
    ['external','...']: Handled basically just as a standard trackname.
        Only particularity is that the top category 'external' is not shown explicitly to users for track selection in HyperBrowser (is hidden)..
        Is of structure ['external'] + [URL_PREFIX] + id + [name], where id can be a list of length>1 (typically 2, due to codings from galaxy id..)
    
    ['galaxy','...']: An especially coded TN, used mainly to process files from galaxy history, but can also be used otherwise.
        Structure is: ['galaxy', fileEnding, origformatTrackFn, name]
        First element used for assertion, second element to determine origformat (as galaxy force ending .dat)
        origformatTrackFn is the file name to the data source for track data to be preprocessed.
        Typically ends with 'XXX/dataset_YYYY.dat'. XXX and YYYY are numbers which are extracted and used as id in the form [XXX, YYYY]
        The last element is the name of the track, only used for presentation purposes.
    '''
    
    @staticmethod
    def isHistoryTrack(tn):
        return ExternalTrackManager.isRedirectTrack(tn) or ExternalTrackManager.isExternalTrack(tn) \
            or ExternalTrackManager.isGalaxyTrack(tn)

    @staticmethod
    def isRedirectTrack(tn):
        return isRedirectTrackName(tn)

    @staticmethod
    def isGalaxyTrack(tn):
        return (tn is not None and len(tn)>0 and tn[0].lower() == 'galaxy')
    
    @staticmethod
    def isExternalTrack(tn):
        return (tn is not None and len(tn)>0 and tn[0].lower() == 'external')
    
    @staticmethod
    def extractIdFromGalaxyFn(fn):
        return commonExtractIdFromGalaxyFn(fn)
    
    @staticmethod
    def extractFnFromGalaxyTN(galaxyTN):
        return galaxyTN[2]

    @staticmethod
    def extractFileSuffixFromGalaxyTN(galaxyTN):
        suffix = galaxyTN[1]
        if not suffix in ExternalTrackManager.getSupportedFileSuffixes():
            raise ShouldNotOccurError('Filetype ' + suffix + ' not supported.')
        return suffix
    
    @staticmethod
    def getSupportedFileSuffixes():
        return ['bed','point.bed','category.bed','marked.bed','microarray','bedGraph','wig','point.wig','meansd.wig','mapping.wig','targetcontrol.wig','customtrack','gff','hbfunction']
    
    @classmethod
    def getStdTrackNameFromGalaxyTN(cls, galaxyTN):
        assert(galaxyTN[0].lower() == 'galaxy')
        assert(galaxyTN[1].lower() in cls.getSupportedFileSuffixes())
        fn = cls.extractFnFromGalaxyTN(galaxyTN)
        id = cls.extractIdFromGalaxyFn(fn)
        name = galaxyTN[-1]
        return ExternalTrackManager.createStdTrackName(id, name)
    
    @classmethod
    def createStdTrackName(cls, id, name, subtype = ''):
        urlPrefix = URL_PREFIX.replace(os.path.sep, '')
        return ['external'] + ([urlPrefix] if urlPrefix != '' else []) + id + [name] + ([subtype] if subtype != '' else [])
    
    @classmethod
    def renameExistingStdTrackIfNeeded(cls, genome, stdTrackName):
        for allowOverlaps in [False, True]:
            parentDir = createDirPath(stdTrackName[:-1], genome, '', allowOverlaps=allowOverlaps)
            if os.path.exists(parentDir):
                dirContents = os.listdir(parentDir)
                if len(dirContents) == 1 and dirContents[0] != stdTrackName[-1]:
                    oldDir = parentDir + dirContents[0]
                    newDir = parentDir + stdTrackName[-1]
                    os.rename(oldDir, newDir)
        
    @staticmethod
    def getGESource(fullFn, fileSuffix, extTrackName=None, genome=None):
        #This is reduntant to GenomeElementSource fn handling, but must be done excplicitly at the time being because suffix is not in fn
        if fileSuffix == 'wig' or fileSuffix == 'customtrack':
            return WigGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'point.wig':
            return WigPointBedGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'meansd.wig':
            return WigBedMeanSdGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'mapping.wig':
            return WigBedMappingGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'targetcontrol.wig':
            return WigBedTargetControlGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'bed':
            return BedGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'point.bed':
            return PointBedGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'category.bed':
            return BedCategoryGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'marked.bed':
            return BedMarkedGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'microarray':
            return MicroarrayGenomeElementSource(fullFn, genome, extTrackName)
        elif fileSuffix == 'hbfunction':
            return HBFunctionGenomeElementSource(fullFn, genome, extTrackName)
        else:
            raise ShouldNotOccurError('Filetype ' + fileSuffix + ' not supported.')
    
    @staticmethod
    def preProcess(fullFn, extTrackName, fileSuffix, genome):
        geSource = ExternalTrackManager.getGESource(fullFn, fileSuffix, extTrackName, genome)
        for allowOverlaps in [False, True]:
            # This is a copy from AllTracksPreprosessor. This should be refactored,
            # perhaps be included in TrackPreProcessor.process()?
            format = TrackFormat.createInstanceFromPrefixList(geSource.getPrefixList(), \
                                                              geSource.getValDataType(), \
                                                              geSource.getValDim())
            if format.getFormatName().lower() == 'function' and allowOverlaps:
                    return False
            TrackPreProcessor.process(geSource, allowOverlaps)
            #TrackPreProcessor.ensureChrCreated(genome, geSource, chrList=GenomeInfo.getChrList(genome))
            TrackPreProcessor.ensureChrCreated(genome, extTrackName, geSource.getPrefixList(), \
                                               geSource.getValDataType(), geSource.getValDim(), \
                                               chrList=GenomeInfo.getChrList(genome), allowOverlaps=allowOverlaps)
        
    #@classmethod
    #def checkIfPreProcessed(extTrackName):
    #    try:
    #        cls.preProcess
    #        geSource = GenomeElementSource(ORIG_DATA_PATH + os.sep + fn, genome, trackName, depth)
    #        geSourceDict.addGeSource(genome, trackName, geSource)
    #        print 'processing fn: ', fn
    #        TrackPreProcessor.process(geSource)
    #    except NotSupportedError:
    #        geSourceDict.removeGeSource(genome, trackName)
    #        print '-',
    #    except Exception, e:
    #        geSourceDict.removeGeSource(genome, trackName)
    #        print 'Warning! Could not pre-process track:', fn
    #        print getClassName(e) + ':', e


    #@staticmethod
    #def checkIfGalaxyTNPreProcessed(extTrackName):
    #    pass
    
    @classmethod
    def getPreProcessedTrackFromGalaxyTN(cls, genome, galaxyTN):
        stdTrackName = cls.getStdTrackNameFromGalaxyTN(galaxyTN)
        cls.renameExistingStdTrackIfNeeded(genome, stdTrackName)
        fn = cls.extractFnFromGalaxyTN(galaxyTN)
        fileSuffix = cls.extractFileSuffixFromGalaxyTN(galaxyTN)
        
        print 'Preprocessing external track...<br>'
        try:
            cls.preProcess(fn, stdTrackName, fileSuffix, genome)
        except IOError:
            print 'Already preprocessed, continuing...<br>'
        except Exception,e:
            print 'An error occured during preprocessing: ', getClassName(e) + ':', e, '<br>'
            raise
        else:
            print 'Finished preprocessing.<br>'
        return stdTrackName

#print ExternalTrackManager.extractIdFromGalaxyFn('/usr/test/ts/000/016.dat')
