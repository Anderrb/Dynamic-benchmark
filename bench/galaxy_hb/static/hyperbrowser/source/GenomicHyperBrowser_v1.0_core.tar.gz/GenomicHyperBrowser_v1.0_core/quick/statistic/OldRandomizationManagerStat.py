# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from numpy import nan, isnan
from gold.statistic.MagicStatFactory import MagicStatFactory
from gold.statistic.Statistic import Statistic, OnlyGloballySplittable
from gold.statistic.RawDataStat import RawDataStat
from gold.track.TrackFormat import NeutralTrackFormatReq
from gold.application.Config import VERBOSE
from gold.util.CommonFunctions import isIter
from gold.util.CompBinManager import CompBinManager


class OldRandomizationManagerStat(MagicStatFactory):
    pass        

class OldRandomizationManagerStatUnsplittable(Statistic):
    IS_MEMOIZABLE = False
    
    def __init__(self, region, track, track2, rawStatistic, randTrackClass, tails='right-tail', numResamplings=1000, **kwArgs):
        Statistic.__init__(self, region, track, track2, **kwArgs)
        
        if type(rawStatistic) is str:
            from gold.statistic.AllStatistics import STAT_CLASS_DICT
            rawStatistic = STAT_CLASS_DICT[rawStatistic]
        if type(randTrackClass) is str:
            randTrackClass = globals()[randTrackClass]
            
        self._rawStatistic = rawStatistic
        self._randTrackClass = randTrackClass
        #assert(randTrackClass == ReshuffledRandomizedTrack)
        
        #self._randTrackList = []
        self._tails = tails
        self._numResamplings = int(numResamplings)
        CompBinManager.ALLOW_COMP_BIN_SPLITTING = False
        
    #def _createRandomizedStat(self, i):
    #    randTrack = self._randTrackClass(self._track, self._region, i)
    #    return self._rawStatistic(self._region, randTrack, self._track2, **self._kwArgs)

    def _addChildrenFirstRandTrack(self):
        for i in xrange(self._numResamplings):
            randTrack = self._randTrackClass(self._track, self._region, i)
            #self._randTrackList.append(randTrack)
            self._addChild(self._rawStatistic(self._region, randTrack, self._track2, **self._kwArgs) )

    def _addChildrenSecondRandTrack(self):
        for i in xrange(self._numResamplings):
            randTrack = self._randTrackClass(self._track2, self._region, i)
            #self._randTrackList.append(randTrack)
            self._addChild(self._rawStatistic(self._region, self._track, randTrack, **self._kwArgs) )

    def _createChildren(self):                
        self._realChildIndex = 0
        self._randChildIndex = 1

        #A trick to ensure memoization of rawData. Not needed anymore, as real child holds both real tracks because real child is now also limited to user-bin level.
        #if not isIter(self._region):            
        #    if self._track2 != None:
        #        self._addChild( RawDataStat(self._region, self._track2, NeutralTrackFormatReq()) )
        #    else:
        #        self._addChild( RawDataStat(self._region, self._track, NeutralTrackFormatReq()) )
        #    self._realChildIndex += 1
        #    self._randChildIndex += 1

        self._addChild( self._rawStatistic(self._region, self._track, self._track2, **self._kwArgs) )        
           
    def _compute(self):
        #must add randomized children inside _compute-method, else result for it would have been created before the call to this compute..
        if self._track2 == None:
            self._addChildrenFirstRandTrack()
        else:
            self._addChildrenSecondRandTrack()

        #if VERBOSE:
        #    print [randChild.getResult() for randChild in self._children]
            
        if self._children[self._realChildIndex].getResult() is None or isnan(self._children[self._realChildIndex].getResult()):
            return None

        randChildren = self._children[self._randChildIndex:]
        for randChild in randChildren:
            print 'computing randChild..'
            randChild.getResult() #only to ensure result is created, will be accessed afterwards..
            randChild.afterComputeCleanup()
        
        print 'randResults: ', [randChild.getResult() for randChild in randChildren]
            
        observation = self._children[self._realChildIndex].getResult()
        meanOfNullDistr = 1.0 * sum( randChild.getResult() for randChild in randChildren ) / \
                             len( randChildren )

        pvalRight = 1.0 * sum(1 for randChild in randChildren \
                         if randChild.getResult() >= observation ) / self._numResamplings
        pvalLeft = 1.0 * sum(1 for randChild in randChildren \
                         if randChild.getResult() <= observation ) / self._numResamplings

        if self._tails == 'right-tail':
            pval = pvalRight
        elif self._tails == 'left-tail':
            pval = pvalLeft
        elif self._tails == 'two-tail':
            pval = 2 * min(pvalLeft, pvalRight)
        else:
            raise RuntimeError()
        
        return {'pVal':pval, 'testStatistic':observation, 'meanOfNull':meanOfNullDistr}
    
    def _afterComputeCleanup(self):
        pass
