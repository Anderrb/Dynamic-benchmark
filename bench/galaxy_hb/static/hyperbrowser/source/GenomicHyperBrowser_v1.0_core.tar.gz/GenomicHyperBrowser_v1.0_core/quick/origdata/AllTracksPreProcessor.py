#!/usr/bin/env python
# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

#!/usr/bin/env python
import os
import shutil
import sys
import re
from gold.description.TrackInfo import TrackInfo
from gold.origdata.GenomeElementSource import GenomeElementSource
from gold.origdata.TrackPreProcessor import TrackPreProcessor
from quick.origdata.OrigTrackFnSource import OrigTrackNameSource
from gold.util.CustomExceptions import NotSupportedError
from quick.util.GenomeInfo import GenomeInfo
from gold.util.CommonFunctions import createOrigPath, createDirPath
from gold.track.TrackFormat import TrackFormat
from gold.application.Config import PROCESSED_DATA_PATH
#from gold.util.Profiler import Profiler
import traceback

class AllTracksPreProcessor:
    PASS_ON_EXCEPTIONS = False
    #SIMULATED_RUN = False
    MODE = 'Real' #'Simulated', 'UpdateMeta'
    
    @staticmethod
    def process(genome, trackNameFilter=[], depth=0):
        avoidLiterature = len(trackNameFilter) == 0 or (trackNameFilter != GenomeInfo.getPropertyTrackName(genome, 'literature'))
        for trackName in OrigTrackNameSource(genome, trackNameFilter, avoidLiterature):
            #AllTracksPreProcessor._processTrackName(genome, trackName, depth, False)
            #AllTracksPreProcessor._processTrackName(genome, trackName, depth, True)
            AllTracksPreProcessor._processTrackName(genome, trackName, depth)
            
    @staticmethod
    def _processTrackName(genome, trackName, depth):
    #def _processTrackName(genome, trackName, depth, allowOverlaps):
        wasProcessed = False
        
        trackInfo = TrackInfo(genome, trackName)
        storedId, storedPreProcVersion = trackInfo.id, trackInfo.preProcVersion
        
        try:
            processStatuses = [AllTracksPreProcessor._processOneOverlapVersion(genome, trackName, depth, \
                               allowOverlaps, trackInfo, storedId, storedPreProcVersion)\
                               for allowOverlaps in [False, True] ]
            wasProcessed = any(processStatuses)
        except NotSupportedError, e:
            AllTracksPreProcessor._printExceptionMsg(e, e.fn, Error=False)
            if AllTracksPreProcessor.PASS_ON_EXCEPTIONS:
                raise
        except Exception, e:
            AllTracksPreProcessor._printExceptionMsg(e, e.fn if hasattr(e, 'fn') else 'No file', Error=True)
            if AllTracksPreProcessor.PASS_ON_EXCEPTIONS:
                raise

        if wasProcessed:
            trackInfo.store()
            
        return wasProcessed

    @staticmethod
    def _processOneOverlapVersion(genome, trackName, depth, allowOverlaps, trackInfo, storedId, storedPreProcVersion):
        baseDir = createOrigPath(genome, trackName,'')
        version, filetype, prefixList, valDataType = None, None, None, None
        id = None
        wasProcessed = False
        
        try:
            #print baseDir, ' and ',os.listdir( baseDir )
            for relFn in sorted(os.listdir( baseDir )):
                fn = baseDir + relFn
        #            print 'Fn: ', fn
                if os.path.isdir(fn):
                    continue
                
                fnPart = os.path.split(fn)[-1]
                if fnPart[0] in ['.','_','#'] or fnPart[-1] in ['~','#']: #to avoid hidden files..
                    continue

                geSource = GenomeElementSource(fn, genome, trackName) #, depth)
                format = TrackFormat.createInstanceFromPrefixList(geSource.getPrefixList(), \
                                                                  geSource.getValDataType(), \
                                                                  geSource.getValDim())
                if format.getFormatName().lower() == 'function' and allowOverlaps:
                    return False
                
                if id is None:
                    id = TrackInfo.constructId(genome, trackName, geSource._VERSION)

                if TrackPreProcessor.preProcFilesExists(geSource, allowOverlaps):
                    if id == storedId and geSource._VERSION == storedPreProcVersion:                        
                        return False
                    #print 'UNEQUAL: ', id , trackInfo.id ,'and ',geSource._VERSION , trackInfo.preProcVersion
                    dirPath = createDirPath(trackName, genome, '', allowOverlaps)
                    
                    assert( dirPath.startswith(PROCESSED_DATA_PATH) )
                    #if not AllTracksPreProcessor.SIMULATED_RUN:
                    if AllTracksPreProcessor.MODE == 'Real':
                        print 'Removing outdated preprocessed data: ', dirPath
                        shutil.rmtree(dirPath)
                    else:
                        print 'Would now have removed outdated preprocessed data if real run: ', dirPath
                                        
                if AllTracksPreProcessor.MODE == 'Simulated':
                    print os.linesep + 'Would now have processed fn: ', fn, ' in a real run'
                    return False
                elif AllTracksPreProcessor.MODE == 'Real':
                    print os.linesep + 'Processing fn: ', fn
                    numGEPreProcessed = TrackPreProcessor.process(geSource, allowOverlaps)
                else:
                    print os.linesep + 'Only updating meta info based on file: ', fn
                    assert AllTracksPreProcessor.MODE == 'UpdateMeta'
                    numGEPreProcessed = None
                    #continue, in order for metadata to be set, but without processing..
                
                wasProcessed = True
                
                assert prefixList in [None, geSource.getPrefixList()], 'Files in the same folder have different prefixLists (different formats?)'
                assert valDataType in [None, geSource.getValDataType()], 'Files in the same folder have different valDataType (different formats?)'
                assert filetype in [None, geSource.getFileSuffix()], 'Files in the same folder have different fileType'
                assert version in [None, geSource._VERSION], 'Files in the same folder use geSources with different version (strange..)'
                
                prefixList, valDataType, valDim = geSource.getPrefixList(), geSource.getValDataType(), geSource.getValDim()
                filetype = geSource.getFileSuffix()
                version = geSource._VERSION
                                
        except Exception, e:
            e.fn = fn
            raise 

        format = TrackFormat.createInstanceFromPrefixList(prefixList, valDataType, valDim)
        if AllTracksPreProcessor.MODE == 'Real':
            TrackPreProcessor.ensureChrCreated(genome, trackName, prefixList, valDataType, valDim, chrList=GenomeInfo.getChrList(genome), allowOverlaps=allowOverlaps)
        trackInfo.setPreProcessInfo(filetype, format, version, id, allowOverlaps, numGEPreProcessed)
        
        return wasProcessed
    
    @staticmethod
    def _printExceptionMsg(e, fn, Error=False):
        print (os.linesep + '--- BEGIN ERROR ---' + os.linesep *2 if Error else 'Warning! ') + 'Could not pre-process track: ' + fn
        print e.__class__.__name__ + ':', e
        if Error:
            traceback.print_exc(file=sys.stdout)
            print os.linesep + '--- END ERROR ---' + os.linesep
    
if __name__ == "__main__":
    if not len(sys.argv) in [2,3,4]:
        print 'Syntax: python AllTracksPreProcessor.py genome [trackName:subType] [mode=Real/Simulated/UpdateMeta]'
        sys.exit(0)
        
    if len(sys.argv) == 2:
        tn = []
        mode = 'Real'
    elif len(sys.argv) == 3:
        if sys.argv[2] in ['Real', 'Simulated', 'UpdateMeta']:
            tn = []
            mode = sys.argv[2]
        else:
            tn = sys.argv[2].split(':')
            mode = 'Real'
    else:
        tn = sys.argv[2].split(':')
        mode = sys.argv[3]

    AllTracksPreProcessor.MODE = mode
    assert AllTracksPreProcessor.MODE in ['Real', 'Simulated', 'UpdateMeta']
    AllTracksPreProcessor.process(sys.argv[1], tn, depth=0)        
    
