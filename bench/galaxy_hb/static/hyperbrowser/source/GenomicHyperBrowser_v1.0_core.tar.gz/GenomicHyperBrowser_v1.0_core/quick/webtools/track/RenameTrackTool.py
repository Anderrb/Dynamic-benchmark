from quick.webtools.GeneralGuiTool import GeneralGuiTool
from quick.aux.RenameTrack import renameTrack
#This is a template prototyping GUI that comes together with a corresponding web page.
#

class RenameTrackTool(GeneralGuiTool):
    @staticmethod
    def getToolName():
        return "Rename track"

    @staticmethod
    def getInputBoxNames(prevChoices=None):
        "Returns a list of names for input boxes, implicitly also the number of input boxes to display on page. Each such box will call function getOptionsBoxK, where K is in the range of 1 to the number of boxes"
        return ['Genome','Current track name','New track name']

    @staticmethod    
    def getOptionsBox1():
        "Returns a list of options to be displayed in the first options box"
        return '__genome__'
    
    @staticmethod    
    def getOptionsBox2(prevChoices): 
        '''Returns a list of options to be displayed in the second options box, which will be displayed after a selection is made in the first box.
        prevChoices is a list of selections made by the web-user in the previous input boxes (that is, list containing only one element for this case)        
        '''
        return '__track__'

    @staticmethod    
    def getOptionsBox3(prevChoices): 
        return ':'.join(prevChoices[1])

    #@staticmethod
    #def getDemoSelections():
    #    return ['NCBI36','Trashcan:SICER islands:H3K27me3','Trashcan:SICER islands:H3K27me3']
    #
    @staticmethod    
    def execute(choices, galaxyFn=None):
        '''Is called when execute-button is pushed by web-user.
        Should print output as HTML to standard out, which will be directed to a results page in Galaxy history.
        If needed, StaticFile can be used to get a path where additional files can be put (e.g. generated image files).
        choices is a list of selections made by web-user in each options box.
        '''
        #print 'Executing...'
        genome = choices[0]
        oldTn = choices[1]
        newTn = choices[2]
        
        renameTrack(genome, oldTn.split(':'), newTn.split(':'))
        print '%s renamed to %s in genome %s.' % (oldTn, newTn, genome)
    
    
    @staticmethod
    def validateAndReturnErrors(choices):
        '''
        Should validate the selected input parameters. If the parameters are not valid,
        an error text explaining the problem should be returned. The GUI then shows this text
        to the user (if not empty) and greys out the execute button (even if the text is empty).
        If all parameters are valid, the method should return None, which enables the execute button.
        '''
        if choices[1] == '':
            return ''
        
    @staticmethod
    def isPublic():
        return False
    
    @staticmethod
    def getToolDescription():
        from gold.result.HtmlCore import HtmlCore
        core = HtmlCore()
        core.paragraph('This tool is used to rename or move a track.')
        core.divider()
        core.highlight('Current track name')
        core.paragraph('Select the track to rename. It is allowed to select a parent track or category.')
        core.divider()
        core.highlight('New track name')
        core.paragraph("Type in the new track name. Track names are separated by ':', e.g. 'Trashcan:SICER islands:H3K27me3'.")
        return str(core)
        
    #@staticmethod
    #def getToolIllustration():
    #    return None
    #
    #@staticmethod
    #def isDebugMode():
    #    return True
