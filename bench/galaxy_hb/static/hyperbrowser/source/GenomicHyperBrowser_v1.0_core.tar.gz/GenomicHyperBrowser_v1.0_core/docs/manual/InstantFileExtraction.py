# Copyright (C) 2009, Geir Kjetil Sandve, Sveinung Gundersen and Morten Johansen
# This file is part of The Genomic HyperBrowser.
#
#    The Genomic HyperBrowser is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    The Genomic HyperBrowser is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with The Genomic HyperBrowser.  If not, see <http://www.gnu.org/licenses/>.

from quick.aux.TrackExtractor import TrackExtractor
from quick.application.UserBinSource import UserBinSource

trackName1 = ['Genes and Gene Prediction Tracks','Refseq','Genes'] #or any other track that are precomputed on the server

#genome regions to extract could be from a bed-file:
#regions = UserBinSource('file','myRegions.bed')
#or implicitly declared, here as 500 regions, 1k long, in the beginning of chr1:
regions = UserBinSource('chr1:1-500000','1k') #could also have been e.g. genomewide as UserBinSource('*','*')

#options
globalCoords=False #now gives coordinates relative to each region. Using True would have given global coordinates (chromosome-offsets)
asOriginal=False #gives output as standard files (bed or wig). Using True would have given the source line for each element in its original format (not applicable to the Function format).

#Generate files. Here only one track, but could have been list of many tracks.
#Either combine track data for all regions in a single file:
TrackExtractor.extractManyToOneDir([trackName1], regions, 'myOutputFolder', globalCoords, asOriginal)
#Or one could have created a separate folder with track-data for each region:
#TrackExtractor.extractManyToRegionDirs([trackName1], regions, 'myOutputFolder', globalCoords, asOriginal)
